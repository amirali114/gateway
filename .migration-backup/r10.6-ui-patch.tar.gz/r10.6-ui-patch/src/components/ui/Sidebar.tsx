"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/cn";
import {
  LayoutDashboard, Bot, Rocket, Network, Stethoscope,
  Globe, Shield, Bell, Users, ClipboardList, Settings,
  ChevronLeft, Zap, LogOut, RefreshCw,
} from "lucide-react";

const navItems = [
  { href: "/",            icon: LayoutDashboard, label: "داشبورد" },
  { href: "/agents",      icon: Bot,             label: "عاملان" },
  { href: "/release",     icon: Rocket,          label: "انتشار" },
  { href: "/mother",      icon: Network,         label: "مادر" },
  { href: "/diagnostics", icon: Stethoscope,     label: "تشخیص" },
  { href: "/gateway",     icon: Globe,           label: "دروازه" },
  { href: "/policy",      icon: Shield,          label: "سیاست" },
  { href: "/alerts",      icon: Bell,            label: "هشدارها" },
  { href: "/users",       icon: Users,           label: "کاربران" },
  { href: "/audit",       icon: ClipboardList,   label: "حسابرسی" },
  { href: "/sync",        icon: RefreshCw,       label: "همگام‌سازی" },
  { href: "/settings",    icon: Settings,        label: "تنظیمات" },
];

interface SidebarProps {
  alertCount?: number;
  /** Injected server-side from session — never derive from client state */
  currentUser?: { name: string; email: string; role: string };
}

export function Sidebar({ alertCount = 0, currentUser }: SidebarProps) {
  const pathname = usePathname();
  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  return (
    <aside className="flex flex-col w-56 shrink-0 bg-[hsl(var(--sidebar))] border-l border-[hsl(var(--sidebar-border))] h-screen sticky top-0">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 h-14 border-b border-[hsl(var(--sidebar-border))] shrink-0">
        <div className="w-7 h-7 rounded-lg bg-[hsl(var(--primary))] flex items-center justify-center shrink-0">
          <Zap className="w-4 h-4 text-white" />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="text-[13px] font-bold tracking-tight">Unixsee</span>
          <span className="text-[10px] text-[hsl(var(--muted-foreground))] ltr">Campaign Gateway</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-2 overflow-y-auto scrollbar-thin">
        <div className="flex flex-col gap-0.5">
          {navItems.map(({ href, icon: Icon, label }) => {
            const active = isActive(href);
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2 rounded-md text-[13px] font-medium transition-colors group relative",
                  active
                    ? "sidebar-item-active"
                    : "text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))]/50 hover:text-[hsl(var(--foreground))]"
                )}
              >
                <Icon className={cn(
                  "w-4 h-4 shrink-0",
                  active ? "text-[hsl(var(--primary))]" : "text-[hsl(var(--muted-foreground))] group-hover:text-[hsl(var(--foreground))]"
                )} />
                <span className="flex-1">{label}</span>
                {href === "/alerts" && alertCount > 0 && (
                  <span className="text-[10px] bg-red-500 text-white font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center ltr">
                    {alertCount}
                  </span>
                )}
                {active && <ChevronLeft className="w-3 h-3 text-[hsl(var(--primary))]" />}
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="border-t border-[hsl(var(--sidebar-border))] p-3 flex flex-col gap-1">
        <form action="/logout" method="POST">
          <button
            type="submit"
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-[13px] text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--sidebar-accent))]/50 hover:text-red-400 transition-colors"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>خروج</span>
          </button>
        </form>
        {currentUser && (
          <div className="px-3 pt-1">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-indigo-500/20 flex items-center justify-center text-[10px] font-bold text-indigo-400 shrink-0">
                {currentUser.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-medium truncate">{currentUser.name}</p>
                <p className="ltr text-[10px] text-[hsl(var(--muted-foreground))] truncate">{currentUser.role}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
