import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";

interface DashboardShellProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  alertCount?: number;
  /**
   * Pass current user from your existing session/auth.
   * DashboardShell is a server component; session reading happens in the parent layout.
   */
  currentUser?: { name: string; email: string; role: string };
}

/**
 * DashboardShell is intentionally a Server Component.
 * It composes Sidebar (client) and Topbar (client) with server-provided props.
 * Data (alertCount, currentUser) must be passed from the parent layout which reads
 * from your existing session guard — never derive these from client state.
 */
export function DashboardShell({
  children,
  title,
  subtitle,
  actions,
  alertCount = 0,
  currentUser,
}: DashboardShellProps) {
  return (
    <div className="flex h-screen bg-[hsl(var(--background))] overflow-hidden">
      <Sidebar alertCount={alertCount} currentUser={currentUser} />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Topbar title={title} subtitle={subtitle} alertCount={alertCount} actions={actions} />
        <main className="flex-1 overflow-y-auto scrollbar-thin p-5">
          {children}
        </main>
      </div>
    </div>
  );
}
