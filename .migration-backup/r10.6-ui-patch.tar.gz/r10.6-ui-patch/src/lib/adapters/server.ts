/**
 * Server-side adapter stubs for Unixsee Campaign Gateway dashboard.
 *
 * INTEGRATION GUIDE:
 * Replace each function body with a call to your existing Mother API client.
 * These functions run server-side only — never import this file in a client component.
 *
 * Real API endpoints (all server-side, via existing Mother API client):
 *   GET /healthz                   → getHealthz()
 *   GET /readyz                    → getReadyz()
 *   GET /v1/storage/status         → getStorageStatus()
 *   GET /v1/health/report          → getHealthReport()
 *   GET /v1/release-gates          → getReleaseGates()
 *   GET /v1/release-gates/summary  → getReleaseGatesSummary()
 *   GET /v1/agents                 → getAgents()
 *   GET /v1/policies/default       → getPolicies()
 *   GET /v1/alerts/summary         → getAlerts()
 *
 * NOTE: Mother base URL stays server-side. No management token is ever sent to the browser.
 * NOTE: Do NOT import or call this adapter from any "use client" component.
 */
import "server-only";
import type {
  DashboardVM, AgentVM, ReleaseGateVM, MotherNodeVM,
  DiagnosticCheckVM, GatewayRouteVM, PolicyVM, AlertVM,
  UserVM, AuditLogVM,
} from "@/lib/view-models";

// ─── dashboard overview ────────────────────────────────────────────────────
export async function getDashboard(): Promise<DashboardVM> {
  // TODO: call your existing Mother API client:
  //   const agents   = await motherClient.get("/v1/agents")
  //   const gates    = await motherClient.get("/v1/release-gates/summary")
  //   const alerts   = await motherClient.get("/v1/alerts/summary")
  //   const health   = await motherClient.get("/v1/health/report")
  //   return normalizeDashboard(agents, gates, alerts, health)
  throw new Error("getDashboard: replace stub with Mother API client call");
}

// ─── agents ────────────────────────────────────────────────────────────────
export async function getAgents(): Promise<AgentVM[]> {
  // TODO: const raw = await motherClient.get("/v1/agents")
  //       return raw.agents.map(normalizeAgent)
  throw new Error("getAgents: replace stub with Mother API client call");
}

export async function getAgent(id: string): Promise<AgentVM | null> {
  // TODO: const raw = await motherClient.get(`/v1/agents/${id}`)
  //       return normalizeAgent(raw)
  throw new Error(`getAgent(${id}): replace stub with Mother API client call`);
}

// ─── release gates ─────────────────────────────────────────────────────────
export async function getActiveRelease(): Promise<ReleaseGateVM | null> {
  // TODO: const raw = await motherClient.get("/v1/release-gates")
  //       return raw.active ? normalizeRelease(raw.active) : null
  throw new Error("getActiveRelease: replace stub with Mother API client call");
}

export async function getReleaseHistory(): Promise<Pick<ReleaseGateVM, "id" | "name" | "version" | "stage">[]> {
  // TODO: const raw = await motherClient.get("/v1/release-gates")
  //       return raw.history.map(r => ({ id: r.id, name: r.name, version: r.version, stage: r.stage }))
  throw new Error("getReleaseHistory: replace stub with Mother API client call");
}

// ─── mother nodes ──────────────────────────────────────────────────────────
export async function getMotherNodes(): Promise<MotherNodeVM[]> {
  // TODO: const raw = await motherClient.get("/v1/health/report")
  //       return normalizeMotherNodes(raw)
  throw new Error("getMotherNodes: replace stub with Mother API client call");
}

// ─── diagnostics ───────────────────────────────────────────────────────────
export async function getDiagnostics(): Promise<DiagnosticCheckVM[]> {
  // TODO:
  //   const healthz  = await motherClient.get("/healthz")
  //   const readyz   = await motherClient.get("/readyz")
  //   const storage  = await motherClient.get("/v1/storage/status")
  //   const report   = await motherClient.get("/v1/health/report")
  //   return normalizeDiagnostics(healthz, readyz, storage, report)
  throw new Error("getDiagnostics: replace stub with Mother API client call");
}

// ─── gateway routes ────────────────────────────────────────────────────────
export async function getGatewayRoutes(): Promise<GatewayRouteVM[]> {
  // TODO: PHP Gateway exposes route config — read from your existing gateway route store
  throw new Error("getGatewayRoutes: replace stub with gateway route store");
}

// ─── policies ──────────────────────────────────────────────────────────────
export async function getPolicies(): Promise<PolicyVM[]> {
  // TODO: const raw = await motherClient.get("/v1/policies/default")
  //       return normalizePolicies(raw)
  throw new Error("getPolicies: replace stub with Mother API client call");
}

// ─── alerts ────────────────────────────────────────────────────────────────
export async function getAlerts(): Promise<AlertVM[]> {
  // TODO: const raw = await motherClient.get("/v1/alerts/summary")
  //       return normalizeAlerts(raw)
  throw new Error("getAlerts: replace stub with Mother API client call");
}

// ─── users ─────────────────────────────────────────────────────────────────
export async function getUsers(): Promise<UserVM[]> {
  // TODO: read from your existing user storage (same source used by RBAC)
  throw new Error("getUsers: replace stub with user storage call");
}

// ─── audit logs ────────────────────────────────────────────────────────────
export async function getAuditLogs(): Promise<AuditLogVM[]> {
  // TODO: read from your existing audit log storage
  throw new Error("getAuditLogs: replace stub with audit log storage call");
}
