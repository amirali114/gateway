import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";

// Self-hosted via Next.js font optimization — no Google CDN at runtime
const vazirmatn = Vazirmatn({
  subsets: ["arabic"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Unixsee Campaign Gateway",
  description: "پنل کنترل عملیاتی Unixsee Campaign Gateway",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl" className={vazirmatn.variable}>
      <body style={{ fontFamily: "var(--font-vazirmatn), Tahoma, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
