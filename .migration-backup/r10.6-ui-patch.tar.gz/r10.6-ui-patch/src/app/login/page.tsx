/**
 * Login page — visual shell only.
 * INTEGRATION: Replace the form's action with your existing app/login/actions.ts server action.
 * Do NOT change the auth/session/token logic in the BASE project.
 */
"use client";
import { useState } from "react";
import { Zap, Eye, EyeOff, Lock, Mail, Shield } from "lucide-react";

export default function LoginPage() {
  const [showPass, setShowPass] = useState(false);

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(99,102,241,0.08)_0%,_transparent_60%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(16,185,129,0.05)_0%,_transparent_50%)] pointer-events-none" />

      <div className="w-full max-w-sm flex flex-col gap-6 relative">
        <div className="text-center flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[hsl(var(--primary))] flex items-center justify-center shadow-lg shadow-[hsl(var(--primary))]/20">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Unixsee Campaign Gateway</h1>
            <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">پنل کنترل عملیاتی</p>
          </div>
        </div>

        <div className="card-glass p-6 flex flex-col gap-5">
          <div>
            <h2 className="text-[15px] font-bold">ورود به سیستم</h2>
            <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">با حساب سازمانی خود وارد شوید</p>
          </div>

          {/*
            INTEGRATION:
            Replace this form action with your existing app/login/actions.ts server action.
            Example: <form action={loginAction}>
            Keep your existing session/cookie logic — only swap the visual wrapper.
          */}
          <form method="POST" action="/login" className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium">ایمیل سازمانی</label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--muted-foreground))]" />
                <input
                  type="email"
                  name="email"
                  placeholder="name@unixsee.io"
                  required
                  className="w-full bg-[hsl(var(--muted))]/40 border border-[hsl(var(--border))] rounded-md px-3 py-2 pr-10 text-sm outline-none focus:border-[hsl(var(--primary))] transition-colors ltr placeholder:text-[hsl(var(--muted-foreground))]"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium">رمز عبور</label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--muted-foreground))]" />
                <input
                  type={showPass ? "text" : "password"}
                  name="password"
                  placeholder="••••••••"
                  required
                  className="w-full bg-[hsl(var(--muted))]/40 border border-[hsl(var(--border))] rounded-md px-3 py-2 pr-10 text-sm outline-none focus:border-[hsl(var(--primary))] transition-colors ltr placeholder:text-[hsl(var(--muted-foreground))]"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] transition-colors"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-medium flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[hsl(var(--muted-foreground))]" />
                کد تأیید دو‌مرحله‌ای
              </label>
              <input
                type="text"
                name="totp"
                placeholder="123456"
                maxLength={6}
                className="w-full bg-[hsl(var(--muted))]/40 border border-[hsl(var(--border))] rounded-md px-3 py-2 text-sm outline-none focus:border-[hsl(var(--primary))] transition-colors ltr tracking-widest placeholder:text-[hsl(var(--muted-foreground))] placeholder:tracking-normal"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] rounded-md py-2.5 text-sm font-semibold hover:bg-[hsl(var(--primary))]/90 transition-colors flex items-center justify-center gap-2"
            >
              ورود به داشبورد
            </button>
          </form>
        </div>

        <p className="text-center text-[11px] text-[hsl(var(--muted-foreground))]">
          Unixsee Campaign Gateway — سایه‌فقط — بدون اجرا
        </p>
      </div>
    </div>
  );
}
