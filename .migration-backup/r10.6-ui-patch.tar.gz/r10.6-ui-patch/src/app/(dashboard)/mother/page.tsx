import { DashboardShell } from "@/components/ui/DashboardShell";
import { StatusPill } from "@/components/ui/StatusPill";
import { getMotherNodes } from "@/lib/adapters/server";
import { Network, Cpu, HardDrive, MemoryStick, Clock, MapPin, Bot } from "lucide-react";

export const dynamic = "force-dynamic";

function ProgressBar({ value, color = "bg-[hsl(var(--primary))]" }: { value: number; color?: string }) {
  return (
    <div className="h-1.5 bg-[hsl(var(--muted))] rounded-full overflow-hidden">
      <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${Math.min(value, 100)}%` }} />
    </div>
  );
}

export default async function MotherPage() {
  const nodes = await getMotherNodes();
  return (
    <DashboardShell title="نود‌های مادر" subtitle="کنترلرهای مرکزی شبکه عاملان گیت‌وی">
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "نودهای مادر",   value: nodes.length },
            { label: "عاملان متصل",   value: nodes.reduce((s, n) => s + n.connectedAgents, 0) },
            { label: "نود اصلی فعال", value: nodes.filter(n => n.status === "active").length },
          ].map(s => (
            <div key={s.label} className="card-glass p-3 text-center">
              <p className="text-2xl font-bold">{s.value}</p>
              <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {nodes.map(node => (
            <div key={node.id} className="card-glass p-4 flex flex-col gap-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <Network className="w-4 h-4 text-indigo-400" />
                    <p className="font-semibold text-sm">{node.name}</p>
                  </div>
                  <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">{node.role}</p>
                </div>
                <StatusPill status={node.status} />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-1.5 text-[hsl(var(--muted-foreground))]">
                  <MapPin className="w-3 h-3" /><span className="ltr">{node.region}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[hsl(var(--muted-foreground))]">
                  <Bot className="w-3 h-3" /><span>{node.connectedAgents} عامل</span>
                </div>
                <div className="flex items-center gap-1.5 text-[hsl(var(--muted-foreground))]">
                  <Clock className="w-3 h-3" />
                  <span>تأخیر sync: <span className="ltr">{node.syncLag}</span></span>
                </div>
                <div className="flex items-center gap-1.5 text-[hsl(var(--muted-foreground))]">
                  <Clock className="w-3 h-3" />
                  <span className="ltr text-[10px]">{new Date(node.lastHeartbeat).toLocaleTimeString("fa-IR")}</span>
                </div>
              </div>

              <div className="flex flex-col gap-2.5">
                {[
                  { icon: Cpu,        label: "CPU",          val: node.cpuPercent,     color: node.cpuPercent > 80 ? "bg-red-500" : node.cpuPercent > 60 ? "bg-amber-500" : "bg-emerald-500" },
                  { icon: MemoryStick,label: "RAM",          val: node.memPercent,     color: node.memPercent > 85 ? "bg-red-500" : node.memPercent > 70 ? "bg-amber-500" : "bg-blue-500" },
                  { icon: HardDrive,  label: "ذخیره‌سازی",  val: node.storagePercent, color: "bg-slate-400" },
                ].map(({ icon: Icon, label, val, color }) => (
                  <div key={label} className="flex flex-col gap-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="flex items-center gap-1 text-[hsl(var(--muted-foreground))]"><Icon className="w-3 h-3" />{label}</span>
                      <span className="ltr font-mono">{val}٪</span>
                    </div>
                    <ProgressBar value={val} color={color} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardShell>
  );
}
