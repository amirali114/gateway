/**
 * Production settings — read-only view.
 * "ذخیره تغییرات" button is intentionally disabled per spec:
 * no destructive actions from the browser-side.
 * Production config changes go through server-side Mother API.
 */
import { DashboardShell } from "@/components/ui/DashboardShell";
import { StatusPill } from "@/components/ui/StatusPill";
import { Server, MapPin, Cpu, MemoryStick, AlertTriangle } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/cn";

// These values should come from your existing BASE config (env/storage)
const productionConfig = {
  region:           "ir-teh-1",
  backupRegion:     "eu-west-1",
  dbConnectionPool: 50,
  maxConnections:   10000,
  tlsVersion:       "TLS 1.3",
  logLevel:         "info",
  metricsInterval:  "15s",
  rateLimitDefault: "1000/min",
};

const serviceResources = [
  { name: "gateway-agent",        cpuLimit: "2 vCPU", memLimit: "4GB",  replicas: 3 },
  { name: "mother-core",          cpuLimit: "4 vCPU", memLimit: "16GB", replicas: 1 },
  { name: "php-gateway-runtime",  cpuLimit: "2 vCPU", memLimit: "4GB",  replicas: 2 },
  { name: "policy-sync-agent",    cpuLimit: "1 vCPU", memLimit: "2GB",  replicas: 1 },
  { name: "telemetry-collector",  cpuLimit: "1 vCPU", memLimit: "2GB",  replicas: 1 },
  { name: "audit-collector",      cpuLimit: "1 vCPU", memLimit: "2GB",  replicas: 1 },
];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <h2 className="text-xs font-medium text-[hsl(var(--muted-foreground))] uppercase tracking-wide">{title}</h2>
      {children}
    </div>
  );
}

export default function SettingsProductionPage() {
  return (
    <DashboardShell title="تنظیمات Production" subtitle="پیکربندی محیط تولید — فقط خواندنی">
      <div className="flex flex-col gap-5 max-w-3xl">

        <div className="flex items-center gap-1.5 text-xs text-[hsl(var(--muted-foreground))]">
          <Link href="/settings" className="hover:text-[hsl(var(--foreground))] transition-colors">تنظیمات</Link>
          <span>/</span>
          <span className="text-[hsl(var(--foreground))]">محیط تولید</span>
        </div>

        <div className="bg-amber-500/8 border border-amber-500/20 rounded-lg px-4 py-3 flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <p className="text-xs text-amber-400">
            این داشبورد فقط وضعیت را نمایش می‌دهد. تغییر پیکربندی تولید از طریق API مادر و سرور انجام می‌پذیرد.
          </p>
        </div>

        <Section title="پیکربندی کلی">
          <div className="card-glass overflow-hidden">
            {Object.entries(productionConfig).map(([key, value], i, arr) => (
              <div key={key} className={cn(
                "flex items-center justify-between px-4 py-2.5 hover:bg-[hsl(var(--muted))]/20 transition-colors",
                i !== arr.length - 1 && "border-b border-[hsl(var(--border))]/50"
              )}>
                <span className="text-xs text-[hsl(var(--muted-foreground))] ltr">{key}</span>
                <span className="ltr font-mono text-xs bg-[hsl(var(--muted))]/40 px-2 py-0.5 rounded">{String(value)}</span>
              </div>
            ))}
          </div>
        </Section>

        <Section title="منابع سرویس‌ها">
          <div className="card-glass overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-[hsl(var(--border))] bg-[hsl(var(--muted))]/30">
                  {["سرویس","CPU","RAM","رپلیکا"].map(h => (
                    <th key={h} className="text-right px-4 py-2.5 text-[hsl(var(--muted-foreground))] font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {serviceResources.map(r => (
                  <tr key={r.name} className="border-b border-[hsl(var(--border))]/50 hover:bg-[hsl(var(--muted))]/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Server className="w-3.5 h-3.5 text-[hsl(var(--muted-foreground))]" />
                        <span className="ltr font-mono">{r.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 ltr">
                      <span className="flex items-center gap-1 text-[hsl(var(--muted-foreground))]"><Cpu className="w-3 h-3" />{r.cpuLimit}</span>
                    </td>
                    <td className="px-4 py-3 ltr">
                      <span className="flex items-center gap-1 text-[hsl(var(--muted-foreground))]"><MemoryStick className="w-3 h-3" />{r.memLimit}</span>
                    </td>
                    <td className="px-4 py-3 ltr font-mono">{r.replicas}×</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>

        <Section title="مناطق استقرار">
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "منطقه اصلی",     value: "ir-teh-1 (تهران ۱)",    primary: true,  status: "active" as const },
              { label: "منطقه پشتیبان",  value: "eu-west-1 (اروپای غربی)", primary: false, status: "active" as const },
            ].map(r => (
              <div key={r.label} className={cn("card-glass p-4", r.primary && "border-[hsl(var(--primary))]/20")}>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-[hsl(var(--muted-foreground))]">{r.label}</p>
                  <StatusPill status={r.status} size="sm" />
                </div>
                <p className="ltr font-mono text-sm font-semibold flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[hsl(var(--muted-foreground))]" />{r.value}
                </p>
                {r.primary && <p className="text-[11px] text-[hsl(var(--primary))] mt-1">نود اصلی</p>}
              </div>
            ))}
          </div>
        </Section>

        {/* Actions disabled per spec — no browser-originated production changes */}
        <div className="flex items-center gap-2 pt-1">
          <button
            disabled
            title="تغییرات از طریق API مادر اعمال می‌شوند"
            className="px-4 py-2 bg-[hsl(var(--primary))]/20 text-[hsl(var(--primary))]/50 text-xs rounded-md cursor-not-allowed font-medium border border-[hsl(var(--primary))]/10"
          >
            ذخیره تغییرات (غیرفعال)
          </button>
          <span className="text-[11px] text-[hsl(var(--muted-foreground))]">— عملیات از سمت سرور انجام می‌پذیرد</span>
        </div>
      </div>
    </DashboardShell>
  );
}
