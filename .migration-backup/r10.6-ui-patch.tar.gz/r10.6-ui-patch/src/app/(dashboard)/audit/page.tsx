import { DashboardShell } from "@/components/ui/DashboardShell";
import { getAuditLogs } from "@/lib/adapters/server";
import { AuditView } from "./_components/AuditView";
import { Download } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AuditPage() {
  const logs = await getAuditLogs();
  return (
    <DashboardShell
      title="گزارش حسابرسی"
      subtitle={`${logs.length} رویداد ثبت‌شده`}
      actions={
        <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[hsl(var(--muted))] border border-[hsl(var(--border))] text-xs rounded-md hover:bg-[hsl(var(--muted))]/80 transition-colors">
          <Download className="w-3.5 h-3.5" />
          خروجی CSV
        </button>
      }
    >
      <AuditView logs={logs} />
    </DashboardShell>
  );
}
