"use client";
import type { AlertVM, AlertSeverity } from "@/lib/view-models";
import { StatusPill } from "@/components/ui/StatusPill";
import { Bell, Clock, User, Filter } from "lucide-react";
import { cn } from "@/lib/cn";
import { useState } from "react";

const severityOrder: AlertSeverity[] = ["critical", "high", "medium", "low", "info"];

export function AlertsView({ alerts }: { alerts: AlertVM[] }) {
  const [filterStatus, setFilterStatus] = useState<"all" | "open" | "acknowledged" | "resolved">("all");
  const sorted = [...alerts].sort((a, b) => severityOrder.indexOf(a.severity) - severityOrder.indexOf(b.severity));
  const filtered = filterStatus === "all" ? sorted : sorted.filter(a => a.status === filterStatus);

  const counts = {
    open: alerts.filter(a => a.status === "open").length,
    acknowledged: alerts.filter(a => a.status === "acknowledged").length,
    resolved: alerts.filter(a => a.status === "resolved").length,
    critical: alerts.filter(a => a.severity === "critical").length,
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "باز",        value: counts.open,         color: "text-red-400" },
          { label: "تأییدشده",  value: counts.acknowledged, color: "text-amber-400" },
          { label: "حل‌شده",    value: counts.resolved,     color: "text-emerald-400" },
          { label: "بحرانی",    value: counts.critical,     color: "text-red-500 font-extrabold" },
        ].map(s => (
          <div key={s.label} className="card-glass p-3 text-center">
            <p className={cn("text-2xl font-bold", s.color)}>{s.value}</p>
            <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2">
        <Filter className="w-3.5 h-3.5 text-[hsl(var(--muted-foreground))]" />
        {(["all", "open", "acknowledged", "resolved"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilterStatus(f)}
            className={cn(
              "text-xs px-3 py-1.5 rounded-md border transition-colors",
              filterStatus === f
                ? "bg-[hsl(var(--primary))]/20 border-[hsl(var(--primary))]/40 text-[hsl(var(--primary))]"
                : "border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted))]/50"
            )}
          >
            {f === "all" ? "همه" : f === "open" ? "باز" : f === "acknowledged" ? "تأییدشده" : "حل‌شده"}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-2.5">
        {filtered.map(alert => (
          <div key={alert.id} className={cn(
            "card-glass p-4 flex flex-col gap-3",
            alert.severity === "critical" && alert.status === "open" && "border-red-500/30",
            alert.severity === "high"     && alert.status === "open" && "border-orange-500/20",
          )}>
            <div className="flex items-start gap-3">
              <StatusPill status={alert.severity} />
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{alert.title}</p>
                <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5 leading-relaxed">{alert.message}</p>
              </div>
              <StatusPill status={alert.status} showDot={false} />
            </div>
            <div className="flex flex-wrap items-center gap-4 text-[11px] text-[hsl(var(--muted-foreground))] border-t border-[hsl(var(--border))] pt-2">
              <span className="ltr font-mono bg-[hsl(var(--muted))]/40 px-1.5 py-0.5 rounded">{alert.source}</span>
              {alert.agentId && <span className="ltr text-[hsl(var(--muted-foreground))]">{alert.agentId}</span>}
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span className="ltr">{new Date(alert.createdAt).toLocaleString("fa-IR")}</span>
              </span>
              {alert.acknowledgedBy && (
                <span className="flex items-center gap-1"><User className="w-3 h-3" /><span className="ltr">{alert.acknowledgedBy}</span></span>
              )}
              <span className="ltr text-[10px] text-[hsl(var(--muted-foreground))]/60 mr-auto">{alert.id}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
