import { DashboardShell } from "@/components/ui/DashboardShell";
import { getAlerts } from "@/lib/adapters/server";
import { AlertsView } from "./_components/AlertsView";

export const dynamic = "force-dynamic";

export default async function AlertsPage() {
  const alerts = await getAlerts();
  const open = alerts.filter(a => a.status === "open").length;
  const ack  = alerts.filter(a => a.status === "acknowledged").length;
  const res  = alerts.filter(a => a.status === "resolved").length;
  return (
    <DashboardShell title="هشدارها" subtitle={`${open} باز، ${ack} تأییدشده، ${res} حل‌شده`}>
      <AlertsView alerts={alerts} />
    </DashboardShell>
  );
}
