import { DashboardShell } from "@/components/ui/DashboardShell";
import { RefreshCw, CheckCircle2, Clock } from "lucide-react";

export const dynamic = "force-dynamic";

export default function SyncPage() {
  return (
    <DashboardShell title="همگام‌سازی" subtitle="وضعیت همگام‌سازی پالیسی و پیکربندی با Mother Core">
      <div className="flex flex-col gap-4 max-w-2xl">
        <div className="bg-[hsl(var(--muted))]/30 border border-[hsl(var(--border))] rounded-lg px-4 py-3 flex items-center gap-3">
          <RefreshCw className="w-4 h-4 text-[hsl(var(--muted-foreground))] shrink-0" />
          <p className="text-xs text-[hsl(var(--muted-foreground))]">
            همگام‌سازی به‌صورت خودکار توسط Mother Core انجام می‌پذیرد — سایه‌فقط، بدون اجرا از مرورگر.
          </p>
        </div>

        <div className="card-glass divide-y divide-[hsl(var(--border))]">
          {[
            { label: "همگام‌سازی سیاست‌ها",     status: "sync", lastSync: "—", source: "/v1/policies/default" },
            { label: "همگام‌سازی پیکربندی",     status: "sync", lastSync: "—", source: "/v1/health/report" },
            { label: "همگام‌سازی دروازه‌های کیفیت", status: "sync", lastSync: "—", source: "/v1/release-gates/summary" },
          ].map(item => (
            <div key={item.label} className="flex items-center gap-3 px-4 py-3">
              <RefreshCw className="w-4 h-4 text-[hsl(var(--muted-foreground))] shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{item.label}</p>
                <p className="ltr text-[11px] text-[hsl(var(--muted-foreground))] font-mono mt-0.5">{item.source}</p>
              </div>
              <span className="flex items-center gap-1 text-[11px] text-[hsl(var(--muted-foreground))]">
                <Clock className="w-3 h-3" />{item.lastSync}
              </span>
            </div>
          ))}
        </div>
      </div>
    </DashboardShell>
  );
}
