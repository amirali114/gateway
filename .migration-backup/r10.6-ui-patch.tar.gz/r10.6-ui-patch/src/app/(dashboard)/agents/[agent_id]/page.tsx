import { DashboardShell } from "@/components/ui/DashboardShell";
import { StatusPill } from "@/components/ui/StatusPill";
import { RawJsonDrawer } from "@/components/ui/RawJsonDrawer";
import { getAgent } from "@/lib/adapters/server";
import { MapPin, Clock, Activity, Zap, AlertTriangle, Globe, ArrowRight } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

interface Props { params: Promise<{ agent_id: string }> }

export default async function AgentDetailPage({ params }: Props) {
  const { agent_id } = await params;
  const agent = await getAgent(agent_id);
  if (!agent) notFound();

  return (
    <DashboardShell title={agent.name} subtitle={`شناسه: ${agent.id}`} actions={<StatusPill status={agent.status} size="md" />}>
      <div className="flex flex-col gap-5 max-w-4xl">

        <div className="flex items-center gap-1.5 text-xs text-[hsl(var(--muted-foreground))]">
          <Link href="/agents" className="hover:text-[hsl(var(--foreground))] transition-colors">عاملان</Link>
          <span>/</span>
          <span className="text-[hsl(var(--foreground))]">{agent.name}</span>
        </div>

        <div className="card-glass p-5 flex flex-col gap-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="text-base font-bold">{agent.name}</h2>
              <p className="ltr text-sm text-[hsl(var(--muted-foreground))] font-mono mt-0.5">{agent.id}</p>
            </div>
            <StatusPill status={agent.status} size="md" />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: MapPin, label: "منطقه",       value: agent.region,  ltr: true },
              { icon: Clock,  label: "آپ‌تایم",     value: agent.uptime,  ltr: true },
              { icon: Globe,  label: "نسخه",        value: agent.version, ltr: true },
              { icon: Clock,  label: "آخرین فعالیت", value: new Date(agent.lastSeen).toLocaleString("fa-IR"), ltr: false },
            ].map(({ icon: Icon, label, value, ltr }) => (
              <div key={label} className="bg-[hsl(var(--muted))]/30 rounded p-3">
                <p className="text-[10px] text-[hsl(var(--muted-foreground))] flex items-center gap-1 mb-1">
                  <Icon className="w-3 h-3" />{label}
                </p>
                <p className={`text-sm font-semibold ${ltr ? "ltr" : ""}`}>{value}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-1.5">
            {agent.tags.map(tag => (
              <span key={tag} className="ltr text-[11px] px-2 py-0.5 rounded bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))] border border-[hsl(var(--primary))]/20 font-mono">
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="card-glass p-4 text-center flex flex-col gap-1">
            <Activity className="w-5 h-5 mx-auto text-indigo-400" />
            <p className="text-2xl font-bold mt-1">{agent.requestsPerMin.toLocaleString("fa-IR")}</p>
            <p className="text-xs text-[hsl(var(--muted-foreground))]">درخواست در دقیقه</p>
          </div>
          <div className="card-glass p-4 text-center flex flex-col gap-1">
            <Zap className="w-5 h-5 mx-auto text-amber-400" />
            <p className="text-2xl font-bold mt-1 ltr">{agent.latencyMs}ms</p>
            <p className="text-xs text-[hsl(var(--muted-foreground))]">میانگین تأخیر</p>
          </div>
          <div className={`card-glass p-4 text-center flex flex-col gap-1 ${agent.errorRate > 1 ? "border-red-500/20" : ""}`}>
            <AlertTriangle className={`w-5 h-5 mx-auto ${agent.errorRate > 1 ? "text-red-400" : "text-emerald-400"}`} />
            <p className={`text-2xl font-bold mt-1 ltr ${agent.errorRate > 1 ? "text-red-400" : "text-emerald-400"}`}>{agent.errorRate}٪</p>
            <p className="text-xs text-[hsl(var(--muted-foreground))]">نرخ خطا</p>
          </div>
        </div>

        <div className="card-glass p-4 flex flex-col gap-2">
          <p className="text-xs font-medium text-[hsl(var(--muted-foreground))]">آدرس endpoint</p>
          <p className="ltr text-sm font-mono text-[hsl(var(--primary))] bg-[hsl(var(--muted))]/30 px-3 py-2 rounded-md break-all">{agent.endpoint}</p>
        </div>

        <div className="card-glass p-4 flex flex-col gap-3">
          <p className="text-xs font-medium text-[hsl(var(--muted-foreground))]">متادیتای فنی</p>
          <RawJsonDrawer data={agent.meta} label="متادیتای عامل" />
        </div>

        <RawJsonDrawer data={agent} label="آبجکت کامل عامل" />
      </div>
    </DashboardShell>
  );
}

export function generateNotFound() {
  return (
    <DashboardShell title="عامل یافت نشد">
      <div className="card-glass p-8 text-center text-[hsl(var(--muted-foreground))]">
        <p className="text-sm">عامل مورد نظر یافت نشد.</p>
        <Link href="/agents" className="mt-3 inline-flex items-center gap-1.5 text-xs text-[hsl(var(--primary))] hover:underline">
          <ArrowRight className="w-3.5 h-3.5" />
          بازگشت به فهرست عاملان
        </Link>
      </div>
    </DashboardShell>
  );
}
