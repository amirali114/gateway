import { DashboardShell } from "@/components/ui/DashboardShell";
import { getAgents } from "@/lib/adapters/server";
import { AgentsView } from "./_components/AgentsView";

export const dynamic = "force-dynamic";

export default async function AgentsPage() {
  const agents = await getAgents();
  const total  = agents.length;
  const active = agents.filter(a => a.status === "active").length;
  const issues = agents.filter(a => a.status === "error" || a.status === "degraded").length;
  return (
    <DashboardShell title="عاملان" subtitle={`${total} عامل — ${active} فعال، ${issues} دارای مشکل`}>
      <AgentsView agents={agents} />
    </DashboardShell>
  );
}
