"use client";
import type { GatewayRouteVM } from "@/lib/view-models";
import { StatusPill } from "@/components/ui/StatusPill";
import { Globe, Lock, Unlock, Activity, Zap, Filter } from "lucide-react";
import { cn } from "@/lib/cn";
import { useState } from "react";

const methodColor: Record<string, string> = {
  GET: "text-emerald-400", POST: "text-blue-400", PUT: "text-amber-400",
  DELETE: "text-red-400", PATCH: "text-purple-400",
};

export function GatewayView({ routes }: { routes: GatewayRouteVM[] }) {
  const [filter, setFilter] = useState<"all" | "active" | "inactive" | "shadow">("all");
  const filtered = filter === "all" ? routes : routes.filter(r => r.status === filter);
  const totalRequests = routes.reduce((s, r) => s + r.requestsToday, 0);
  const avgLatency = Math.round(
    routes.filter(r => r.avgLatencyMs > 0).reduce((s, r) => s + r.avgLatencyMs, 0) /
    (routes.filter(r => r.avgLatencyMs > 0).length || 1)
  );

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "کل مسیرها",    value: routes.length,                        color: "" },
          { label: "مسیرهای فعال", value: routes.filter(r => r.status === "active").length, color: "text-emerald-400" },
          { label: "درخواست امروز", value: totalRequests.toLocaleString("fa-IR"), color: "text-indigo-400" },
          { label: "میانگین تأخیر", value: `${avgLatency}ms`,                   color: "text-amber-400" },
        ].map(s => (
          <div key={s.label} className="card-glass p-3 text-center">
            <p className={cn("text-xl font-bold ltr", s.color)}>{s.value}</p>
            <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2">
        <Filter className="w-3.5 h-3.5 text-[hsl(var(--muted-foreground))]" />
        {(["all", "active", "inactive", "shadow"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "text-xs px-3 py-1.5 rounded-md border transition-colors",
              filter === f
                ? "bg-[hsl(var(--primary))]/20 border-[hsl(var(--primary))]/40 text-[hsl(var(--primary))]"
                : "border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))] hover:bg-[hsl(var(--muted))]/50"
            )}
          >
            {f === "all" ? "همه" : f === "active" ? "فعال" : f === "inactive" ? "غیرفعال" : "سایه"}
          </button>
        ))}
      </div>

      <div className="card-glass overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-[hsl(var(--border))] bg-[hsl(var(--muted))]/30">
              {["مسیر","متد","عامل upstream","محدودیت نرخ","احراز هویت","درخواست امروز","تأخیر","وضعیت"].map(h => (
                <th key={h} className="text-right px-4 py-2.5 text-[hsl(var(--muted-foreground))] font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(route => (
              <tr key={route.id} className="border-b border-[hsl(var(--border))]/50 hover:bg-[hsl(var(--muted))]/20 transition-colors">
                <td className="px-4 py-3 ltr font-mono text-[hsl(var(--primary))]">{route.path}</td>
                <td className="px-4 py-3">
                  <span className={cn("ltr font-mono font-bold text-[11px]", methodColor[route.method] ?? "text-[hsl(var(--foreground))]")}>
                    {route.method}
                  </span>
                </td>
                <td className="px-4 py-3 ltr font-mono text-[hsl(var(--muted-foreground))] text-[11px]">{route.upstreamAgent}</td>
                <td className="px-4 py-3 ltr">
                  {route.rateLimit === 0 ? <span className="text-[hsl(var(--muted-foreground))]">بدون محدودیت</span> : `${route.rateLimit}/min`}
                </td>
                <td className="px-4 py-3">
                  {route.authRequired
                    ? <span className="flex items-center gap-1 text-emerald-400"><Lock className="w-3 h-3" />فعال</span>
                    : <span className="flex items-center gap-1 text-[hsl(var(--muted-foreground))]"><Unlock className="w-3 h-3" />عمومی</span>}
                </td>
                <td className="px-4 py-3 ltr">
                  <span className="flex items-center gap-1"><Activity className="w-3 h-3 text-[hsl(var(--muted-foreground))]" />{route.requestsToday.toLocaleString()}</span>
                </td>
                <td className="px-4 py-3 ltr">
                  {route.avgLatencyMs > 0
                    ? <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-[hsl(var(--muted-foreground))]" />{route.avgLatencyMs}ms</span>
                    : <span className="text-[hsl(var(--muted-foreground))]">—</span>}
                </td>
                <td className="px-4 py-3"><StatusPill status={route.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
