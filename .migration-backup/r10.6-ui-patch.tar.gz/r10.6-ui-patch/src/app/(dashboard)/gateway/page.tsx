import { DashboardShell } from "@/components/ui/DashboardShell";
import { getGatewayRoutes } from "@/lib/adapters/server";
import { GatewayView } from "./_components/GatewayView";

export const dynamic = "force-dynamic";

export default async function GatewayPage() {
  const routes = await getGatewayRoutes();
  const totalRequests = routes.reduce((s, r) => s + r.requestsToday, 0);
  return (
    <DashboardShell
      title="مدیریت دروازه"
      subtitle={`${routes.length} مسیر — ${totalRequests.toLocaleString("fa-IR")} درخواست امروز`}
    >
      <GatewayView routes={routes} />
    </DashboardShell>
  );
}
