/**
 * Dashboard layout — wraps all authenticated routes.
 *
 * INTEGRATION:
 * 1. Replace the TODO session read with your existing session/auth guard.
 * 2. Replace the TODO alert count with a real call to getAlerts() or a cached summary.
 * 3. If your BASE project already has a layout with session guard, keep that guard
 *    and only adopt the DashboardShell visual wrapper from here.
 *
 * This layout is intentionally a Server Component.
 * Sidebar and Topbar are Client Components — they receive server-read data as props.
 */
import { DashboardShell } from "@/components/ui/DashboardShell";

interface LayoutProps {
  children: React.ReactNode;
  params: Record<string, string>;
}

export default async function DashboardLayout({ children }: LayoutProps) {
  // TODO: Replace with your existing session guard:
  //   const session = await getSession()
  //   if (!session) redirect("/login")
  //
  // TODO: Replace with a real open-alert count (lightweight, cached):
  //   const alertCount = await getOpenAlertCount()
  //
  // Example currentUser shape (read from your existing RBAC session):
  //   const currentUser = { name: session.user.name, email: session.user.email, role: session.user.role }

  const alertCount = 0;       // replace with real value
  const currentUser = undefined; // replace with session.user

  return (
    <DashboardShell
      title=""
      alertCount={alertCount}
      currentUser={currentUser}
    >
      {children}
    </DashboardShell>
  );
}
