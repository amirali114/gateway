"use client";
import type { DiagnosticCheckVM } from "@/lib/view-models";
import { StatusPill } from "@/components/ui/StatusPill";
import { CheckCircle2, XCircle, AlertCircle, SkipForward, Clock, RefreshCw } from "lucide-react";
import { cn } from "@/lib/cn";
import { useState } from "react";

const icons = { pass: CheckCircle2, warn: AlertCircle, fail: XCircle, skip: SkipForward };
const iconColors = { pass: "text-emerald-400", warn: "text-amber-400", fail: "text-red-400", skip: "text-slate-500" };

export function DiagnosticsClient({ initialChecks }: { initialChecks: DiagnosticCheckVM[] }) {
  const [checks] = useState(initialChecks);

  const counts = {
    pass: checks.filter(c => c.status === "pass").length,
    warn: checks.filter(c => c.status === "warn").length,
    fail: checks.filter(c => c.status === "fail").length,
  };
  const overall = counts.fail > 0 ? "fail" : counts.warn > 0 ? "warn" : "pass";

  return (
    <div className="flex flex-col gap-4 max-w-3xl">
      <div className={cn(
        "card-glass p-4 flex items-center gap-4",
        overall === "fail" && "border-red-500/30",
        overall === "warn" && "border-amber-500/30",
        overall === "pass" && "border-emerald-500/20",
      )}>
        <div className={cn(
          "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
          overall === "fail" ? "bg-red-500/20" : overall === "warn" ? "bg-amber-500/20" : "bg-emerald-500/20"
        )}>
          {overall === "pass" ? <CheckCircle2 className="w-5 h-5 text-emerald-400" />
           : overall === "warn" ? <AlertCircle className="w-5 h-5 text-amber-400" />
           : <XCircle className="w-5 h-5 text-red-400" />}
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold">
            {overall === "pass" ? "تمام سیستم‌ها سالم هستند"
             : overall === "warn" ? "برخی هشدارها نیاز به توجه دارند"
             : "خرابی‌هایی در سیستم وجود دارد"}
          </p>
          <p className="text-xs text-[hsl(var(--muted-foreground))] mt-0.5">
            {counts.pass} سالم، {counts.warn} هشدار، {counts.fail} خطا
          </p>
        </div>
        <div className="flex gap-3 text-xs">
          {[
            { key: "pass", label: "سالم",  color: "text-emerald-400" },
            { key: "warn", label: "هشدار", color: "text-amber-400" },
            { key: "fail", label: "خطا",   color: "text-red-400" },
          ].map(({ key, label, color }) => (
            <div key={key} className="text-center">
              <p className={cn("text-lg font-bold", color)}>{counts[key as keyof typeof counts]}</p>
              <p className="text-[hsl(var(--muted-foreground))] text-[10px]">{label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="card-glass overflow-hidden">
        {checks.map((check, i) => {
          const Icon = icons[check.status];
          return (
            <div key={check.id} className={cn(
              "flex items-center gap-3 px-4 py-3 hover:bg-[hsl(var(--muted))]/20 transition-colors",
              i !== checks.length - 1 && "border-b border-[hsl(var(--border))]/50"
            )}>
              <Icon className={cn("w-4 h-4 shrink-0", iconColors[check.status])} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{check.name}</p>
                <p className={cn(
                  "text-xs mt-0.5",
                  check.status === "fail" ? "text-red-400" : check.status === "warn" ? "text-amber-400" : "text-[hsl(var(--muted-foreground))]"
                )}>{check.message}</p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                {check.latencyMs !== undefined && (
                  <span className="ltr text-[11px] text-[hsl(var(--muted-foreground))] flex items-center gap-1">
                    <Clock className="w-3 h-3" />{check.latencyMs}ms
                  </span>
                )}
                <span className="ltr text-[10px] font-mono text-[hsl(var(--muted-foreground))] bg-[hsl(var(--muted))]/40 px-1.5 py-0.5 rounded">{check.component}</span>
                <StatusPill status={check.status} showDot={false} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
