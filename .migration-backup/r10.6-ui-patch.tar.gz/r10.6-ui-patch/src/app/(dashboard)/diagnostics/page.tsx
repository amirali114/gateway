import { DashboardShell } from "@/components/ui/DashboardShell";
import { getDiagnostics } from "@/lib/adapters/server";
import { DiagnosticsClient } from "./_components/DiagnosticsClient";

export const dynamic = "force-dynamic";

export default async function DiagnosticsPage() {
  const checks = await getDiagnostics();
  return (
    <DashboardShell title="تشخیص سیستم" subtitle="بررسی سلامت اجزای سیستم">
      <DiagnosticsClient initialChecks={checks} />
    </DashboardShell>
  );
}
