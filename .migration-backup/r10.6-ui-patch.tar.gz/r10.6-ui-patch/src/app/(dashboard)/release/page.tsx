/**
 * Release gates page — read-only view of release gates from Mother API.
 * Actions (continue rollout / pause / rollback) are DISABLED per spec:
 * these are shadow-only — no enforcement, no remote command.
 */
import { DashboardShell } from "@/components/ui/DashboardShell";
import { ReleaseGatePanel } from "@/components/ui/ReleaseGatePanel";
import { StatusPill } from "@/components/ui/StatusPill";
import { getActiveRelease, getReleaseHistory } from "@/lib/adapters/server";
import { GitBranch } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ReleasePage() {
  const [release, history] = await Promise.all([
    getActiveRelease(),
    getReleaseHistory(),
  ]);

  return (
    <DashboardShell title="مدیریت انتشار" subtitle="دروازه‌های انتشار — سایه‌فقط، بدون اجرا">
      <div className="flex flex-col gap-5 max-w-4xl">

        <div className="bg-amber-500/8 border border-amber-500/20 rounded-lg px-4 py-3 flex items-center gap-3">
          <span className="text-xs text-amber-400">
            این داشبورد فقط وضعیت را نمایش می‌دهد — هیچ اقدامی از مرورگر اجرا نمی‌شود. عملیات انتشار از سمت سرور و API مادر انجام می‌پذیرد.
          </span>
        </div>

        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
            انتشار جاری
          </h2>
          {release ? (
            <ReleaseGatePanel release={release} />
          ) : (
            <div className="card-glass p-8 text-center text-[hsl(var(--muted-foreground))] text-sm">
              هیچ انتشار فعالی وجود ندارد
            </div>
          )}
        </div>

        <div className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">تاریخچه انتشارها</h2>
          <div className="card-glass overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-[hsl(var(--border))] bg-[hsl(var(--muted))]/30">
                  <th className="text-right px-4 py-2.5 text-[hsl(var(--muted-foreground))] font-medium">نام</th>
                  <th className="text-right px-4 py-2.5 text-[hsl(var(--muted-foreground))] font-medium">نسخه</th>
                  <th className="text-right px-4 py-2.5 text-[hsl(var(--muted-foreground))] font-medium">وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {history.map(r => (
                  <tr key={r.id} className="border-b border-[hsl(var(--border))]/50 hover:bg-[hsl(var(--muted))]/20 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <GitBranch className="w-3.5 h-3.5 text-[hsl(var(--muted-foreground))]" />
                        <span className="font-medium">{r.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 ltr font-mono text-[hsl(var(--primary))]">{r.version}</td>
                    <td className="px-4 py-3"><StatusPill status={r.stage} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardShell>
  );
}
