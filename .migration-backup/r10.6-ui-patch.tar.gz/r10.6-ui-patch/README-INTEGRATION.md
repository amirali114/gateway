# Unixsee Campaign Gateway — r10.6 UI Patch

Visual layer patch for the Next.js App Router dashboard.
Converts the Replit design into BASE-compatible server components.

## What this patch contains

```
src/
  app/
    globals.css                          ← CSS variables + RTL + utilities
    layout.tsx                           ← Root layout (Vazirmatn via next/font, RTL html)
    (dashboard)/
      layout.tsx                         ← Dashboard shell wrapper (reads session here)
      page.tsx                           ← Dashboard overview (server component)
      agents/
        page.tsx                         ← Agent list (server → AgentsView client)
        _components/AgentsView.tsx       ← Filter/search (client)
        [agent_id]/page.tsx              ← Agent detail (server)
      release/page.tsx                   ← Release gates view (read-only, no actions)
      mother/page.tsx                    ← Mother node cluster (server)
      diagnostics/
        page.tsx                         ← Diagnostics (server)
        _components/DiagnosticsClient.tsx
      gateway/
        page.tsx                         ← Gateway routes (server → GatewayView client)
        _components/GatewayView.tsx      ← Filter (client)
      policy/page.tsx                    ← Policy list (server)
      alerts/
        page.tsx                         ← Alerts (server → AlertsView client)
        _components/AlertsView.tsx       ← Filter (client)
      users/page.tsx                     ← User list (server)
      audit/
        page.tsx                         ← Audit log (server → AuditView client)
        _components/AuditView.tsx        ← Expand/collapse (client)
      settings/
        page.tsx                         ← Settings hub (server)
        production/page.tsx              ← Production config (read-only, save disabled)
      sync/page.tsx                      ← Policy sync status (server)
    login/page.tsx                       ← Login form (connects to your actions.ts)
  components/ui/
    DashboardShell.tsx                   ← Server component wrapper
    Sidebar.tsx                          ← Client ("use client", usePathname)
    Topbar.tsx                           ← Client ("use client", useState)
    KpiCard.tsx                          ← Server component
    StatusPill.tsx                       ← Server component
    AgentCard.tsx                        ← Server component
    ReleaseGatePanel.tsx                 ← Server component
    RawJsonDrawer.tsx                    ← Client ("use client", useState)
  lib/
    cn.ts                                ← className utility (clsx + tailwind-merge)
    view-models.ts                       ← TypeScript interfaces for all data
    adapters/server.ts                   ← Server-side adapter stubs (fill these in)
```

## Integration steps

### 1. Merge CSS
Copy `src/app/globals.css` into your existing `app/globals.css`.
- Remove the existing `@import url('https://fonts.googleapis.com/...')` line if present.
- Font is now loaded via `next/font/google` in `layout.tsx` (self-hosted at runtime).

### 2. Merge root layout
Update your `app/layout.tsx` to include the `Vazirmatn` font setup from this patch's `layout.tsx`.
Add `dir="rtl"` and `lang="fa"` to the `<html>` element.

### 3. Install dependencies
```bash
npm install clsx tailwind-merge lucide-react
```
These are likely already present in your BASE project.

### 4. Copy components
Copy `src/components/ui/` into your project's component directory.
Update the import alias `@/components/ui/` and `@/lib/` to match your project's tsconfig paths.

### 5. Fill in the adapters
Open `src/lib/adapters/server.ts`.
Each function has a comment showing exactly which Mother API endpoint to call.
Replace the `throw new Error(...)` stubs with calls to your existing Mother API client.

Example (getAgents):
```ts
export async function getAgents(): Promise<AgentVM[]> {
  const raw = await motherClient.get("/v1/agents")
  return raw.agents.map(normalizeAgent)
}
```

### 6. Wire the dashboard layout to your session
Open `src/app/(dashboard)/layout.tsx`.
Replace the TODO comments with your existing session guard:
```ts
const session = await getSession()
if (!session) redirect("/login")
const alertCount = await getOpenAlertCount()
const currentUser = { name: session.user.name, email: session.user.email, role: session.user.role }
```

### 7. Wire the login form
In `src/app/login/page.tsx`, replace the `<form action="/login">` with your existing Server Action:
```tsx
import { loginAction } from "@/app/login/actions"
// ...
<form action={loginAction}>
```

### 8. Keep BASE routes intact
- Do NOT remove your existing `app/login/actions.ts`
- Do NOT remove your existing `app/logout/route.ts`
- Do NOT change your existing RBAC middleware
- Do NOT change your existing Mother API client

## Absolute rules preserved

- Mother base URL stays server-side only
- No management token sent to browser
- No enforcement actions from browser
- Rollback / pause / continue rollout buttons removed (disabled where shown)
- "ذخیره تغییرات" on production settings is disabled
- Font served via next/font (no Google CDN at runtime)
- All UI text Persian RTL; technical values (IDs, paths, tokens) in `.ltr` class
- Raw JSON only inside `RawJsonDrawer` (collapsible, never on main screen)

## Content corrections applied

| Old (Replit demo) | New (Campaign Gateway) |
|---|---|
| inference-worker | gateway-agent |
| model-manager | mother-core |
| guardrail-validator | policy-sync-agent |
| embedding-service | telemetry-collector |
| GPU | — |
| canary deployment | shadow-only release |
| canaryMetrics | shadowMetrics |

## Real API sources (server-side only)

```
GET /healthz                   → getDiagnostics()
GET /readyz                    → getDiagnostics()
GET /v1/storage/status         → getDiagnostics()
GET /v1/health/report          → getMotherNodes(), getDiagnostics()
GET /v1/release-gates          → getActiveRelease(), getReleaseHistory()
GET /v1/release-gates/summary  → getDashboard()
GET /v1/agents                 → getAgents(), getAgent()
GET /v1/policies/default       → getPolicies()
GET /v1/alerts/summary         → getAlerts()
```
