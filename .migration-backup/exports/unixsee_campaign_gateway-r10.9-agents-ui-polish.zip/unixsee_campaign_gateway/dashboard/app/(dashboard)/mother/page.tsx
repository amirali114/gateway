import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherDiagnosticsSummary, getMotherHealth, getMotherPolicy, getMotherReady, motherBaseUrl, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

export default async function MotherPage() {
  await requirePermission("settings.view");
  const [healthResult, readyResult, policyResult, summaryResult] = await Promise.all([getMotherHealth(), getMotherReady(), getMotherPolicy("default"), getMotherDiagnosticsSummary()]);
  const health = read(healthResult); const ready = read(readyResult); const policy = read(policyResult)?.policy; const summary = read(summaryResult)?.summary;
  return (
    <>
      <PageHeader eyebrow="Core" title="Mother Core" description="Read-only status for the local Mother API. The management token stays server-side only." />
      <div className="grid kpis">
        <KpiCard title="Health" value={<StatusPill value={health?.ok ? "healthy" : "unavailable"} />} hint={valueOrDash(health?.service)} icon="◎" />
        <KpiCard title="Ready" value={<StatusPill value={ready?.ok ? "ready" : "not-ready"} />} hint={valueOrDash(ready?.storage)} icon="✓" />
        <KpiCard title="Mother URL" value={<span className="mono">{motherBaseUrl}</span>} hint="server-side only" icon="↔" />
        <KpiCard title="Registered agents" value={summary?.total_agents ?? 0} icon="◉" />
      </div>
      <SectionCard title="Default policy"><table className="kv"><tbody><tr><th>Policy ID</th><td className="mono">{valueOrDash(policy?.id)}</td></tr><tr><th>Profile</th><td className="mono">{valueOrDash(policy?.profile_id)}</td></tr><tr><th>Version</th><td>{valueOrDash(policy?.version)}</td></tr><tr><th>Source</th><td>{valueOrDash(policy?.source)}</td></tr></tbody></table></SectionCard>
      <SectionCard title="Safety model"><ul className="checklist"><li>Dashboard uses server-side Mother API calls only.</li><li>Browser never receives the Mother management token.</li><li>Agents remain shadow-only; PHP Gateway is the runtime source.</li><li>No enforcement or remote command is available in this dashboard.</li></ul></SectionCard>
      <RawJsonDrawer data={{ healthResult, readyResult, policyResult, summaryResult }} title="Raw Mother payloads" />
    </>
  );
}
