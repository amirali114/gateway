import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherAlertSummary, getMotherAlerts, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

export default async function AlertsPage() {
  await requirePermission("alerts.view");
  const [summaryResult, activeResult, historyResult] = await Promise.all([getMotherAlertSummary(), getMotherAlerts({ status: "active", limit: 200 }), getMotherAlerts({ limit: 100 })]);
  const summary = read(summaryResult);
  const active = read(activeResult)?.alerts || [];
  const history = read(historyResult)?.alerts || [];
  return (
    <>
      <PageHeader eyebrow="Alert Center" title="Alerts" description="Internal alerts with safe metadata. Management actions are intentionally not exposed by this visual release." />
      <div className="grid kpis"><KpiCard title="Active" value={summary?.active_total ?? active.length} icon="!" /><KpiCard title="Critical" value={summary?.critical ?? 0} icon="×" tone={(summary?.critical || 0) > 0 ? "danger" : "success"} /><KpiCard title="Warn" value={summary?.warn ?? 0} icon="!" tone={(summary?.warn || 0) > 0 ? "warning" : "success"} /><KpiCard title="Muted" value={summary?.muted ?? 0} icon="◌" /><KpiCard title="Resolved 24h" value={summary?.resolved_24h ?? 0} icon="✓" /></div>
      <SectionCard title="Active alerts" description="Duplicate events are grouped by Mother fingerprints.">
        {activeResult.ok ? active.length ? <DataTable><thead><tr><th>Severity</th><th>Status</th><th>Scope</th><th>Agent</th><th>Title</th><th>First seen</th><th>Last seen</th><th>Count</th></tr></thead><tbody>{active.map((a) => <tr key={a.id || a.fingerprint}><td><StatusPill value={a.severity || "info"} /></td><td><StatusPill value={a.status || "active"} /></td><td>{valueOrDash(a.scope)}</td><td className="mono">{valueOrDash(a.agent_id)}</td><td>{valueOrDash(a.title)}</td><td className="mono">{valueOrDash(a.first_seen_at)}</td><td className="mono">{valueOrDash(a.last_seen_at)}</td><td>{valueOrDash(a.occurrence_count)}</td></tr>)}</tbody></DataTable> : <EmptyState title="No active alerts" description="Telemetry, storage, and rollout issues will appear here." /> : <ErrorState error={activeResult.error} />}
      </SectionCard>
      <RawJsonDrawer data={{ summaryResult, history: history.slice(0, 20) }} title="Raw alert payloads" />
    </>
  );
}
