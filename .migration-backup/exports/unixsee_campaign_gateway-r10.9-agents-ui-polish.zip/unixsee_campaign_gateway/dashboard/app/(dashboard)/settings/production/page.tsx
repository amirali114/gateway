import { DataTable } from "../../../../components/DataTable";
import { KpiCard } from "../../../../components/KpiCard";
import { PageHeader } from "../../../../components/PageHeader";
import { RawJsonDrawer } from "../../../../components/RawJsonDrawer";
import { SectionCard } from "../../../../components/SectionCard";
import { StatusPill } from "../../../../components/StatusPill";
import { getMotherAgents, getMotherDiagnosticsSummary, getMotherHealthReport, getMotherStorageStatus, read, valueOrDash } from "../../../../lib/api";
import { dashboardSecuritySummary, requirePermission } from "../../../../lib/auth";

export const dynamic = "force-dynamic";

function ok(v: boolean | undefined) { return <StatusPill value={v ? "pass" : "unknown"} />; }
export default async function ProductionReadinessPage() {
  await requirePermission("settings.view");
  const security = await dashboardSecuritySummary();
  const [storageResult, summaryResult, agentsResult, reportResult] = await Promise.all([getMotherStorageStatus(), getMotherDiagnosticsSummary(), getMotherAgents(), getMotherHealthReport()]);
  const storage = read(storageResult); const summary = read(summaryResult)?.summary; const agents = read(agentsResult)?.agents || [];
  const rows = [
    ["Dashboard bind", "Local-only 127.0.0.1 behind SSH tunnel or trusted proxy", true],
    ["Mother token", "Configured server-side; never delivered to the browser", security.management_token_configured],
    ["Storage", "Mother storage path is writable", Boolean(storage?.writable)],
    ["Agents", "At least one Agent registered for production-like rollout", agents.length > 0],
    ["Telemetry", "Fresh telemetry exists for at least one Agent", (summary?.telemetry_fresh || 0) > 0],
    ["Enforcement", "No enforcement in this controlled beta", true],
    ["Remote command", "No remote command capability exposed", true]
  ] as const;
  return (
    <>
      <PageHeader eyebrow="Controlled rollout" title="Production Readiness" description="Operational checklist for staged rollout. This page is read-only and does not perform deployment actions." />
      <div className="grid kpis"><KpiCard title="Storage" value={ok(Boolean(storage?.writable))} icon="▣" /><KpiCard title="Agents" value={agents.length} icon="◉" /><KpiCard title="Fresh telemetry" value={summary?.telemetry_fresh ?? 0} icon="⌁" /><KpiCard title="Remote commands" value={<StatusPill tone="success">none</StatusPill>} icon="✓" /></div>
      <SectionCard title="Readiness checklist"><DataTable><thead><tr><th>Check</th><th>Evidence</th><th>Status</th></tr></thead><tbody>{rows.map(([name, evidence, pass]) => <tr key={name}><td>{name}</td><td>{evidence}</td><td>{ok(pass)}</td></tr>)}</tbody></DataTable></SectionCard>
      <RawJsonDrawer data={{ security, storageResult, summaryResult, agentsResult, reportResult }} title="Raw readiness payload" />
    </>
  );
}
