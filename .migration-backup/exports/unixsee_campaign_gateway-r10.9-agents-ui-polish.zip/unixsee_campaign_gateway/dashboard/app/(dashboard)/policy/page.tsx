import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherPolicies, getMotherPolicy, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

export default async function PolicyPage() {
  await requirePermission("policy.view");
  const [policiesResult, defaultResult] = await Promise.all([getMotherPolicies(), getMotherPolicy("default")]);
  const policies = read(policiesResult)?.policies || [];
  const defaultPolicy = read(defaultResult)?.policy;
  return (
    <>
      <PageHeader eyebrow="Policy" title="Policy Sync" description="Read-only policy catalog from Mother. Policy assignment is controlled through safe Mother APIs only." actions={<a className="button-link button-secondary" href="/gateway">Gateway control</a>} />
      <SectionCard title="Default policy"><table className="kv"><tbody><tr><th>ID</th><td className="mono">{valueOrDash(defaultPolicy?.id)}</td></tr><tr><th>Profile ID</th><td className="mono">{valueOrDash(defaultPolicy?.profile_id)}</td></tr><tr><th>Version</th><td>{valueOrDash(defaultPolicy?.version)}</td></tr><tr><th>Source</th><td>{valueOrDash(defaultPolicy?.source)}</td></tr><tr><th>Default</th><td><StatusPill value={defaultPolicy?.is_default ? "active" : "unknown"} /></td></tr></tbody></table></SectionCard>
      <SectionCard title="Policy catalog">
        {policiesResult.ok ? policies.length ? <DataTable><thead><tr><th>ID</th><th>Profile</th><th>Version</th><th>Source</th><th>Default</th></tr></thead><tbody>{policies.map((p) => <tr key={p.id || p.profile_id}><td className="mono">{valueOrDash(p.id)}</td><td className="mono">{valueOrDash(p.profile_id)}</td><td>{valueOrDash(p.version)}</td><td>{valueOrDash(p.source)}</td><td><StatusPill value={p.is_default ? "active" : "inactive"} /></td></tr>)}</tbody></DataTable> : <EmptyState title="No policies returned" /> : <ErrorState error={policiesResult.error} />}
      </SectionCard>
      <RawJsonDrawer data={{ policiesResult, defaultResult }} title="Raw policy payloads" />
    </>
  );
}
