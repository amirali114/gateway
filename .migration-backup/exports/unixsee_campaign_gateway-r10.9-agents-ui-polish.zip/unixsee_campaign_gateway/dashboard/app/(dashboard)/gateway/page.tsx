import { AgentSelector } from "../../../components/AgentSelector";
import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { asRecord, getMotherAgentConfig, getMotherAgentConfigDiff, getMotherAgentConfigVersions, getMotherAgents, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";
type Props = { searchParams?: Promise<{ agent_id?: string }> };
function configFrom(record: unknown) { const r = asRecord(record); return asRecord(r.config); }

export default async function GatewayPage({ searchParams }: Props) {
  await requirePermission("gateway.view");
  const sp = searchParams ? await searchParams : {};
  const agentsResult = await getMotherAgents();
  const agents = read(agentsResult)?.agents || [];
  const selectedAgent = sp.agent_id || agents[0]?.agent_id || "";
  const [cfgResult, diffResult, versionsResult] = selectedAgent ? await Promise.all([getMotherAgentConfig(selectedAgent), getMotherAgentConfigDiff(selectedAgent), getMotherAgentConfigVersions(selectedAgent)]) : [undefined, undefined, undefined] as const;
  const activeRecord = asRecord(read(cfgResult!)?.active_config);
  const draftRecord = asRecord(read(cfgResult!)?.draft_config);
  const activeConfig = configFrom(activeRecord);
  const versions = read(versionsResult!)?.versions || [];
  return (
    <>
      <PageHeader eyebrow="Gateway" title="Gateway Control" description="Safe read-only control-plane view. Write/publish/rollback actions are not exposed in this visual release." actions={<StatusPill tone="blue">shadow-only</StatusPill>} />
      <SectionCard title="Select agent"><AgentSelector agents={agents} selectedAgentId={selectedAgent} basePath="/gateway" /></SectionCard>
      {selectedAgent ? <>
        <div className="grid kpis" style={{ marginTop: 14 }}><KpiCard title="Agent" value={<span className="mono">{selectedAgent}</span>} icon="◉" /><KpiCard title="Active version" value={valueOrDash(activeRecord.version)} icon="▣" /><KpiCard title="Draft version" value={valueOrDash(draftRecord.version)} icon="□" /><KpiCard title="Dirty" value={<StatusPill value={Boolean(read(diffResult!)?.diff?.dirty)} />} icon="!" /></div>
        <div className="grid two" style={{ marginTop: 14 }}><SectionCard title="Active config"><RawJsonDrawer data={activeConfig} title="Active config JSON" /></SectionCard><SectionCard title="Draft diff"><RawJsonDrawer data={read(diffResult!)?.diff || diffResult} title="Diff JSON" /></SectionCard></div>
        <SectionCard title="Config versions" description="Rollback is intentionally not exposed here.">{versions.length ? <DataTable><thead><tr><th>Version</th><th>Status</th><th>Hash</th><th>Published</th><th>Source</th></tr></thead><tbody>{versions.map((v) => <tr key={`${v.version}-${v.config_hash}`}><td>{valueOrDash(v.version)}</td><td><StatusPill value={v.status || "unknown"} /></td><td className="mono">{valueOrDash(v.config_hash)}</td><td className="mono">{valueOrDash(v.published_at)}</td><td>{valueOrDash(v.source)}</td></tr>)}</tbody></DataTable> : <EmptyState title="No config versions" />}</SectionCard>
      </> : agentsResult.ok ? <EmptyState title="No agent selected" description="Register an Agent first, then return to this page." /> : <ErrorState error={agentsResult.error} />}
    </>
  );
}
