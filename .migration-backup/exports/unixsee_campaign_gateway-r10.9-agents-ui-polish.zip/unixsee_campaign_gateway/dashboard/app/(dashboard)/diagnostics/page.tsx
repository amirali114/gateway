import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherAgents, getMotherAlertSummary, getMotherDiagnosticsSummary, getMotherHealth, getMotherHealthReport, getMotherReady, getMotherStorageStatus, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";
function pct(value: unknown): string { const n = Number(value || 0); return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}%` : "—"; }

export default async function DiagnosticsPage() {
  await requirePermission("diagnostics.view");
  const [healthResult, readyResult, agentsResult, summaryResult, storageResult, alertsResult, reportResult] = await Promise.all([getMotherHealth(), getMotherReady(), getMotherAgents(), getMotherDiagnosticsSummary(), getMotherStorageStatus(), getMotherAlertSummary(), getMotherHealthReport()]);
  const summary = read(summaryResult)?.summary;
  const agents = read(agentsResult)?.agents || [];
  const alerts = read(alertsResult);
  return (
    <>
      <PageHeader eyebrow="Observability" title="Diagnostics" description="Safe operational summary from Mother. Secrets, tokens, and cookies are not displayed." />
      <div className="grid kpis">
        <KpiCard title="Mother health" value={<StatusPill value={read(healthResult)?.ok ? "healthy" : "unavailable"} />} icon="◎" />
        <KpiCard title="Mother ready" value={<StatusPill value={read(readyResult)?.ok ? "ready" : "not-ready"} />} hint={valueOrDash(read(readyResult)?.storage)} icon="✓" />
        <KpiCard title="Storage" value={<StatusPill value={read(storageResult)?.engine || "unknown"} />} hint={read(storageResult)?.writable ? "writable" : "not writable or unknown"} icon="▣" />
        <KpiCard title="Match rate" value={pct(summary?.average_match_rate)} icon="⌁" />
        <KpiCard title="Fresh/stale/missing" value={`${summary?.telemetry_fresh ?? 0}/${summary?.telemetry_stale ?? 0}/${summary?.telemetry_missing ?? 0}`} icon="◉" />
        <KpiCard title="Critical alerts" value={alerts?.critical ?? 0} icon="!" tone={(alerts?.critical || 0) > 0 ? "danger" : "success"} />
      </div>
      <SectionCard title="Agent diagnostics snapshot">
        {agents.length ? <DataTable><thead><tr><th>Agent</th><th>Status</th><th>Telemetry</th><th>Received</th><th>Mismatched</th><th>Last seen</th></tr></thead><tbody>{agents.map((a) => <tr key={a.agent_id || Math.random()}><td className="mono">{valueOrDash(a.agent_id)}</td><td><StatusPill value={a.status || "unknown"} /></td><td><StatusPill value={a.telemetry_status || "missing"} /></td><td>{valueOrDash(a.last_received)}</td><td>{valueOrDash(a.last_mismatched)}</td><td className="mono">{valueOrDash(a.last_seen_at)}</td></tr>)}</tbody></DataTable> : <EmptyState title="No agent diagnostics yet" />}
      </SectionCard>
      <RawJsonDrawer data={{ healthResult, readyResult, storageResult, summaryResult, alertsResult, reportResult }} title="Raw diagnostic payloads" />
    </>
  );
}
