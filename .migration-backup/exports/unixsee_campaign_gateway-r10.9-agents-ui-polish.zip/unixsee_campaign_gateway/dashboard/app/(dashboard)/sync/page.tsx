import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherAgents, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

export default async function SyncPage() {
  await requirePermission("agents.view");
  const agentsResult = await getMotherAgents();
  const agents = read(agentsResult)?.agents || [];
  return (
    <>
      <PageHeader eyebrow="Sync" title="Policy Sync" description="Read-only sync visibility for Agent pull and config acknowledgement. No push to Agent is available." />
      <SectionCard title="Agent sync states">
        {agents.length ? <DataTable><thead><tr><th>Agent</th><th>Policy pull</th><th>Policy version</th><th>Config delivered</th><th>Config acknowledged</th><th>Sync status</th></tr></thead><tbody>{agents.map((a) => <tr key={a.agent_id || Math.random()}><td className="mono">{valueOrDash(a.agent_id)}</td><td className="mono">{valueOrDash(a.last_policy_pull_at)}</td><td>{valueOrDash(a.last_policy_version)}</td><td className="mono">{valueOrDash(a.last_config_delivered_at)}</td><td className="mono">{valueOrDash(a.last_config_ack_at)}</td><td><StatusPill value={a.config_sync_status || "unknown"} /></td></tr>)}</tbody></DataTable> : <EmptyState title="No sync data" description="Agents will appear after policy pull or telemetry push." />}
      </SectionCard>
      <RawJsonDrawer data={agentsResult.ok ? agentsResult.data : agentsResult} title="Raw sync payload" />
    </>
  );
}
