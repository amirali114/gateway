import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { ReleaseGatePanel, ReleaseSummaryStrip } from "../../../components/ReleaseGatePanel";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherAlerts, getMotherHealthReport, getMotherReleaseGates, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";
import { releaseLabel } from "../../../lib/dashboard/mappers";

export const dynamic = "force-dynamic";

export default async function ReleaseReadinessPage() {
  await requirePermission("release.view");
  const [gatesResult, healthReportResult, alertsResult] = await Promise.all([getMotherReleaseGates(), getMotherHealthReport(), getMotherAlerts({ status: "active", limit: 20 })]);
  const gatesData = read(gatesResult);
  const gates = gatesData?.gates || [];
  const summary = gatesData?.summary;
  const alerts = read(alertsResult)?.alerts || [];
  return (
    <>
      <PageHeader eyebrow="Controlled beta" title="Release Readiness" description="Operational go/no-go evidence. This page does not enable enforcement, rollback, or remote command execution." actions={<StatusPill value={releaseLabel(summary)} />} />
      <ReleaseSummaryStrip summary={summary} />
      <SectionCard title="Release gates" description="Grouped evidence returned by Mother.">{gatesResult.ok ? <ReleaseGatePanel gates={gates} /> : <ErrorState error={gatesResult.error} />}</SectionCard>
      <div className="grid two" style={{ marginTop: 14 }}>
        <SectionCard title="Active release blockers"><ReleaseGatePanel gates={[...(summary?.blockers || []), ...(gates.filter((g) => g.status === "fail"))]} /></SectionCard>
        <SectionCard title="Active alerts">{alerts.length ? <DataTable><thead><tr><th>Severity</th><th>Scope</th><th>Agent</th><th>Title</th><th>Last seen</th></tr></thead><tbody>{alerts.map((a) => <tr key={a.id || a.fingerprint}><td><StatusPill value={a.severity || "info"} /></td><td>{valueOrDash(a.scope)}</td><td className="mono">{valueOrDash(a.agent_id)}</td><td>{valueOrDash(a.title)}</td><td className="mono">{valueOrDash(a.last_seen_at)}</td></tr>)}</tbody></DataTable> : <EmptyState title="No active alerts" />}</SectionCard>
      </div>
      <SectionCard title="Controlled beta checklist" description="Manual operator checklist; no write action is performed from this page.">
        <ul className="checklist"><li>Package hash captured.</li><li>Backup and restore drill reviewed.</li><li>PHP wrapper exposure validated.</li><li>Agent telemetry fresh enough for staging.</li><li>Shadow-only safety confirmed.</li><li>Incident response and rollback path reviewed.</li></ul>
      </SectionCard>
      <RawJsonDrawer data={{ gates: gatesResult.ok ? gatesResult.data : gatesResult, health_report: healthReportResult.ok ? healthReportResult.data : healthReportResult }} title="Raw release evidence" />
    </>
  );
}
