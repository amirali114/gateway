import { AgentCard } from "../../../components/AgentCard";
import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherAgents, getMotherAlertSummary, getMotherDiagnosticsSummary, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";
function pct(v: unknown) { const n = Number(v || 0); return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}%` : "—"; }

export default async function AgentsPage() {
  await requirePermission("agents.view");
  const [agentsResult, summaryResult, alertsResult] = await Promise.all([getMotherAgents(), getMotherDiagnosticsSummary(), getMotherAlertSummary()]);
  const agents = read(agentsResult)?.agents || [];
  const summary = read(summaryResult)?.summary;
  const online = summary?.online_agents ?? agents.filter((a) => a.status === "online").length;
  const stale = summary?.stale_agents ?? agents.filter((a) => a.status === "stale").length;
  const unknown = summary?.unknown_agents ?? Math.max(0, agents.length - online - stale);
  const total = agentsResult.ok ? agents.length : 0;
  const registryTone = !agentsResult.ok ? "danger" : total === 0 ? "blue" : stale > 0 || unknown > 0 ? "warning" : "success";
  const registryLabel = !agentsResult.ok ? "Unavailable" : total === 0 ? "Empty registry" : stale > 0 || unknown > 0 ? "Needs review" : "All healthy";
  const alertTone = (read(alertsResult)?.critical || 0) > 0 ? "danger" : (read(alertsResult)?.warn || 0) > 0 ? "warning" : "neutral";

  return (
    <>
      <PageHeader
        eyebrow="Registry"
        title="Agents"
        description="Mother registry and telemetry aggregate. The dashboard never fetches Agents directly from the browser."
        meta={<StatusPill tone={registryTone}>{registryLabel}</StatusPill>}
      />

      <section className="hero-panel">
        <div className="hero-main">
          <div className={`hero-badge ${registryTone === "blue" ? "" : registryTone}`}>&#9678;</div>
          <div>
            <div className="hero-label">Registry status</div>
            <div className="hero-value">{online}/{total} online</div>
            <div className="hero-sub">Aggregated from Mother's agent registry. Agents remain shadow-only — no remote commands are issued from this dashboard.</div>
          </div>
        </div>
        <div className="hero-stats">
          <div className="hero-stat"><span>Total</span><b>{total}</b></div>
          <div className="hero-stat"><span>Stale</span><b>{stale}</b></div>
          <div className="hero-stat"><span>Unknown</span><b>{unknown}</b></div>
          <div className="hero-stat"><span>Active alerts</span><b>{read(alertsResult)?.active_total ?? 0}</b></div>
        </div>
      </section>

      <div className="grid kpis">
        <KpiCard title="Fresh telemetry" value={summary?.telemetry_fresh ?? 0} hint="agents reporting within freshness window" icon="⌁" tone="success" />
        <KpiCard title="Missing telemetry" value={summary?.telemetry_missing ?? 0} hint="no recent telemetry payload" icon="!" tone={(summary?.telemetry_missing ?? 0) > 0 ? "warning" : "success"} />
        <KpiCard title="Avg match rate" value={pct(summary?.average_match_rate)} hint="policy match rate across fleet" icon="◈" tone="blue" />
        <KpiCard title="Active alerts" value={read(alertsResult)?.active_total ?? 0} hint={`${read(alertsResult)?.critical || 0} critical`} icon="▲" tone={alertTone} />
      </div>

      <div className="section-block">
        <SectionCard title="Agent registry" description="Click an agent to inspect telemetry, config history, events, and alerts.">
          {agentsResult.ok ? (
            agents.length ? (
              <>
                <div className="agent-section-head"><span className="agent-section-count">{agents.length} agent{agents.length === 1 ? "" : "s"} registered</span></div>
                <div className="agent-grid">
                  {agents.map((agent) => (
                    <AgentCard key={agent.agent_id || Math.random()} agent={agent} href={agent.agent_id ? `/agents/${encodeURIComponent(agent.agent_id)}` : undefined} />
                  ))}
                </div>
              </>
            ) : (
              <EmptyState tone="info" icon="◉" title="No agents registered" description="Agents appear here automatically after a policy pull or telemetry push reaches Mother." />
            )
          ) : (
            <ErrorState error={agentsResult.error} />
          )}
        </SectionCard>
      </div>

      <div className="section-block">
        <SectionCard title="Registry table" description="Full fleet detail with sync and telemetry state per agent.">
          {agentsResult.ok ? (
            agents.length ? (
              <DataTable>
                <thead><tr><th>Agent ID</th><th>Status</th><th>Telemetry</th><th>Last telemetry</th><th>Match rate</th><th>Config sync</th><th>Received</th><th></th></tr></thead>
                <tbody>
                  {agents.map((agent) => (
                    <tr key={agent.agent_id || Math.random()}>
                      <td className="mono">{valueOrDash(agent.agent_id)}</td>
                      <td><StatusPill value={agent.status || "unknown"} /></td>
                      <td><StatusPill value={agent.telemetry_status || "missing"} /></td>
                      <td className="mono">{valueOrDash(agent.last_telemetry_at)}</td>
                      <td>{pct(agent.last_match_rate)}</td>
                      <td><StatusPill value={agent.config_sync_status || "unknown"} /></td>
                      <td>{valueOrDash(agent.last_received)}</td>
                      <td>{agent.agent_id ? <a className="button-link button-secondary" href={`/agents/${encodeURIComponent(agent.agent_id)}`}>Open</a> : null}</td>
                    </tr>
                  ))}
                </tbody>
              </DataTable>
            ) : (
              <EmptyState tone="info" icon="▤" title="No rows to display" description="The registry table will populate once agents are known to Mother." />
            )
          ) : (
            <ErrorState error={agentsResult.error} />
          )}
        </SectionCard>
      </div>

      <div className="section-block">
        <RawJsonDrawer data={agentsResult.ok ? agentsResult.data : agentsResult} title="Raw Mother registry" />
      </div>
    </>
  );
}
