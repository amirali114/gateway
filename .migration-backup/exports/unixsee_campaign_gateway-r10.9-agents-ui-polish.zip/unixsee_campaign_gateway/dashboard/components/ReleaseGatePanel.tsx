import type { MotherReleaseGate, MotherReleaseGateSummary } from "../lib/types";
import { valueOrDash } from "../lib/api";
import { StatusPill } from "./StatusPill";
import { EmptyState } from "./EmptyState";

function normalizedReleaseLabel(summary?: MotherReleaseGateSummary): string {
  if (!summary) return "Unknown";
  if ((summary.fail || 0) > 0 || (summary.blockers || []).length > 0) return "Blocked";
  if ((summary.warn || 0) > 0 || (summary.unknown || 0) > 0 || (summary.skipped || 0) > 0) return "Conditional";
  return summary.ready ? "Ready" : "Needs review";
}

export function ReleaseSummaryStrip({ summary }: { summary?: MotherReleaseGateSummary }) {
  return (
    <div className="grid kpis">
      <div className="kpi-card success"><div className="kpi-head"><span>Pass</span><span className="kpi-icon">✓</span></div><div className="kpi-value">{summary?.pass ?? 0}</div></div>
      <div className="kpi-card warning"><div className="kpi-head"><span>Warn</span><span className="kpi-icon">!</span></div><div className="kpi-value">{summary?.warn ?? 0}</div></div>
      <div className="kpi-card danger"><div className="kpi-head"><span>Fail</span><span className="kpi-icon">×</span></div><div className="kpi-value">{summary?.fail ?? 0}</div></div>
      <div className="kpi-card blue"><div className="kpi-head"><span>Status</span><span className="kpi-icon">◇</span></div><div className="kpi-value"><StatusPill value={normalizedReleaseLabel(summary)} /></div></div>
    </div>
  );
}

export function ReleaseGatePanel({ gates }: { gates: MotherReleaseGate[] }) {
  if (!gates.length) return <EmptyState title="No release gates yet" description="Mother has not returned release-gate evidence for this environment." />;
  return (
    <div className="release-list">
      {gates.map((gate) => (
        <article className="release-card" key={gate.id || `${gate.category}-${gate.title}`}>
          <div className="release-card-head">
            <div><div className="release-title">{valueOrDash(gate.title)}</div><div className="agent-id">{valueOrDash(gate.category)} · {valueOrDash(gate.id)}</div></div>
            <StatusPill value={gate.status || "unknown"} />
          </div>
          <div className="release-message">{valueOrDash(gate.message)}</div>
          {gate.remediation_hint ? <div className="small-muted">Remediation: {gate.remediation_hint}</div> : null}
        </article>
      ))}
    </div>
  );
}
