import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import type { PillTone } from "../../../components/StatusPill";
import { getMotherAgents, getMotherAlertSummary, getMotherDiagnosticsSummary, getMotherHealth, getMotherHealthReport, getMotherReady, getMotherStorageStatus, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";
function pct(value: unknown): string { const n = Number(value || 0); return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}%` : "—"; }

function diagnosticsOverall(healthOk?: boolean, readyOk?: boolean, critical?: number): { label: string; tone: PillTone; heroBadgeTone: "success" | "warning" | "danger"; sub: string } {
  if (!healthOk || !readyOk) {
    return { label: "Unavailable", tone: "danger", heroBadgeTone: "danger", sub: "Mother could not be reached — the readings below reflect the last safe fallback." };
  }
  if ((critical || 0) > 0) {
    return { label: "Attention needed", tone: "danger", heroBadgeTone: "danger", sub: `${critical} critical alert${(critical || 0) === 1 ? "" : "s"} require review below.` };
  }
  return { label: "Nominal", tone: "success", heroBadgeTone: "success", sub: "Mother is healthy and no critical alerts are active." };
}

export default async function DiagnosticsPage() {
  await requirePermission("diagnostics.view");
  const [healthResult, readyResult, agentsResult, summaryResult, storageResult, alertsResult, reportResult] = await Promise.all([getMotherHealth(), getMotherReady(), getMotherAgents(), getMotherDiagnosticsSummary(), getMotherStorageStatus(), getMotherAlertSummary(), getMotherHealthReport()]);
  const health = read(healthResult);
  const ready = read(readyResult);
  const summary = read(summaryResult)?.summary;
  const agents = read(agentsResult)?.agents || [];
  const storage = read(storageResult);
  const alerts = read(alertsResult);
  const report = read(reportResult);
  const overall = diagnosticsOverall(health?.ok, ready?.ok, alerts?.critical);

  return (
    <>
      <PageHeader eyebrow="Observability" title="Diagnostics" description="Safe operational summary from Mother. Secrets, tokens, and cookies are not displayed." />

      <div className="readonly-banner">
        <span>◈</span>
        <span><b>Evidence only.</b> Every value below is read live from the local Mother API on the server. No secrets, tokens, or cookies are ever rendered, and no remote-command action exists on this page.</span>
      </div>

      <div className="hero-panel">
        <div className="hero-main">
          <div className={`hero-badge ${overall.heroBadgeTone}`}>⌁</div>
          <div>
            <div className="hero-label">Diagnostics status</div>
            <div className="hero-value"><StatusPill tone={overall.tone}>{overall.label}</StatusPill></div>
            <p className="hero-sub">{overall.sub}</p>
          </div>
        </div>
        <div className="hero-stats">
          <div className="hero-stat"><span>Agents</span><b>{summary?.total_agents ?? 0}</b></div>
          <div className="hero-stat"><span>Match rate</span><b>{pct(summary?.average_match_rate)}</b></div>
          <div className="hero-stat"><span>Storage</span><b>{valueOrDash(storage?.engine)}</b></div>
          <div className="hero-stat"><span>Critical alerts</span><b>{alerts?.critical ?? 0}</b></div>
        </div>
      </div>

      <div className="grid kpis">
        <KpiCard title="Mother health" value={<StatusPill value={health?.ok ? "healthy" : "unavailable"} />} icon="◎" tone={health?.ok ? "success" : "danger"} />
        <KpiCard title="Mother ready" value={<StatusPill value={ready?.ok ? "ready" : "not-ready"} />} hint={valueOrDash(ready?.storage)} icon="✓" tone={ready?.ok ? "success" : "warning"} />
        <KpiCard title="Storage" value={<StatusPill value={storage?.engine || "unknown"} />} hint={storage?.writable ? "Writable" : "Not writable or unknown"} icon="▣" tone={storage?.writable ? "success" : "warning"} />
        <KpiCard title="Match rate" value={pct(summary?.average_match_rate)} icon="⌁" />
        <KpiCard title="Fresh / stale / missing" value={`${summary?.telemetry_fresh ?? 0} / ${summary?.telemetry_stale ?? 0} / ${summary?.telemetry_missing ?? 0}`} icon="◉" />
        <KpiCard title="Critical alerts" value={alerts?.critical ?? 0} icon="!" tone={(alerts?.critical || 0) > 0 ? "danger" : "success"} />
      </div>

      <SectionCard title="Alert summary" description="Active alert counts by severity, plus alerts resolved in the last 24 hours.">
        <div className="pulse-grid">
          <div className="pulse-item"><div className="pulse-item-head"><span>Critical</span><StatusPill tone={(alerts?.critical || 0) > 0 ? "danger" : "success"}>{alerts?.critical || 0}</StatusPill></div><div className="pulse-item-value">{alerts?.critical ?? 0}</div><div className="pulse-item-note">Active, highest severity</div></div>
          <div className="pulse-item"><div className="pulse-item-head"><span>Warning</span><StatusPill tone={(alerts?.warn || 0) > 0 ? "warning" : "success"}>{alerts?.warn || 0}</StatusPill></div><div className="pulse-item-value">{alerts?.warn ?? 0}</div><div className="pulse-item-note">Active, needs review</div></div>
          <div className="pulse-item"><div className="pulse-item-head"><span>Info</span><StatusPill tone="neutral">{alerts?.info || 0}</StatusPill></div><div className="pulse-item-value">{alerts?.info ?? 0}</div><div className="pulse-item-note">Active, informational</div></div>
          <div className="pulse-item"><div className="pulse-item-head"><span>Resolved (24h)</span><StatusPill tone="success">{alerts?.resolved_24h || 0}</StatusPill></div><div className="pulse-item-value">{alerts?.resolved_24h ?? 0}</div><div className="pulse-item-note">Closed out in the last day</div></div>
        </div>
        {alerts?.muted ? <p className="small-muted" style={{ marginTop: 12 }}>{alerts.muted} alert{alerts.muted === 1 ? "" : "s"} currently muted.</p> : null}
      </SectionCard>

      <SectionCard title="Storage detail" description="Persistence engine health as reported by Mother.">
        <table className="kv"><tbody>
          <tr><th>Engine</th><td><StatusPill value={storage?.engine || "unknown"} /></td></tr>
          <tr><th>Writable</th><td><StatusPill value={storage?.writable ? "true" : "false"} /></td></tr>
          <tr><th>Last load</th><td className="mono">{valueOrDash(storage?.last_load_at)}</td></tr>
          <tr><th>Last save</th><td className="mono">{valueOrDash(storage?.last_save_at)}</td></tr>
          {storage?.database_connected !== undefined ? <tr><th>Database connected</th><td><StatusPill value={storage.database_connected ? "true" : "false"} /></td></tr> : null}
          {storage?.schema_version !== undefined ? <tr><th>Schema version</th><td>{valueOrDash(storage.schema_version)}</td></tr> : null}
          {storage?.migration_status ? <tr><th>Migration status</th><td><StatusPill value={storage.migration_status} /></td></tr> : null}
          {storage?.last_error ? <tr><th>Last error</th><td>{storage.last_error}</td></tr> : null}
        </tbody></table>
      </SectionCard>

      <SectionCard title="Agent diagnostics snapshot">
        {agents.length ? <DataTable><thead><tr><th>Agent</th><th>Status</th><th>Telemetry</th><th>Received</th><th>Mismatched</th><th>Last seen</th></tr></thead><tbody>{agents.map((a, index) => <tr key={a.agent_id || `agent-diag-${index}`}><td className="mono">{valueOrDash(a.agent_id)}</td><td><StatusPill value={a.status || "unknown"} /></td><td><StatusPill value={a.telemetry_status || "missing"} /></td><td>{valueOrDash(a.last_received)}</td><td>{valueOrDash(a.last_mismatched)}</td><td className="mono">{valueOrDash(a.last_seen_at)}</td></tr>)}</tbody></DataTable> : <EmptyState title="No agent diagnostics yet" />}
      </SectionCard>

      <SectionCard title="Release safety signals" description="Read-only posture flags surfaced by the health report — no controls are exposed here.">
        <div className="checklist-cards">
          <div className="checklist-card"><span className="checklist-card-icon">◈</span><span className="checklist-card-text">Backup / restore: <StatusPill value={report?.backup_restore_status || "unknown"} /></span></div>
          <div className="checklist-card"><span className="checklist-card-icon">◈</span><span className="checklist-card-text">Shadow-only safety: <StatusPill value={report?.shadow_only_safety_status || "unknown"} /></span></div>
          <div className="checklist-card"><span className="checklist-card-icon">◈</span><span className="checklist-card-text">Public exposure: <StatusPill value={report?.public_exposure_status || "unknown"} /></span></div>
          <div className="checklist-card"><span className="checklist-card-icon">◈</span><span className="checklist-card-text">Recent critical events: {report?.recent_critical_events?.length ?? 0}</span></div>
        </div>
      </SectionCard>

      <RawJsonDrawer data={{ healthResult, readyResult, storageResult, summaryResult, alertsResult, reportResult }} title="Raw diagnostic payloads" />
    </>
  );
}
