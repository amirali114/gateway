import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import type { PillTone } from "../../../components/StatusPill";
import { getMotherDiagnosticsSummary, getMotherHealth, getMotherPolicy, getMotherReady, motherBaseUrl, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

function motherOverall(healthOk?: boolean, readyOk?: boolean): { label: string; tone: PillTone; heroBadgeTone: "success" | "warning" | "danger"; sub: string } {
  if (healthOk && readyOk) {
    return { label: "Operational", tone: "success", heroBadgeTone: "success", sub: "Mother is healthy and ready. All diagnostics below are read from the local Mother API." };
  }
  if (healthOk || readyOk) {
    return { label: "Degraded", tone: "warning", heroBadgeTone: "warning", sub: "Mother is partially available. Check the health and ready indicators below." };
  }
  return { label: "Unavailable", tone: "danger", heroBadgeTone: "danger", sub: "Mother could not be reached. The dashboard is showing the last known safe defaults." };
}

export default async function MotherPage() {
  await requirePermission("settings.view");
  const [healthResult, readyResult, policyResult, summaryResult] = await Promise.all([getMotherHealth(), getMotherReady(), getMotherPolicy("default"), getMotherDiagnosticsSummary()]);
  const health = read(healthResult); const ready = read(readyResult); const policy = read(policyResult)?.policy; const summary = read(summaryResult)?.summary;
  const overall = motherOverall(health?.ok, ready?.ok);

  return (
    <>
      <PageHeader eyebrow="Core" title="Mother Core" description="Read-only status for the local Mother API. The management token stays server-side only." />

      <div className="readonly-banner">
        <span>◈</span>
        <span><b>Local-only, read-only.</b> This page calls the Mother API from the server only. The browser never receives the management token, and no control or command action exists on this page.</span>
      </div>

      <div className="hero-panel">
        <div className="hero-main">
          <div className={`hero-badge ${overall.heroBadgeTone}`}>◎</div>
          <div>
            <div className="hero-label">Mother status</div>
            <div className="hero-value"><StatusPill tone={overall.tone}>{overall.label}</StatusPill></div>
            <p className="hero-sub">{overall.sub}</p>
          </div>
        </div>
        <div className="hero-stats">
          <div className="hero-stat"><span>Health</span><b><StatusPill value={health?.ok ? "healthy" : "unavailable"} /></b></div>
          <div className="hero-stat"><span>Ready</span><b><StatusPill value={ready?.ok ? "ready" : "not-ready"} /></b></div>
          <div className="hero-stat"><span>Storage</span><b>{valueOrDash(ready?.storage)}</b></div>
          <div className="hero-stat"><span>Registered agents</span><b>{summary?.total_agents ?? 0}</b></div>
        </div>
      </div>

      <div className="grid kpis">
        <KpiCard title="Health" value={<StatusPill value={health?.ok ? "healthy" : "unavailable"} />} hint={valueOrDash(health?.service)} icon="◎" tone={health?.ok ? "success" : "danger"} />
        <KpiCard title="Ready" value={<StatusPill value={ready?.ok ? "ready" : "not-ready"} />} hint={valueOrDash(ready?.storage)} icon="✓" tone={ready?.ok ? "success" : "warning"} />
        <KpiCard title="Mother URL" value={<StatusPill tone="blue">Local-only</StatusPill>} hint="Server-side calls only — never exposed to the browser" icon="↔" tone="blue" />
        <KpiCard title="Registered agents" value={summary?.total_agents ?? 0} icon="◉" />
      </div>

      <SectionCard title="Default policy" description="The policy profile Mother currently advertises as the default for shadow evaluation.">
        <table className="kv"><tbody>
          <tr><th>Policy ID</th><td className="mono">{valueOrDash(policy?.id)}</td></tr>
          <tr><th>Profile</th><td className="mono">{valueOrDash(policy?.profile_id)}</td></tr>
          <tr><th>Version</th><td>{valueOrDash(policy?.version)}</td></tr>
          <tr><th>Source</th><td>{valueOrDash(policy?.source)}</td></tr>
        </tbody></table>
      </SectionCard>

      <SectionCard title="Safety model" description="What this dashboard can and cannot do with Mother.">
        <div className="checklist-cards">
          <div className="checklist-card"><span className="checklist-card-icon">✓</span><span className="checklist-card-text">Dashboard uses server-side Mother API calls only.</span></div>
          <div className="checklist-card"><span className="checklist-card-icon">✓</span><span className="checklist-card-text">Browser never receives the Mother management token.</span></div>
          <div className="checklist-card"><span className="checklist-card-icon">✓</span><span className="checklist-card-text">Agents remain shadow-only; the PHP Gateway is the runtime source.</span></div>
          <div className="checklist-card"><span className="checklist-card-icon">✓</span><span className="checklist-card-text">No enforcement or remote command is available in this dashboard.</span></div>
        </div>
      </SectionCard>

      <RawJsonDrawer data={{ healthResult, readyResult, policyResult, summaryResult }} title="Raw Mother payloads" />
    </>
  );
}
