# R10.4 Dashboard UI Restore / Visual Continuity

R10.4 restores the intended premium Unixsee dashboard appearance after R10.3 beta hardening made the UI look too much like a raw staging/operator panel.

Scope:
- Dashboard UI only.
- No Mother Go changes.
- No Agent Go changes.
- No PHP Gateway runtime changes.
- No auth/session/RBAC/token logic changes.
- No enforcement UI or remote command functionality.

Dashboard changes:
- Premium branded shell, sidebar, topbar and login page.
- Unixsee palette restored: navy, blue, pale blue, gold and neutral panels.
- Overview uses a polished health hero and metric cards.
- Release readiness uses clear Persian labels: آماده مشروط، نیازمند تکمیل، مسدود.
- Release warnings are grouped into Agent, PHP Wrapper, Backup/Restore and Evidence.
- Agents empty state is polished and includes next-step guidance.
- Raw JSON is hidden behind collapsible panels titled مشاهده پاسخ خام.
- Security posture remains visible: shadow-only, PHP runtime source of truth, no enforcement, no remote command.

Runtime preservation:
- Dashboard continues to fetch through server-side Mother API helpers.
- Browser does not receive Mother management token.
- Local-only staging behavior is preserved.
