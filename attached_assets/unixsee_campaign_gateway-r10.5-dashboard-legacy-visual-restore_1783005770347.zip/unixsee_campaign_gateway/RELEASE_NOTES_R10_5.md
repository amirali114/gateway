# R10.5 Dashboard Legacy Visual Restore

- Dashboard UI-only hotfix.
- Restores the dark PHP admin panel visual language from the original `unixsee_campaign_gateway.zip`: dark #020617 surface, compact 220px sidebar, minimal KPI cards, muted table/card styling.
- Preserves R10.4/R10.3 runtime, auth, RBAC, Mother API, release gates, routes, tokens, storage, and local-only behavior.
- No Mother/Agent/PHP runtime changes.
- Does not bundle original font files or secret/database runtime files from the legacy reference.
