# Unixsee Campaign Gateway R10.4

Release: dashboard-ui-restore-visual-continuity

Summary:
- Restored premium Unixsee Dashboard visual continuity.
- Kept all R10.3 routes and runtime behavior.
- Reworked shell/sidebar/topbar/login styling.
- Reworked /release page into polished readiness cards and grouped warning sections.
- Added premium empty state for /agents.
- Raw JSON responses are now collapsed by default.

No backend behavior changed:
- Mother Go unchanged.
- Agent Go unchanged.
- PHP Gateway runtime unchanged.
- Auth/session/RBAC/token logic unchanged.
- No enforcement.
- No remote commands.
- Agent remains private.
