# Unixsee Gateway Dashboard

داشبورد R9.2 یک کنترل‌پنل فارسی RTL برای مدیریت مرحله‌ای Gateway از طریق Mother است.

## وضعیت محصول

- Mother-backed control plane — staging mode
- Dashboard روی صفحات عملیاتی فقط Mother APIs را می‌خواند/می‌نویسد.
- Agent همچنان shadow-only است.
- PHP Gateway همچنان source of truth برای runtime request handling است.
- Dashboard نباید بدون auth/reverse proxy امن به‌صورت عمومی expose شود.

## Environment

Server-only variables preferred:

```env
UNIXSEE_MOTHER_BASE_URL=http://127.0.0.1:8732
```

Legacy fallback هنوز پشتیبانی می‌شود:

```env
NEXT_PUBLIC_UNIXSEE_MOTHER_BASE_URL=http://127.0.0.1:8732
```

هیچ secret داخل `.env.example` قرار ندهید.

## Pages

- `/` نمای کلی
- `/agents` سایت‌ها / Agentها
- `/agents/[agent_id]` مدیریت Agent
- `/gateway` کنترل گیت‌وی
- `/policy` سیاست‌ها
- `/diagnostics` لاگ‌ها و عیب‌یابی محدود
- `/settings` تنظیمات Mother

## Writes

تنها writeهای Dashboard در R9.2:

- `POST /v1/agents/{agent_id}/config/draft`
- `POST /v1/agents/{agent_id}/config/publish`

هیچ write مستقیم به Agent، WordPress، فایل‌های PHP، webroot، `.htaccess` یا web server config وجود ندارد.

## Build

```bash
npm ci
npm run build
```

## R9.3 telemetry dashboard

Dashboard pages now show Mother-aggregated Agent telemetry and events:

- `/` overview shows telemetry freshness, total received shadow payloads, mismatch totals, and latest events.
- `/agents` shows telemetry status per Agent.
- `/agents/[agent_id]` shows telemetry, counters, by-action breakdown, runtime module status, and recent events.
- `/diagnostics` shows Mother diagnostics summary and stale/mismatch warnings.

Dashboard production pages still use Mother APIs only. No direct Agent fetch, no write to site files, no remote commands, and no enforcement controls are included.

## R9.4 authentication and access control

The dashboard is protected by staging authentication when `DASHBOARD_AUTH_ENABLED=true`.
Use `node scripts/hash-password.mjs` to generate `DASHBOARD_ADMIN_PASSWORD_HASH` and set a long `DASHBOARD_SESSION_SECRET`.
Write calls to Mother draft/publish endpoints are made server-side only and may attach `UNIXSEE_MOTHER_MANAGEMENT_TOKEN`; this token must never be exposed to the browser.

## R9.4 authentication

Dashboard authentication is enabled with server-side environment variables:

```env
DASHBOARD_AUTH_ENABLED=true
DASHBOARD_ADMIN_USERNAME=admin
DASHBOARD_ADMIN_PASSWORD_HASH=$2b$...
DASHBOARD_SESSION_SECRET=replace-with-long-random-secret
UNIXSEE_MOTHER_MANAGEMENT_TOKEN=
```

Generate a password hash with:

```bash
node scripts/hash-password.mjs
```

The dashboard uses a signed HTTP-only cookie and never stores credentials in localStorage. Write calls to Mother are server-side only; the Mother management token must not be exposed to browser JavaScript.

## HTTPS / reverse proxy profile

For staging exposure, keep Dashboard bound to `127.0.0.1:8740` and put Nginx or OpenLiteSpeed in front of it. Set:

```env
DASHBOARD_PUBLIC_BASE_URL=https://panel.example.com
DASHBOARD_TRUST_PROXY=true
```

The reverse proxy must forward `X-Forwarded-Proto` and `X-Forwarded-Host`. Dashboard uses these values only in trusted proxy mode. The Mother management token stays server-side and must not be exposed to browser JavaScript.

## R9.6 Mother storage visibility

The Dashboard remains Persian RTL and Mother-backed only. `/settings` and `/diagnostics` show Mother storage status from `/v1/storage/status`, including engine, path, writable state, last load/save time, and warnings for volatile memory storage. No secrets are displayed.

## R9.7 rollout visibility

The Persian RTL dashboard now shows immutable config versions, draft vs active diff, publish notes, rollback controls, delivery state, and telemetry acknowledgement. It remains Mother-backed only. No production page fetches the Agent directly, and no remote command or enforcement UI exists.

## R9.8 local RBAC user store

R9.8 replaces the single-admin runtime model with a local multi-user RBAC store.

Recommended environment:

```env
DASHBOARD_USER_STORE_PATH=/var/lib/unixsee-gateway/dashboard
DASHBOARD_BOOTSTRAP_ADMIN_USERNAME=admin
DASHBOARD_BOOTSTRAP_ADMIN_PASSWORD_HASH=$2b$12$replace-with-generated-bcrypt-hash
DASHBOARD_BOOTSTRAP_ADMIN_EMAIL=
```

If the user store is empty, the Dashboard bootstraps one `owner` user from the environment. Passwords are stored as bcrypt hashes only.

Routes:

- `/users` — user management, protected by `users.view` and `users.manage`.
- `/audit` — operator audit trail, protected by `audit.view`.

Roles:

- `owner` — full access.
- `admin` — manage agents/configs and view audit, no owner management.
- `operator` — view and save drafts only.
- `viewer` — read-only.

Dashboard write calls to Mother include safe actor metadata headers, but the Mother management token remains server-only and is never sent to the browser.

## R9.9 storage visibility

The Dashboard settings and diagnostics pages show Mother storage engine, PostgreSQL connection/schema/migration status when available, and Dashboard user-store engine. Secrets such as PostgreSQL DSNs, management tokens and session secrets are never sent to the browser.

`DASHBOARD_USER_STORE_ENGINE=json` remains the supported default in this offline build. `DASHBOARD_POSTGRES_DSN` is documented for a future driver-enabled production profile and must stay server-side only.
