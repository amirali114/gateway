export const ROLES = ["owner", "admin", "operator", "viewer"] as const;
export type Role = typeof ROLES[number];

export const PERMISSIONS = [
  "dashboard.view",
  "agents.view",
  "gateway.view",
  "gateway.draft.write",
  "gateway.publish",
  "gateway.rollback",
  "policy.view",
  "diagnostics.view",
  "alerts.view",
  "alerts.manage",
  "release.view",
  "settings.view",
  "users.view",
  "users.manage",
  "audit.view"
] as const;

export type Permission = typeof PERMISSIONS[number];

const rolePermissions: Record<Role, Permission[]> = {
  owner: [...PERMISSIONS],
  admin: [
    "dashboard.view",
    "agents.view",
    "gateway.view",
    "gateway.draft.write",
    "gateway.publish",
    "gateway.rollback",
    "policy.view",
    "diagnostics.view",
    "alerts.view",
    "alerts.manage",
    "release.view",
    "settings.view",
    "users.view",
    "audit.view"
  ],
  operator: [
    "dashboard.view",
    "agents.view",
    "gateway.view",
    "gateway.draft.write",
    "policy.view",
    "diagnostics.view",
    "alerts.view",
    "release.view"
  ],
  viewer: [
    "dashboard.view",
    "agents.view",
    "gateway.view",
    "policy.view",
    "diagnostics.view",
    "alerts.view",
    "release.view"
  ]
};

export function isRole(value: string): value is Role {
  return (ROLES as readonly string[]).includes(value);
}

export function permissionsForRole(role: Role): Permission[] {
  return rolePermissions[role] || [];
}

export function can(role: Role, permission: Permission): boolean {
  return permissionsForRole(role).includes(permission);
}

export function roleLabel(role: Role | string): string {
  switch (role) {
    case "owner": return "مالک";
    case "admin": return "مدیر";
    case "operator": return "اپراتور";
    case "viewer": return "مشاهده‌گر";
    default: return "نامشخص";
  }
}

export function permissionLabel(permission: Permission | string): string {
  const labels: Record<string, string> = {
    "dashboard.view": "مشاهده داشبورد",
    "agents.view": "مشاهده Agentها",
    "gateway.view": "مشاهده کنترل گیت‌وی",
    "gateway.draft.write": "ذخیره پیش‌نویس تنظیمات",
    "gateway.publish": "انتشار تنظیمات",
    "gateway.rollback": "بازگشت به نسخه قبلی",
    "policy.view": "مشاهده سیاست‌ها",
    "diagnostics.view": "مشاهده عیب‌یابی",
    "alerts.view": "مشاهده هشدارها",
    "alerts.manage": "مدیریت هشدارها",
    "release.view": "مشاهده آمادگی انتشار",
    "settings.view": "مشاهده تنظیمات",
    "users.view": "مشاهده کاربران",
    "users.manage": "مدیریت کاربران",
    "audit.view": "مشاهده audit trail"
  };
  return labels[permission] || permission;
}
