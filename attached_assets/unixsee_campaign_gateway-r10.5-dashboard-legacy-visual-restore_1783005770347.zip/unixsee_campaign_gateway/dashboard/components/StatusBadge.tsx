import type { ReactNode } from "react";

export type BadgeTone = "online" | "stale" | "unknown" | "shadow" | "danger" | "success" | "warning" | "neutral";

const toneLabels: Record<string, string> = {
  online: "آنلاین",
  stale: "قدیمی",
  unknown: "نامشخص",
  shadow: "سایه‌ای",
  fresh: "تازه",
  missing: "دریافت نشده",
  local: "محلی",
  fallback_default: "پیش‌فرض امن",
  last_known_good: "آخرین نسخه سالم",
  invalid_fallback: "بازگشت امن",
  true: "فعال",
  false: "غیرفعال"
};

function normalizeTone(value?: string): BadgeTone {
  if (value === "online" || value === "fresh") return "online";
  if (value === "stale") return "stale";
  if (value === "unknown" || value === "missing") return "unknown";
  if (value === "shadow") return "shadow";
  if (value === "danger") return "danger";
  if (value === "success") return "success";
  if (value === "warning") return "warning";
  return "neutral";
}

export function translateStatus(value: unknown): string {
  if (value === true) return toneLabels.true;
  if (value === false) return toneLabels.false;
  const text = String(value ?? "").trim();
  return toneLabels[text] || text || "—";
}

export function StatusBadge({ value, tone, children }: { value?: unknown; tone?: BadgeTone; children?: ReactNode }) {
  const raw = value ?? children;
  const resolvedTone = tone || normalizeTone(typeof raw === "string" ? raw : undefined);
  return <span className={`badge badge-${resolvedTone}`}>{children ?? translateStatus(raw)}</span>;
}
