import { RawJsonAccordion } from "./RawJsonAccordion";

export function JsonPreview({ data, title }: { data: unknown; title?: string }) {
  return <RawJsonAccordion data={data} title={title || "مشاهده پاسخ خام"} />;
}
