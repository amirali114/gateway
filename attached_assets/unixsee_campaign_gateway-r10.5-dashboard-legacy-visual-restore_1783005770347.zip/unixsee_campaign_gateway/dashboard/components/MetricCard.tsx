import type { ReactNode } from "react";

export function MetricCard({ title, value, hint, children }: { title: string; value: ReactNode; hint?: ReactNode; children?: ReactNode }) {
  return (
    <article className="metric-card">
      <div className="metric-title">{title}</div>
      <div className="metric-value">{value}</div>
      {hint ? <div className="metric-hint">{hint}</div> : null}
      {children}
    </article>
  );
}
