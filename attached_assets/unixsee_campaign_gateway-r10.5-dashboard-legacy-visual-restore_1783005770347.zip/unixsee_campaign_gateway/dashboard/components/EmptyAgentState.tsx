export function EmptyAgentState() {
  return (
    <div className="empty-agent-state">
      <div className="empty-agent-orb">A</div>
      <div>
        <h3>هنوز Agent ثبت نشده</h3>
        <p>بعد از نصب Agent و دریافت telemetry، این صفحه به‌صورت خودکار با وضعیت سایت، config sync، match rate و هشدارها پر می‌شود.</p>
        <div className="checklist-mini">
          <span>۱. نصب private runtime خارج webroot</span>
          <span>۲. نصب wrapper فقط در public path</span>
          <span>۳. اجرای Agent روی 127.0.0.1:8731</span>
          <span>۴. دریافت policy و push telemetry به Mother</span>
        </div>
      </div>
    </div>
  );
}
