export function RawJsonAccordion({ data, title = "مشاهده پاسخ خام" }: { data: unknown; title?: string }) {
  return (
    <details className="raw-json-accordion">
      <summary>{title}</summary>
      <pre className="json-panel" dir="ltr">{JSON.stringify(data ?? null, null, 2)}</pre>
    </details>
  );
}
