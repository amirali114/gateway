import type { ReactNode } from "react";

interface SectionProps {
  title: string;
  description?: ReactNode;
  children: ReactNode;
}

export function Section({ title, description, children }: SectionProps) {
  return (
    <section className="section">
      <div className="section-header">
        <h2>{title}</h2>
        {description ? <p>{description}</p> : null}
      </div>
      {children}
    </section>
  );
}
