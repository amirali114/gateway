import type { MotherAgentRecord } from "../lib/types";
import { ltr, valueOrDash } from "../lib/api";
import { StatusBadge } from "./StatusBadge";

export function AgentSelector({ agents, selectedAgentId, basePath = "/gateway" }: { agents: MotherAgentRecord[]; selectedAgentId?: string; basePath?: string }) {
  if (agents.length === 0) {
    return <div className="state-box state-empty">هنوز Agentی در Mother ثبت نشده است.</div>;
  }
  return (
    <div className="agent-selector">
      {agents.map((agent) => {
        const id = agent.agent_id || "";
        const href = `${basePath}?agent_id=${encodeURIComponent(id)}`;
        const active = id && id === selectedAgentId;
        return (
          <a key={id || Math.random()} className={`agent-option ${active ? "active" : ""}`} href={href}>
            <span className="technical-value">{ltr(valueOrDash(id))}</span>
            <StatusBadge value={agent.status || "unknown"} />
          </a>
        );
      })}
    </div>
  );
}
