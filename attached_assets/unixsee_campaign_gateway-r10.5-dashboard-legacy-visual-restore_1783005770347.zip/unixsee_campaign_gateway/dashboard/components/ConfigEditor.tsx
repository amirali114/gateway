import type { UnknownRecord } from "../lib/types";

function boolFromConfig(config: UnknownRecord, group: string, key: string, fallback: boolean): boolean {
  const section = config[group];
  if (typeof section === "object" && section !== null && key in section) {
    return Boolean((section as Record<string, unknown>)[key]);
  }
  return fallback;
}

function stringFromConfig(config: UnknownRecord, group: string, key: string, fallback: string): string {
  const section = config[group];
  if (typeof section === "object" && section !== null) {
    const value = (section as Record<string, unknown>)[key];
    return typeof value === "string" && value ? value : fallback;
  }
  return fallback;
}

export function ConfigEditor({ agentId, activeConfig, action, disabled = false }: { agentId: string; activeConfig: UnknownRecord; action: (formData: FormData) => Promise<void>; disabled?: boolean }) {
  return (
    <form action={action} className="config-editor">
      <input type="hidden" name="agent_id" value={agentId} />
      <div className="locked-mode">
        <span>حالت اجرا</span>
        <strong>shadow-only</strong>
        <small>قفل شده؛ enforcement در این نسخه وجود ندارد.</small>
      </div>
      <label className="switch-row">
        <input type="checkbox" name="gateway_enabled" disabled={disabled} defaultChecked={boolFromConfig(activeConfig, "gateway", "enabled", true)} />
        <span>Gateway enabled</span>
      </label>
      <label className="switch-row">
        <input type="checkbox" name="campaign_enabled" disabled={disabled} defaultChecked={boolFromConfig(activeConfig, "campaign", "enabled", true)} />
        <span>Campaign enabled</span>
      </label>
      <label className="switch-row">
        <input type="checkbox" name="queue_enabled" disabled={disabled} defaultChecked={boolFromConfig(activeConfig, "queue", "enabled", false)} />
        <span>Queue enabled</span>
      </label>
      <label className="switch-row">
        <input type="checkbox" name="bot_enabled" disabled={disabled} defaultChecked={boolFromConfig(activeConfig, "bot", "enabled", false)} />
        <span>Bot module enabled</span>
      </label>
      <label className="switch-row">
        <input type="checkbox" name="require_signature" disabled={disabled} defaultChecked={boolFromConfig(activeConfig, "security", "require_signature", true)} />
        <span>Require signature</span>
      </label>
      <label className="field-row">
        <span>Default action</span>
        <select name="default_action" disabled={disabled} defaultValue={stringFromConfig(activeConfig, "gateway", "default_action", "allow")}>
          <option value="allow">allow</option>
          <option value="pass">pass</option>
        </select>
      </label>
      <label className="field-row">
        <span>Storage fail mode</span>
        <select name="storage_fail_mode" disabled={disabled} defaultValue={stringFromConfig(activeConfig, "storage", "fail_mode", "open")}>
          <option value="open">open</option>
          <option value="closed">closed</option>
        </select>
      </label>
      <button type="submit" disabled={disabled}>ذخیره پیش‌نویس</button>
    </form>
  );
}
