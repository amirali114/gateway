import { JsonPreview } from "./JsonPreview";
import { StatusBadge } from "./StatusBadge";
import { valueOrDash } from "../lib/api";
import type { MotherReleaseGate } from "../lib/types";

function statusLabel(value?: string) {
  switch (value) {
    case "pass": return "عبور کرده";
    case "warn": return "هشدار";
    case "fail": return "شکست";
    case "skipped": return "رد شده";
    case "unknown": return "بررسی نشده";
    default: return valueOrDash(value);
  }
}

function toneForStatus(value?: string) {
  if (value === "fail") return "danger" as const;
  if (value === "warn" || value === "unknown" || value === "skipped") return "warning" as const;
  return "success" as const;
}

export function ReleaseGateCard({ gate }: { gate: MotherReleaseGate }) {
  return (
    <article className={`release-gate-card release-gate-${gate.status || "unknown"}`}>
      <div className="release-gate-top">
        <StatusBadge tone={toneForStatus(gate.status)}>{statusLabel(gate.status)}</StatusBadge>
        <span className="technical-value">{valueOrDash(gate.category)}</span>
      </div>
      <h3>{valueOrDash(gate.title)}</h3>
      <p>{valueOrDash(gate.message)}</p>
      {gate.remediation_hint ? <div className="remediation">راهکار پیشنهادی: {gate.remediation_hint}</div> : null}
      <div className="release-gate-meta">
        <span className="technical-value">{valueOrDash(gate.id)}</span>
        <span className="technical-value">{valueOrDash(gate.last_checked_at)}</span>
      </div>
      {gate.evidence ? <JsonPreview data={gate.evidence} title="مشاهده شواهد امن" /> : null}
    </article>
  );
}
