import { RawJsonAccordion } from "./RawJsonAccordion";

interface JsonPanelProps {
  data: unknown;
  title?: string;
}

export function JsonPanel({ data, title }: JsonPanelProps) {
  return <RawJsonAccordion data={data} title={title || "مشاهده پاسخ خام"} />;
}
