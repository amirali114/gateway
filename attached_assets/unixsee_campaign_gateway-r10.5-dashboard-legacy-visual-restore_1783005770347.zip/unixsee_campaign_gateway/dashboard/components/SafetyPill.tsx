import type { ReactNode } from "react";

export function SafetyPill({ label, value, tone = "neutral" }: { label: string; value: ReactNode; tone?: "safe" | "warn" | "danger" | "neutral" | "gold" }) {
  return (
    <span className={`safety-pill safety-pill-${tone}`}>
      <span className="safety-pill-label">{label}</span>
      <strong>{value}</strong>
    </span>
  );
}
