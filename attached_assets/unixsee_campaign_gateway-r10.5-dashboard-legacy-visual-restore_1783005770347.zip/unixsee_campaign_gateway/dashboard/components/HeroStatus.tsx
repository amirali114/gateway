import type { ReactNode } from "react";

export function HeroStatus({ eyebrow, title, description, tone = "safe", actions, children }: { eyebrow?: ReactNode; title: ReactNode; description?: ReactNode; tone?: "safe" | "warn" | "danger" | "neutral"; actions?: ReactNode; children?: ReactNode }) {
  return (
    <section className={`hero-status hero-status-${tone}`}>
      <div className="hero-status-content">
        {eyebrow ? <div className="hero-eyebrow">{eyebrow}</div> : null}
        <h1>{title}</h1>
        {description ? <p>{description}</p> : null}
      </div>
      {children ? <div className="hero-status-grid">{children}</div> : null}
      {actions ? <div className="hero-actions">{actions}</div> : null}
    </section>
  );
}
