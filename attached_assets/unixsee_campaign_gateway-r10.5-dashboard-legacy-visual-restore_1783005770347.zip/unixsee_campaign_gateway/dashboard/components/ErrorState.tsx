export function ErrorState({ title = "خطا در دریافت اطلاعات", error }: { title?: string; error?: string }) {
  return (
    <div className="state-box state-error">
      <strong>{title}</strong>
      <p>{error || "سرویس در دسترس نیست یا پاسخ معتبر برنگرداند."}</p>
    </div>
  );
}
