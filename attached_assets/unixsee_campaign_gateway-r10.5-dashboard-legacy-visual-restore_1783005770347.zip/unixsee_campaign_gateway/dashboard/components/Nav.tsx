import type { Permission } from "../lib/rbac";

const items: { href: string; label: string; permission: Permission; icon: string }[] = [
  { href: "/", label: "نمای کلی", permission: "dashboard.view", icon: "◆" },
  { href: "/release", label: "آمادگی انتشار", permission: "release.view", icon: "◈" },
  { href: "/agents", label: "سایت‌ها / Agentها", permission: "agents.view", icon: "●" },
  { href: "/mother", label: "Mother", permission: "settings.view", icon: "◐" },
  { href: "/diagnostics", label: "عیب‌یابی", permission: "diagnostics.view", icon: "◎" },
  { href: "/alerts", label: "هشدارها", permission: "alerts.view", icon: "!" },
  { href: "/settings/production", label: "Production readiness", permission: "settings.view", icon: "✓" },
  { href: "/gateway", label: "کنترل گیت‌وی", permission: "gateway.view", icon: "◇" },
  { href: "/policy", label: "سیاست‌ها", permission: "policy.view", icon: "▣" },
  { href: "/users", label: "کاربران", permission: "users.view", icon: "♙" },
  { href: "/audit", label: "ردپای عملیات", permission: "audit.view", icon: "⌁" },
  { href: "/settings", label: "تنظیمات Mother", permission: "settings.view", icon: "⚙" }
];

export function Nav({ permissions }: { permissions: readonly string[] }) {
  return (
    <nav className="nav" aria-label="ناوبری داشبورد">
      {items.filter((item) => permissions.includes(item.permission)).map((item) => (
        <a href={item.href} key={item.href}>
          <span className="nav-icon">{item.icon}</span>
          <span>{item.label}</span>
        </a>
      ))}
    </nav>
  );
}
