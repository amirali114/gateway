import { redirect } from "next/navigation";
import { loginAction } from "./actions";
import { currentSession, isAuthEnabled } from "../../lib/auth";

export const dynamic = "force-dynamic";

type Props = { searchParams?: Promise<{ error?: string }> };

export default async function LoginPage({ searchParams }: Props) {
  if (!isAuthEnabled()) redirect("/");
  const session = await currentSession();
  if (session) redirect("/");
  const sp = searchParams ? await searchParams : {};
  return (
    <main className="login-page">
      <section className="login-card">
        <div className="login-logo">Unixsee Gateway</div>
        <h1>ورود به پنل مدیریت</h1>
        <p>برای دسترسی به کنترل‌پلین Mother-backed وارد شوید.</p>
        {sp.error ? <div className="login-error">نام کاربری یا رمز عبور نادرست است.</div> : null}
        <form action={loginAction} className="login-form">
          <label>
            <span>نام کاربری</span>
            <input name="username" autoComplete="username" required />
          </label>
          <label>
            <span>رمز عبور</span>
            <input name="password" type="password" autoComplete="current-password" required />
          </label>
          <button type="submit">ورود</button>
        </form>
        <small>نشست با cookie امن، httpOnly و SameSite=Lax نگهداری می‌شود.</small>
      </section>
    </main>
  );
}
