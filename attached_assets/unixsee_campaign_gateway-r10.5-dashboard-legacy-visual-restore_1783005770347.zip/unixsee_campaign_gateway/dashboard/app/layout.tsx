import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "کنترل‌پنل Unixsee Gateway",
  description: "Mother-backed control plane — staging mode for Unixsee Campaign Gateway."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
