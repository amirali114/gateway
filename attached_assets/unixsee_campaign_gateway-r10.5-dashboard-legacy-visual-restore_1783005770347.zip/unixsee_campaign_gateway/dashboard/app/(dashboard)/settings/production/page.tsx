import { EmptyState } from "../../../../components/EmptyState";
import { ErrorState } from "../../../../components/ErrorState";
import { JsonPreview } from "../../../../components/JsonPreview";
import { MetricCard } from "../../../../components/MetricCard";
import { PageHeader } from "../../../../components/PageHeader";
import { Section } from "../../../../components/Section";
import { StatusBadge } from "../../../../components/StatusBadge";
import { getMotherAgents, getMotherDiagnosticsSummary, getMotherHealthReport, getMotherStorageStatus, read, valueOrDash } from "../../../../lib/api";
import { dashboardSecuritySummary, requirePermission } from "../../../../lib/auth";
import { permissionLabel, roleLabel } from "../../../../lib/rbac";

export const dynamic = "force-dynamic";

function yesNo(value: boolean | undefined) {
  return value ? <StatusBadge tone="success">آماده</StatusBadge> : <StatusBadge tone="warning">نیازمند بررسی</StatusBadge>;
}

export default async function ProductionReadinessPage() {
  await requirePermission("settings.view");
  const security = await dashboardSecuritySummary();
  const [storageResult, summaryResult, agentsResult, healthReportResult] = await Promise.all([
    getMotherStorageStatus(),
    getMotherDiagnosticsSummary(),
    getMotherAgents(),
    getMotherHealthReport()
  ]);
  const storage = read(storageResult);
  const summary = read(summaryResult)?.summary;
  const agents = read(agentsResult)?.agents || [];
  const healthReport = read(healthReportResult);

  const authReady = Boolean(security.auth_enabled && security.session_secret_configured && security.user_count > 0);
  const rbacReady = Boolean(security.user_count > 0 && security.current_user?.permissions?.length);
  const storageReady = Boolean(storageResult.ok && storage?.ok && storage?.writable);
  const telemetryReady = Boolean((summary?.telemetry_fresh || 0) > 0 || agents.length === 0);
  const rolloutReady = Boolean(summaryResult.ok);
  const proxyReady = Boolean(security.public_base_url && security.trust_proxy && security.cookie_secure_expected);

  return (
    <>
      <PageHeader
        title="آمادگی Production / Controlled Rollout"
        description="نمای عملیاتی برای بررسی blockerهای rollout کنترل‌شده. هیچ secret یا token در این صفحه نمایش داده نمی‌شود."
      />

      <div className="notice warning">
        این پنل فقط staging/control-plane است. Agent همچنان shadow-only است، enforcement فعال نیست و publish فقط state داخل Mother را به‌روزرسانی می‌کند.
      </div>

      <div className="grid cards">
        <MetricCard title="Auth" value={yesNo(authReady)} hint={security.auth_enabled ? "فعال" : "غیرفعال"} />
        <MetricCard title="RBAC users" value={valueOrDash(security.user_count)} hint={rbacReady ? "user store آماده است" : "bootstrap/user store را بررسی کن"} />
        <MetricCard title="Audit" value={<StatusBadge tone="success">فعال</StatusBadge>} hint="audit.jsonl یا dashboard store" />
        <MetricCard title="Mother storage" value={<span className="technical-value">{valueOrDash(storage?.engine)}</span>} hint={storageReady ? "writable" : storageResult.ok ? valueOrDash(storage?.last_error) : storageResult.error} />
        <MetricCard title="PostgreSQL" value={storage?.engine === "postgres" ? (storage.database_connected ? <StatusBadge tone="success">متصل</StatusBadge> : <StatusBadge tone="danger">قطع</StatusBadge>) : <StatusBadge tone="warning">اختیاری/غیرفعال</StatusBadge>} hint={valueOrDash(storage?.migration_status || storage?.dsn_redacted)} />
        <MetricCard title="Public URL" value={<span className="technical-value">{valueOrDash(security.public_base_url)}</span>} hint="DASHBOARD_PUBLIC_BASE_URL" />
        <MetricCard title="Trust proxy" value={security.trust_proxy ? <StatusBadge tone="success">فعال</StatusBadge> : <StatusBadge tone="warning">غیرفعال</StatusBadge>} />
        <MetricCard title="Secure cookie" value={security.cookie_secure_expected ? <StatusBadge tone="success">HTTPS</StatusBadge> : <StatusBadge tone="warning">local HTTP</StatusBadge>} />
        <MetricCard title="Management token" value={security.management_token_configured ? <StatusBadge tone="success">configured</StatusBadge> : <StatusBadge tone="danger">missing</StatusBadge>} hint="مقدار نمایش داده نمی‌شود" />
        <MetricCard title="Agent count" value={agents.length} hint={`fresh telemetry: ${summary?.telemetry_fresh ?? 0}`} />
        <MetricCard title="Telemetry health" value={telemetryReady ? <StatusBadge tone="success">قابل قبول</StatusBadge> : <StatusBadge tone="warning">نیازمند بررسی</StatusBadge>} hint={`missing: ${summary?.telemetry_missing ?? 0}`} />
        <MetricCard title="Config rollout" value={rolloutReady ? <StatusBadge tone="success">endpoint آماده</StatusBadge> : <StatusBadge tone="danger">خطا</StatusBadge>} hint={`published: ${summary?.configs_published_total ?? 0}`} />
      </div>

      <Section title="Blocker checklist">
        <table className="data-table">
          <thead><tr><th>مورد</th><th>وضعیت</th><th>توضیح</th></tr></thead>
          <tbody>
            <tr><td>Dashboard فقط پشت HTTPS/reverse proxy</td><td>{proxyReady ? <StatusBadge tone="success">آماده</StatusBadge> : <StatusBadge tone="warning">نیازمند تنظیم</StatusBadge>}</td><td>DASHBOARD_PUBLIC_BASE_URL و DASHBOARD_TRUST_PROXY را بررسی کن.</td></tr>
            <tr><td>Mother token server-side</td><td>{security.management_token_configured ? <StatusBadge tone="success">آماده</StatusBadge> : <StatusBadge tone="danger">Blocker</StatusBadge>}</td><td>Browser نباید token را دریافت کند.</td></tr>
            <tr><td>Storage writable</td><td>{storageReady ? <StatusBadge tone="success">آماده</StatusBadge> : <StatusBadge tone="danger">Blocker</StatusBadge>}</td><td>مسیر storage باید خارج webroot و writable باشد.</td></tr>
            <tr><td>Agent public exposure</td><td><StatusBadge tone="warning">نیازمند validation</StatusBadge></td><td>deploy/scripts/validate-runtime-exposure.sh را اجرا کن.</td></tr>
            <tr><td>Rollback plan</td><td><StatusBadge tone="success">مستند شد</StatusBadge></td><td>docs/deploy/R10_0_ROLLBACK.md</td></tr>
            <tr><td>Enforcement</td><td><StatusBadge tone="shadow">غیرفعال</StatusBadge></td><td>در R10.0 عمداً فعال نیست.</td></tr>
          </tbody>
        </table>
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="کاربر و permission فعلی">
          <table className="kv"><tbody>
            <tr><th>Username</th><td className="technical-value">{valueOrDash(security.current_user?.username)}</td></tr>
            <tr><th>Role</th><td>{roleLabel(String(security.current_user?.role || ""))}</td></tr>
            <tr><th>Session expiry</th><td>{valueOrDash(security.session_expiry_hours)} ساعت</td></tr>
            <tr><th>Permissions</th><td>{(security.current_user?.permissions || []).map((p: string) => permissionLabel(p)).join("، ") || "—"}</td></tr>
          </tbody></table>
        </Section>
        <Section title="Validation scripts status">
          <EmptyState title="اجرای اسکریپت‌ها از داخل UI انجام نمی‌شود" description="برای امنیت، پنل دستور remote اجرا نمی‌کند. وضعیت نهایی با deploy/scripts/validate-production-readiness.sh تولید می‌شود." />
        </Section>
      </div>

      <Section title="Mother health report">
        {healthReportResult.ok ? <JsonPreview data={healthReport} /> : <ErrorState error={healthReportResult.error} />}
      </Section>
    </>
  );
}
