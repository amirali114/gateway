import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherHealth, getMotherPolicies, getMotherReady, getMotherStorageStatus, motherBaseUrl, read, valueOrDash } from "../../../lib/api";
import { dashboardSecuritySummary, requirePermission } from "../../../lib/auth";
import { permissionLabel, roleLabel } from "../../../lib/rbac";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  await requirePermission("settings.view");

  const security = await dashboardSecuritySummary();
  const [healthResult, readyResult, policiesResult, storageResult] = await Promise.all([
    getMotherHealth(),
    getMotherReady(),
    getMotherPolicies(),
    getMotherStorageStatus()
  ]);
  const ready = read(readyResult);
  const policies = read(policiesResult)?.policies || [];
  const storage = read(storageResult);
  return (
    <>
      <PageHeader
        title="تنظیمات Mother"
        description="اطلاعات محیطی و مدل امنیتی داشبورد. این صفحه secret یا token نمایش نمی‌دهد."
      />

      <div className="grid cards">
        <MetricCard title="Mother base URL" value={<span className="technical-value">{motherBaseUrl}</span>} hint="server-only env preferred" />
        <MetricCard title="Public base URL" value={<span className="technical-value">{valueOrDash(security.public_base_url)}</span>} hint="DASHBOARD_PUBLIC_BASE_URL" />
        <MetricCard title="Trust proxy" value={security.trust_proxy ? <StatusBadge tone="success">فعال</StatusBadge> : <StatusBadge tone="warning">غیرفعال</StatusBadge>} hint="DASHBOARD_TRUST_PROXY" />
        <MetricCard title="Cookie secure" value={security.cookie_secure_expected ? <StatusBadge tone="success">HTTPS/proxy</StatusBadge> : <StatusBadge tone="warning">local HTTP</StatusBadge>} hint="بر اساس proxy headers یا public URL" />
        <MetricCard title="Auth" value={security.auth_enabled ? <StatusBadge tone="success">فعال</StatusBadge> : <StatusBadge tone="warning">غیرفعال</StatusBadge>} hint="RBAC local user store" />
        <MetricCard title="Dashboard user store" value={<span className="technical-value">{valueOrDash(security.user_store_engine)}</span>} hint={<span className="technical-value">{valueOrDash(security.user_store_path)}</span>} />
        <MetricCard title="Dashboard PostgreSQL" value={security.dashboard_postgres_configured ? <StatusBadge tone="success">configured</StatusBadge> : <StatusBadge tone="warning">json fallback</StatusBadge>} hint="DASHBOARD_USER_STORE_ENGINE / DASHBOARD_POSTGRES_DSN" />
        <MetricCard title="User store writable" value={security.user_store_writable ? <StatusBadge tone="success">قابل نوشتن</StatusBadge> : <StatusBadge tone="danger">خطا</StatusBadge>} hint={<span className="technical-value">{valueOrDash(security.user_store_path)}</span>} />
        <MetricCard title="تعداد کاربران" value={valueOrDash(security.user_count)} />
        <MetricCard title="کاربر فعلی" value={valueOrDash(security.current_user?.username)} hint={security.current_user ? roleLabel(String(security.current_user.role)) : "—"} />
        <MetricCard title="نشست" value={`${security.session_expiry_hours} ساعت`} hint="cookie امن httpOnly" />
        <MetricCard title="Dashboard mode" value={<StatusBadge tone="shadow">local-only by default</StatusBadge>} hint="Expose فقط پشت HTTPS/reverse proxy" />
        <MetricCard title="Bind recommendation" value={<span className="technical-value">{security.dashboard_bind_recommendation}</span>} hint="Dashboard نباید مستقیم public bind شود." />
        <MetricCard title="توکن مدیریت" value={security.management_token_configured ? <StatusBadge tone="success">configured</StatusBadge> : <StatusBadge tone="warning">missing</StatusBadge>} hint="مقدار توکن هرگز نمایش داده نمی‌شود." />
        <MetricCard title="Management read" value={policiesResult.ok ? <StatusBadge tone="success">در دسترس</StatusBadge> : <StatusBadge tone="warning">نامشخص</StatusBadge>} hint={policiesResult.ok ? `${policies.length} سیاست` : policiesResult.error} />
        <MetricCard title="Mother storage engine" value={<span className="technical-value">{valueOrDash(storage?.engine || ready?.storage_engine || ready?.storage)}</span>} hint={storage?.engine === "memory" ? "هشدار: volatile/in-memory" : storage?.engine === "postgres" ? "production SQL profile" : "persistent JSON storage"} />
        <MetricCard title="PostgreSQL connected" value={storage?.engine === "postgres" ? (storage?.database_connected ? <StatusBadge tone="success">متصل</StatusBadge> : <StatusBadge tone="danger">قطع/driver unavailable</StatusBadge>) : <StatusBadge tone="warning">استفاده نمی‌شود</StatusBadge>} hint={storage?.engine === "postgres" ? valueOrDash(storage?.dsn_redacted) : "engine=json"} />
        <MetricCard title="Schema / migration" value={<span className="technical-value">{valueOrDash(storage?.schema_version)}</span>} hint={valueOrDash(storage?.migration_status)} />
        <MetricCard title="Storage writable" value={storage?.writable ? <StatusBadge tone="success">قابل نوشتن</StatusBadge> : <StatusBadge tone="warning">نامشخص/خطا</StatusBadge>} hint={storageResult.ok ? valueOrDash(storage?.last_error) : storageResult.error} />
        <MetricCard title="Storage path" value={<span className="technical-value">{valueOrDash(storage?.path)}</span>} hint="مقدار secret نیست اما مسیر runtime است." />
        <MetricCard title="Last save/load" value={<span className="technical-value">{valueOrDash(storage?.last_save_at || storage?.last_load_at)}</span>} />
      </div>

      <Section title="مدل امنیتی">
        <ul className="safety-list">
          <li>Dashboard با login، session امن و RBAC محلی محافظت می‌شود؛ public exposure فقط پشت HTTPS و reverse proxy مجاز است.</li>
          <li>در reverse proxy باید <span className="technical-value">X-Forwarded-Proto</span> و <span className="technical-value">X-Forwarded-Host</span> ارسال شود و <span className="technical-value">DASHBOARD_TRUST_PROXY=true</span> باشد.</li>
          <li>Dashboard به Agent مستقیم وصل نمی‌شود و فایل‌های سایت را تغییر نمی‌دهد.</li>
          <li>همه writeهای تنظیمات فقط از server-side Dashboard به Mother draft/publish API می‌روند، token به مرورگر نمی‌رود و permission server-side چک می‌شود.</li>
          <li>Agent همچنان shadow-only است و enforcement فعال نیست.</li>
          <li>در staging پایدار، Mother storage می‌تواند <span className="technical-value">json</span> باشد؛ برای production profile از <span className="technical-value">postgres</span> با migration و backup استفاده شود.</li>
          <li>Dashboard RBAC در این build همچنان <span className="technical-value">json</span> است مگر build آینده با store driver PostgreSQL فعال شود؛ مقدار DSN هرگز نمایش داده نمی‌شود.</li>
          <li>هیچ secret، cookie، header حساس، token مدیریت یا دستور ریموت در UI نمایش داده نمی‌شود.</li>
          <li>پورت‌های <span className="technical-value">8731</span> و <span className="technical-value">8740</span> نباید عمومی باشند؛ Mother روی <span className="technical-value">8732</span> فقط با firewall محدود برای Agentهای مجاز باز شود.</li>
        </ul>
      </Section>


      <Section title="مجوزهای کاربر فعلی">
        <ul className="safety-list">{(security.current_user?.permissions || []).map((p: string) => <li key={p}>{permissionLabel(p)}</li>)}</ul>
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="Mother health"><JsonPreview data={healthResult.ok ? healthResult.data : healthResult} /></Section>
        <Section title="Mother ready"><JsonPreview data={readyResult.ok ? readyResult.data : readyResult} /></Section>
        <Section title="Mother storage"><JsonPreview data={storageResult.ok ? storageResult.data : storageResult} /></Section>
      </div>
    </>
  );
}
