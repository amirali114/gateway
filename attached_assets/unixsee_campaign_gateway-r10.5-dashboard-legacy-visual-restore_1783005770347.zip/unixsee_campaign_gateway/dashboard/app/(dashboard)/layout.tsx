import { Nav } from "../../components/Nav";
import { SafetyPill } from "../../components/SafetyPill";
import { requireDashboardAuth } from "../../lib/auth";
import { roleLabel } from "../../lib/rbac";

export default async function DashboardLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const auth = await requireDashboardAuth();
  return (
    <div className="shell shell-premium">
      <aside className="sidebar">
        <div className="brand-block">
          <div>
            <div className="brand">Unixsee Gateway</div>
            <div className="brand-subtitle">پنل مدیریت کمپین</div>
          </div>
        </div>
        <div className="mode-pill premium-mode">
          <b>حالت امن Staging</b>
          <span>PHP Gateway منبع runtime است و Agent فقط shadow telemetry ارسال می‌کند.</span>
        </div>
        <Nav permissions={auth.permissions} />
        <div className="sidebar-footer">
          {auth.enabled ? <span className="session-chip">نشست فعال: <b>{auth.display_name || auth.username}</b> <span className="role-inline">{roleLabel(String(auth.role))}</span></span> : <span className="session-chip">Auth غیرفعال</span>}
          <a className="logout-link" href="/logout">خروج از پنل</a>
        </div>
      </aside>
      <div className="workspace">
        <div className="topbar topbar-premium">
          <div className="topbar-copy">
            <strong>پنل مدیریت گیت‌وی</strong>
            <span>بدون enforcement، بدون دستور ریموت، بدون نمایش token در مرورگر</span>
          </div>
          <div className="topbar-pills">
            <SafetyPill label="Agent" value="local-only" tone="safe" />
            <SafetyPill label="Runtime" value="PHP source" tone="gold" />
            <SafetyPill label="Mode" value="shadow" tone="neutral" />
          </div>
        </div>
        <main className="main">{children}</main>
      </div>
    </div>
  );
}
