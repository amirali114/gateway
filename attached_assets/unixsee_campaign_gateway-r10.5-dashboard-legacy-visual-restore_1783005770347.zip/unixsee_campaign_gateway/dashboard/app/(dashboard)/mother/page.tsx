import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherDebugDefaultPolicy, getMotherDiagnosticsSummary, getMotherHealth, getMotherPolicy, getMotherReady, motherBaseUrl, read, valueOrDash } from "../../../lib/api";

export const dynamic = "force-dynamic";

export default async function MotherPage() {
  const [healthResult, readyResult, defaultPolicyResult, debugResult, summaryResult] = await Promise.all([
    getMotherHealth(),
    getMotherReady(),
    getMotherPolicy("default"),
    getMotherDebugDefaultPolicy(),
    getMotherDiagnosticsSummary()
  ]);
  const health = read(healthResult);
  const ready = read(readyResult);
  const summary = read(summaryResult)?.summary;

  return (
    <>
      <PageHeader
        title="تنظیمات Mother"
        description="وضعیت Core/Mother و مدل امنیتی کنترل‌پلین. این صفحه فقط خواندنی است و هیچ secret یا دستور اجرایی نمایش نمی‌دهد."
      />

      <div className="grid cards">
        <MetricCard title="Mother base URL" value={<span className="technical-value">{motherBaseUrl}</span>} hint="server-side env" />
        <MetricCard title="Health" value={healthResult.ok && health?.ok ? <StatusBadge tone="success">سالم</StatusBadge> : <StatusBadge tone="danger">قطع</StatusBadge>} />
        <MetricCard title="Ready" value={readyResult.ok && ready?.ok ? <StatusBadge tone="success">آماده</StatusBadge> : <StatusBadge tone="warning">نیازمند بررسی</StatusBadge>} hint={readyResult.ok ? valueOrDash(ready?.storage) : readyResult.error} />
        <MetricCard title="Dashboard mode" value={<StatusBadge value="shadow" />} hint="local-only staging control plane" />
      </div>

      <Section title="مدل امنیتی">
        <ul className="safety-list">
          <li>Dashboard نباید بدون auth/reverse proxy در اینترنت expose شود.</li>
          <li>Agent عمومی نیست؛ Agent به Mother telemetry و policy request می‌فرستد.</li>
          <li>writeهای Dashboard فقط به Mother draft/publish محدود هستند.</li>
          <li>هیچ remote command، enforce یا تغییر مستقیم فایل سایت وجود ندارد.</li>
        </ul>
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="Default policy از مسیر عادی" description="این مسیر resource عادی است: /v1/policies/default">
          {defaultPolicyResult.ok ? <JsonPreview data={defaultPolicyResult.data} /> : <ErrorState error={defaultPolicyResult.error} />}
        </Section>
        <Section title="Debug endpoint" description="این مسیر debug-only است: /v1/debug/policies/default و پیش‌فرض باید غیرفعال باشد.">
          {debugResult.ok ? <JsonPreview data={debugResult.data} /> : <div className="notice">Debug endpoint غیرفعال یا مسدود است: <span className="technical-value">{debugResult.error}</span></div>}
        </Section>
      </div>

      <Section title="Mother diagnostics summary" description="خلاصه telemetry و event aggregation سمت Mother.">
        {summaryResult.ok ? (
          <table className="kv"><tbody>
            <tr><th>Total agents</th><td>{valueOrDash(summary?.total_agents)}</td></tr>
            <tr><th>Telemetry fresh</th><td>{valueOrDash(summary?.telemetry_fresh)}</td></tr>
            <tr><th>Telemetry stale</th><td>{valueOrDash(summary?.telemetry_stale)}</td></tr>
            <tr><th>Telemetry missing</th><td>{valueOrDash(summary?.telemetry_missing)}</td></tr>
            <tr><th>Total received</th><td>{valueOrDash(summary?.total_received)}</td></tr>
            <tr><th>Total mismatched</th><td>{valueOrDash(summary?.total_mismatched)}</td></tr>
          </tbody></table>
        ) : <ErrorState error={summaryResult.error} />}
      </Section>
    </>
  );
}
