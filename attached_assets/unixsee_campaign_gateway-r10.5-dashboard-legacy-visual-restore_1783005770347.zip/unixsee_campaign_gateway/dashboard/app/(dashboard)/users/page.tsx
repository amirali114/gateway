import { revalidatePath } from "next/cache";
import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { currentSession, hasPermission, requirePermission } from "../../../lib/auth";
import { permissionLabel, roleLabel, ROLES, type Role } from "../../../lib/rbac";
import { createUser, listUsers, resetUserPassword, updateUser } from "../../../lib/user-store";

export const dynamic = "force-dynamic";

function actorFromAuth(auth: Awaited<ReturnType<typeof currentSession>>) {
  if (!auth) return undefined;
  return { id: auth.user_id, username: auth.username, role: auth.role === "auth-disabled" ? "owner" as const : auth.role };
}

export default async function UsersPage({ searchParams }: { searchParams?: Promise<{ error?: string; ok?: string }> }) {
  const auth = await requirePermission("users.view");
  const canManage = hasPermission(auth, "users.manage");
  const sp = searchParams ? await searchParams : {};

  async function createUserAction(formData: FormData) {
    "use server";
    const current = await requirePermission("users.manage");
    await createUser({
      username: String(formData.get("username") || ""),
      display_name: String(formData.get("display_name") || ""),
      email: String(formData.get("email") || ""),
      role: String(formData.get("role") || "viewer") as Role,
      status: "active",
      password: String(formData.get("password") || "")
    }, actorFromAuth(current));
    revalidatePath("/users");
  }

  async function updateUserAction(formData: FormData) {
    "use server";
    const current = await requirePermission("users.manage");
    await updateUser(String(formData.get("id") || ""), {
      display_name: String(formData.get("display_name") || ""),
      email: String(formData.get("email") || ""),
      role: String(formData.get("role") || "viewer") as Role,
      status: String(formData.get("status") || "active") as "active" | "disabled"
    }, actorFromAuth(current));
    revalidatePath("/users");
  }

  async function resetPasswordAction(formData: FormData) {
    "use server";
    const current = await requirePermission("users.manage");
    await resetUserPassword(String(formData.get("id") || ""), String(formData.get("new_password") || ""), actorFromAuth(current));
    revalidatePath("/users");
  }

  let users = [] as ReturnType<typeof listUsers>;
  let error = "";
  try { users = listUsers(); } catch (err) { error = err instanceof Error ? err.message : "user store unavailable"; }

  return (
    <>
      <PageHeader title="مدیریت کاربران" description="کاربران محلی Dashboard و نقش‌های RBAC. رمز عبور plaintext هرگز ذخیره یا نمایش داده نمی‌شود." />
      <div className="grid cards">
        <MetricCard title="کاربر فعلی" value={auth.display_name || auth.username} hint={<span className="technical-value">{auth.username}</span>} />
        <MetricCard title="نقش" value={<StatusBadge tone="shadow">{roleLabel(String(auth.role))}</StatusBadge>} />
        <MetricCard title="تعداد کاربران" value={users.length} />
        <MetricCard title="مدیریت کاربران" value={canManage ? <StatusBadge tone="success">مجاز</StatusBadge> : <StatusBadge tone="warning">غیرمجاز</StatusBadge>} />
      </div>
      {sp.error ? <ErrorState error="شما دسترسی لازم برای این عملیات را ندارید." /> : null}
      {error ? <ErrorState error={error} /> : null}

      <Section title="لیست کاربران" description="مالک آخرین حساب owner فعال نمی‌تواند غیرفعال یا downgrade شود.">
        <table className="data-table">
          <thead><tr><th>نام کاربری</th><th>نام نمایشی</th><th>ایمیل</th><th>نقش</th><th>وضعیت</th><th>آخرین ورود</th><th>ویرایش</th><th>Reset</th></tr></thead>
          <tbody>{users.map((u) => <tr key={u.id}>
            <td className="technical-value">{u.username}</td><td>{u.display_name}</td><td className="technical-value">{u.email || "—"}</td><td><StatusBadge tone="shadow">{roleLabel(u.role)}</StatusBadge></td><td><StatusBadge tone={u.status === "active" ? "success" : "danger"}>{u.status === "active" ? "فعال" : "غیرفعال"}</StatusBadge></td><td className="technical-value">{u.last_login_at || "—"}</td>
            <td><form action={updateUserAction} className="inline-form"><input type="hidden" name="id" value={u.id} /><input name="display_name" defaultValue={u.display_name} placeholder="نام نمایشی" disabled={!canManage} /><input name="email" defaultValue={u.email || ""} placeholder="email" disabled={!canManage} /><select name="role" defaultValue={u.role} disabled={!canManage}>{ROLES.map((r) => <option key={r} value={r}>{roleLabel(r)}</option>)}</select><select name="status" defaultValue={u.status} disabled={!canManage}><option value="active">فعال</option><option value="disabled">غیرفعال</option></select><button type="submit" className="button-secondary" disabled={!canManage}>ذخیره</button></form></td>
            <td><form action={resetPasswordAction} className="inline-form"><input type="hidden" name="id" value={u.id} /><input type="password" name="new_password" placeholder="رمز جدید حداقل ۱۰ کاراکتر" disabled={!canManage} /><button type="submit" className="button-secondary" disabled={!canManage}>Reset</button></form></td>
          </tr>)}</tbody>
        </table>
      </Section>

      <Section title="ایجاد کاربر جدید" description="پس از ایجاد، رمز عبور نمایش داده نمی‌شود. برای تحویل امن رمز از کانال خارج از Dashboard استفاده کنید.">
        {canManage ? <form action={createUserAction} className="stack-form"><label>نام کاربری<input name="username" required /></label><label>نام نمایشی<input name="display_name" /></label><label>ایمیل<input name="email" type="email" /></label><label>نقش<select name="role" defaultValue="viewer">{ROLES.map((r) => <option key={r} value={r}>{roleLabel(r)}</option>)}</select></label><label>رمز عبور اولیه<input name="password" type="password" minLength={10} required /></label><div className="form-actions"><button type="submit">ایجاد کاربر</button><span className="small-muted">حداقل طول رمز عبور ۱۰ کاراکتر است.</span></div></form> : <ErrorState error="شما دسترسی لازم برای این عملیات را ندارید." />}
      </Section>

      <Section title="مجوزهای نقش فعلی"><JsonPreview data={auth.permissions.map(permissionLabel)} /></Section>
    </>
  );
}
