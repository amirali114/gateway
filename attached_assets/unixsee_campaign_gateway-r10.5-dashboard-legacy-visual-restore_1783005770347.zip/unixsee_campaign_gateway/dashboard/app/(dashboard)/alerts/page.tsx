import { revalidatePath } from "next/cache";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherAlertSummary, getMotherAlerts, muteMotherAlert, read, resolveMotherAlert, unmuteMotherAlert, valueOrDash } from "../../../lib/api";
import { hasPermission, motherActorHeaders, requirePermission } from "../../../lib/auth";
import { appendAudit } from "../../../lib/user-store";
import type { MotherAlertRecord } from "../../../lib/types";

export const dynamic = "force-dynamic";

function severityLabel(value?: string) {
  switch (value) {
    case "critical": return "بحرانی";
    case "warn": return "هشدار";
    case "info": return "اطلاع";
    default: return valueOrDash(value);
  }
}

function statusLabel(value?: string) {
  switch (value) {
    case "active": return "فعال";
    case "resolved": return "حل‌شده";
    case "muted": return "بی‌صدا";
    default: return valueOrDash(value);
  }
}

function toneForSeverity(value?: string) {
  if (value === "critical") return "danger" as const;
  if (value === "warn") return "warning" as const;
  return "success" as const;
}

function AlertActions({ alert, canManage }: { alert: MotherAlertRecord; canManage: boolean }) {
  if (!canManage || !alert.id) return <span className="small-muted">فقط مشاهده</span>;
  return (
    <div className="form-actions compact-actions">
      <form action={resolveAlertAction}><input type="hidden" name="alert_id" value={alert.id} /><button type="submit" disabled={alert.status === "resolved"}>حل شد</button></form>
      <form action={muteAlertAction}><input type="hidden" name="alert_id" value={alert.id} /><button type="submit" disabled={alert.status === "muted"}>بی‌صدا کردن</button></form>
      <form action={unmuteAlertAction}><input type="hidden" name="alert_id" value={alert.id} /><button type="submit" disabled={alert.status === "active"}>فعال‌سازی دوباره</button></form>
    </div>
  );
}

async function resolveAlertAction(formData: FormData) {
  "use server";
  const auth = await requirePermission("alerts.manage");
  const alertId = String(formData.get("alert_id") || "");
  const res = await resolveMotherAlert(alertId, motherActorHeaders(auth));
  await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "alert_resolved", target_type: "alert", target_id: alertId, result: res.ok ? "success" : "failure", metadata: { error: res.ok ? "" : res.error } });
  revalidatePath("/alerts");
}

async function muteAlertAction(formData: FormData) {
  "use server";
  const auth = await requirePermission("alerts.manage");
  const alertId = String(formData.get("alert_id") || "");
  const res = await muteMotherAlert(alertId, motherActorHeaders(auth));
  await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "alert_muted", target_type: "alert", target_id: alertId, result: res.ok ? "success" : "failure", metadata: { error: res.ok ? "" : res.error } });
  revalidatePath("/alerts");
}

async function unmuteAlertAction(formData: FormData) {
  "use server";
  const auth = await requirePermission("alerts.manage");
  const alertId = String(formData.get("alert_id") || "");
  const res = await unmuteMotherAlert(alertId, motherActorHeaders(auth));
  await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "alert_unmuted", target_type: "alert", target_id: alertId, result: res.ok ? "success" : "failure", metadata: { error: res.ok ? "" : res.error } });
  revalidatePath("/alerts");
}

export default async function AlertsPage() {
  const auth = await requirePermission("alerts.view");
  const canManage = hasPermission(auth, "alerts.manage");
  const [summaryResult, activeResult, historyResult] = await Promise.all([
    getMotherAlertSummary(),
    getMotherAlerts({ status: "active", limit: 200 }),
    getMotherAlerts({ limit: 100 })
  ]);
  const summary = read(summaryResult);
  const activeAlerts = read(activeResult)?.alerts || [];
  const historyAlerts = read(historyResult)?.alerts || [];

  return (
    <>
      <PageHeader title="هشدارها" description="مرکز هشدار داخلی Mother برای staging. هشدارها فقط visibility می‌دهند؛ enforcement یا دستور ریموت اجرا نمی‌شود." />

      <div className="grid cards">
        <MetricCard title="فعال" value={summary?.active_total ?? activeAlerts.length} hint="critical + warn + info" />
        <MetricCard title="بحرانی" value={<StatusBadge tone={(summary?.critical || 0) > 0 ? "danger" : "success"}>{summary?.critical ?? 0}</StatusBadge>} />
        <MetricCard title="هشدار" value={<StatusBadge tone={(summary?.warn || 0) > 0 ? "warning" : "success"}>{summary?.warn ?? 0}</StatusBadge>} />
        <MetricCard title="اطلاع" value={summary?.info ?? 0} />
        <MetricCard title="بی‌صدا" value={summary?.muted ?? 0} />
        <MetricCard title="حل‌شده ۲۴ ساعت" value={summary?.resolved_24h ?? 0} />
      </div>

      <Section title="هشدارهای فعال" description="Deduplication با fingerprint انجام می‌شود و تکرار همان مشکل occurrence_count را بالا می‌برد.">
        {activeResult.ok ? activeAlerts.length > 0 ? (
          <table className="data-table">
            <thead><tr><th>شدت</th><th>وضعیت</th><th>محدوده</th><th>عامل</th><th>عنوان</th><th>اولین مشاهده</th><th>آخرین مشاهده</th><th>تعداد تکرار</th><th>عملیات</th></tr></thead>
            <tbody>{activeAlerts.map((alert) => (
              <tr key={alert.id || alert.fingerprint}>
                <td><StatusBadge tone={toneForSeverity(alert.severity)}>{severityLabel(alert.severity)}</StatusBadge></td>
                <td>{statusLabel(alert.status)}</td>
                <td className="technical-value">{valueOrDash(alert.scope)}</td>
                <td className="technical-value">{valueOrDash(alert.agent_id)}</td>
                <td>{valueOrDash(alert.title)}<div className="small-muted">{valueOrDash(alert.message)}</div></td>
                <td className="technical-value">{valueOrDash(alert.first_seen_at)}</td>
                <td className="technical-value">{valueOrDash(alert.last_seen_at)}</td>
                <td>{valueOrDash(alert.occurrence_count)}</td>
                <td><AlertActions alert={alert} canManage={canManage} /></td>
              </tr>
            ))}</tbody>
          </table>
        ) : <EmptyState title="هشدار فعالی وجود ندارد" description="در صورت stale telemetry، مشکل storage یا rollout، هشدارها اینجا ظاهر می‌شوند." /> : <ErrorState error={activeResult.error} />}
      </Section>

      <Section title="جزئیات امن آخرین هشدارها" description="metadata حساس redacted می‌شود و token/secret/cookie نمایش داده نمی‌شود.">
        {historyResult.ok ? historyAlerts.length > 0 ? <JsonPreview data={historyAlerts.slice(0, 20)} /> : <EmptyState title="تاریخچه هشدار خالی است" /> : <ErrorState error={historyResult.error} />}
      </Section>
    </>
  );
}
