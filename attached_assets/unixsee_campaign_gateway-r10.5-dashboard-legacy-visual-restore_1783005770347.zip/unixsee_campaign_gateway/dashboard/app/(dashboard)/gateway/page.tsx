import { revalidatePath } from "next/cache";
import { AgentSelector } from "../../../components/AgentSelector";
import { ConfigEditor } from "../../../components/ConfigEditor";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { asRecord, controlPlaneConfigFromForm, getMotherAgentConfig, getMotherAgentConfigDiff, getMotherAgentConfigVersions, getMotherAgents, getNestedRecord, postMotherJson, read, valueOrDash } from "../../../lib/api";
import { hasPermission, motherActorHeaders, requirePermission } from "../../../lib/auth";
import { appendAudit } from "../../../lib/user-store";
import type { ControlPlaneConfigRecord, UnknownRecord } from "../../../lib/types";

export const dynamic = "force-dynamic";

type Props = { searchParams?: Promise<{ agent_id?: string }> };

function configFrom(record: unknown): UnknownRecord {
  return getNestedRecord(asRecord(record), "config");
}

function syncLabel(status: unknown): string {
  switch (String(status || "")) {
    case "pending_delivery": return "در انتظار ارسال";
    case "delivered": return "ارسال شده";
    case "acknowledged": return "تأیید شده توسط Agent";
    case "stale": return "قدیمی";
    default: return "نامشخص";
  }
}

export default async function GatewayPage({ searchParams }: Props) {
  const sp = searchParams ? await searchParams : {};
  const agentsResult = await getMotherAgents();
  const agents = read(agentsResult)?.agents || [];
  const selectedAgent = sp.agent_id || agents[0]?.agent_id || "";

  async function saveDraft(formData: FormData) {
    "use server";
    const agentId = String(formData.get("agent_id") || "");
    const auth = await requirePermission("gateway.draft.write");
    if (agentId) {
      const res = await postMotherJson(`/v1/agents/${encodeURIComponent(agentId)}/config/draft`, { config: controlPlaneConfigFromForm(formData), base_version: Number(formData.get("base_version") || 0) }, undefined, motherActorHeaders(auth));
      await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "config_draft_saved", target_type: "agent", target_id: agentId, result: res.ok ? "success" : "failure", metadata: { error: res.ok ? "" : res.error } });
    }
    revalidatePath("/gateway");
  }

  async function validateDraft(formData: FormData) {
    "use server";
    const agentId = String(formData.get("agent_id") || "");
    const auth = await requirePermission("gateway.draft.write");
    if (agentId) await postMotherJson(`/v1/agents/${encodeURIComponent(agentId)}/config/validate`, { config: controlPlaneConfigFromForm(formData) }, undefined, motherActorHeaders(auth));
    revalidatePath("/gateway");
  }

  async function publishDraft(formData: FormData) {
    "use server";
    const agentId = String(formData.get("agent_id") || "");
    const note = String(formData.get("publish_note") || "");
    const auth = await requirePermission("gateway.publish");
    if (agentId) {
      const res = await postMotherJson(`/v1/agents/${encodeURIComponent(agentId)}/config/publish`, { note }, undefined, motherActorHeaders(auth));
      await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "config_published", target_type: "agent", target_id: agentId, result: res.ok ? "success" : "failure", metadata: { note, error: res.ok ? "" : res.error } });
    }
    revalidatePath("/gateway");
  }

  async function rollbackVersion(formData: FormData) {
    "use server";
    const agentId = String(formData.get("agent_id") || "");
    const targetVersion = Number(formData.get("target_version") || 0);
    const note = String(formData.get("rollback_note") || "");
    const auth = await requirePermission("gateway.rollback");
    if (agentId && targetVersion > 0) {
      const res = await postMotherJson(`/v1/agents/${encodeURIComponent(agentId)}/config/rollback`, { target_version: targetVersion, note }, undefined, motherActorHeaders(auth));
      await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "config_rollback", target_type: "agent", target_id: agentId, result: res.ok ? "success" : "failure", metadata: { target_version: targetVersion, note, error: res.ok ? "" : res.error } });
    }
    revalidatePath("/gateway");
  }

  const auth = await requirePermission("gateway.view");
  const canDraft = auth ? hasPermission(auth, "gateway.draft.write") : false;
  const canPublish = auth ? hasPermission(auth, "gateway.publish") : false;
  const canRollback = auth ? hasPermission(auth, "gateway.rollback") : false;
  const [cfgResult, diffResult, versionsResult] = selectedAgent ? await Promise.all([
    getMotherAgentConfig(selectedAgent),
    getMotherAgentConfigDiff(selectedAgent),
    getMotherAgentConfigVersions(selectedAgent)
  ]) : [undefined, undefined, undefined] as const;
  const cfg = cfgResult ? read(cfgResult) : undefined;
  const activeRecord = (cfg?.active_config || {}) as ControlPlaneConfigRecord;
  const draftRecord = (cfg?.draft_config || undefined) as ControlPlaneConfigRecord | undefined;
  const activeConfig = configFrom(activeRecord);
  const gateway = getNestedRecord(activeConfig, "gateway");
  const campaign = getNestedRecord(activeConfig, "campaign");
  const queue = getNestedRecord(activeConfig, "queue");
  const bot = getNestedRecord(activeConfig, "bot");
  const storage = getNestedRecord(activeConfig, "storage");
  const diff = read(diffResult || { ok: false, error: "" })?.diff;
  const versions = read(versionsResult || { ok: false, error: "" })?.versions || [];
  const selectedAgentRecord = agents.find((a) => a.agent_id === selectedAgent);

  return (
    <>
      <PageHeader title="کنترل گیت‌وی" description="Rollout مرحله‌ای config با نسخه immutable، diff، publish tracking و rollback امن. همه writeها فقط به Mother API می‌روند." actions={<StatusBadge value="shadow" />} />

      <div className="grid cards">
        <MetricCard title="Agent انتخاب‌شده" value={<span className="technical-value">{valueOrDash(selectedAgent)}</span>} />
        <MetricCard title="نسخه فعال" value={valueOrDash(activeRecord.version)} hint={<span className="technical-value">{valueOrDash(activeRecord.config_hash)}</span>} />
        <MetricCard title="وضعیت Sync" value={syncLabel(selectedAgentRecord?.config_sync_status)} hint={<span className="technical-value">{valueOrDash(selectedAgentRecord?.last_config_delivered_at)}</span>} />
        <MetricCard title="Draft dirty" value={diff?.dirty ? "تغییر دارد" : "بدون تغییر"} />
        <MetricCard title="Gateway" value={valueOrDash(gateway.enabled)} />
        <MetricCard title="Campaign" value={valueOrDash(campaign.enabled)} />
        <MetricCard title="Queue" value={valueOrDash(queue.enabled)} />
        <MetricCard title="Bot module" value={valueOrDash(bot.enabled)} />
        <MetricCard title="Storage fail mode" value={<span className="technical-value">{valueOrDash(storage.fail_mode)}</span>} />
        <MetricCard title="Default action" value={<span className="technical-value">{valueOrDash(gateway.default_action)}</span>} />
      </div>

      <Section title="انتخاب Agent" description="برای هر Agent rollout مستقل نگه‌داری می‌شود.">
        {agentsResult.ok ? <AgentSelector agents={agents} selectedAgentId={selectedAgent} /> : <ErrorState error={agentsResult.error} />}
      </Section>

      {selectedAgent ? (
        <Section title="ویرایش پیش‌نویس" description="Mode روی shadow-only قفل است. default_action فقط allow/pass و fail_mode فقط open/closed است.">
          {cfgResult?.ok ? <ConfigEditor agentId={selectedAgent} activeConfig={draftRecord?.config || activeConfig} action={saveDraft} disabled={!canDraft} /> : <ErrorState error={cfgResult?.error || "config دریافت نشد"} />}
          <form action={validateDraft} className="form-actions"><input type="hidden" name="agent_id" value={selectedAgent} /><button type="submit" className="button-secondary" disabled={!canDraft}>اعتبارسنجی پیش‌نویس</button><span className="small-muted">اعتبارسنجی بدون انتشار انجام می‌شود.</span></form>
        </Section>
      ) : <EmptyState title="Agentی برای مدیریت انتخاب نشده است" description="بعد از ثبت Agent در Mother، این صفحه فعال می‌شود." />}

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="Diff پیش‌نویس و نسخه فعال"><JsonPreview data={diff || { message: "diff unavailable" }} /></Section>
        <Section title="وضعیت نسخه فعال"><JsonPreview data={activeRecord || null} /></Section>
      </div>

      {selectedAgent ? <Section title="انتشار پیش‌نویس" description="انتشار یک نسخه immutable جدید می‌سازد. نسخه قبلی superseded می‌شود ولی حذف یا mutate نمی‌شود.">
        <form action={publishDraft} className="stack-form">
          <input type="hidden" name="agent_id" value={selectedAgent} />
          <label>یادداشت انتشار<input name="publish_note" placeholder="مثلاً: فعال‌سازی queue در staging" /></label>
          <div className="form-actions"><button type="submit" disabled={!canPublish}>انتشار</button><span className="small-muted">Agent config را در pull بعدی دریافت می‌کند؛ هیچ push یا دستور ریموت وجود ندارد.</span></div>
        </form>
      </Section> : null}

      <Section title="تاریخچه نسخه‌ها و rollback" description="Rollback نسخه قدیمی را mutate نمی‌کند؛ یک نسخه جدید از config قبلی می‌سازد.">
        {versions.length > 0 ? <table className="data-table"><thead><tr><th>نسخه</th><th>وضعیت</th><th>Hash</th><th>زمان انتشار</th><th>منبع</th><th>Rollback</th></tr></thead><tbody>{versions.map((v) => <tr key={v.version}>
          <td>{valueOrDash(v.version)}</td><td><StatusBadge value={v.status || "unknown"} /></td><td className="technical-value">{valueOrDash(v.config_hash)}</td><td className="technical-value">{valueOrDash(v.published_at)}</td><td className="technical-value">{valueOrDash(v.source)}</td><td>{v.version !== activeRecord.version ? <form action={rollbackVersion} className="inline-form"><input type="hidden" name="agent_id" value={selectedAgent} /><input type="hidden" name="target_version" value={v.version || 0} /><input name="rollback_note" placeholder="دلیل rollback" /><button type="submit" className="button-secondary" disabled={!canRollback}>Rollback</button></form> : <span className="small-muted">فعال</span>}</td>
        </tr>)}</tbody></table> : <EmptyState title="نسخه‌ای منتشر نشده است" description="بعد از اولین publish، تاریخچه اینجا نمایش داده می‌شود." />}
      </Section>

      <Section title="اعلان ایمنی"><div className="notice">نقش فعلی شما تعیین می‌کند کدام عملیات فعال باشد. مشاهده‌گر فقط خواندن دارد؛ اپراتور می‌تواند پیش‌نویس ذخیره کند؛ مدیر و مالک می‌توانند انتشار و rollback انجام دهند. انتشار فقط Mother config را به‌روزرسانی می‌کند. Agent shadow-only است، enforcement فعال نمی‌شود، فایل سایت تغییر نمی‌کند و remote command وجود ندارد.</div></Section>
    </>
  );
}
