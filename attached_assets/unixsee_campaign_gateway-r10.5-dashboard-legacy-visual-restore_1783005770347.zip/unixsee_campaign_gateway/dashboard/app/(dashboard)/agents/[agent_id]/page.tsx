import { revalidatePath } from "next/cache";
import { ConfigEditor } from "../../../../components/ConfigEditor";
import { EmptyState } from "../../../../components/EmptyState";
import { ErrorState } from "../../../../components/ErrorState";
import { JsonPreview } from "../../../../components/JsonPreview";
import { MetricCard } from "../../../../components/MetricCard";
import { PageHeader } from "../../../../components/PageHeader";
import { Section } from "../../../../components/Section";
import { StatusBadge } from "../../../../components/StatusBadge";
import { asRecord, controlPlaneConfigFromForm, getMotherAgent, getMotherAlerts, getMotherAgentConfig, getMotherAgentConfigHistory, getMotherAgentConfigVersions, getMotherAgentDiagnostics, getMotherAgentEvents, getMotherAgentTelemetry, getMotherControlPlane, getMotherPolicyAssignment, getNestedRecord, postMotherJson, read, valueOrDash } from "../../../../lib/api";
import { hasPermission, motherActorHeaders, requirePermission } from "../../../../lib/auth";
import { appendAudit } from "../../../../lib/user-store";
import type { UnknownRecord } from "../../../../lib/types";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ agent_id: string }> };

function activeConfigFrom(record: unknown): UnknownRecord {
  const outer = asRecord(record);
  return getNestedRecord(outer, "config");
}

export default async function AgentDetailPage({ params }: Params) {
  const { agent_id } = await params;
  const agentId = decodeURIComponent(agent_id);

  async function saveDraft(formData: FormData) {
    "use server";
    const auth = await requirePermission("gateway.draft.write");
    const res = await postMotherJson(`/v1/agents/${encodeURIComponent(agentId)}/config/draft`, { config: controlPlaneConfigFromForm(formData) }, undefined, motherActorHeaders(auth));
    await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "config_draft_saved", target_type: "agent", target_id: agentId, result: res.ok ? "success" : "failure", metadata: { error: res.ok ? "" : res.error } });
    revalidatePath(`/agents/${encodeURIComponent(agentId)}`);
  }

  async function publishDraft() {
    "use server";
    const auth = await requirePermission("gateway.publish");
    const res = await postMotherJson(`/v1/agents/${encodeURIComponent(agentId)}/config/publish`, {}, undefined, motherActorHeaders(auth));
    await appendAudit({ actor: { id: auth.user_id, username: auth.username, role: auth.role as "owner" | "admin" | "operator" | "viewer" }, action: "config_published", target_type: "agent", target_id: agentId, result: res.ok ? "success" : "failure", metadata: { error: res.ok ? "" : res.error } });
    revalidatePath(`/agents/${encodeURIComponent(agentId)}`);
  }

  const auth = await requirePermission("agents.view");
  const canDraft = auth ? hasPermission(auth, "gateway.draft.write") : false;
  const canPublish = auth ? hasPermission(auth, "gateway.publish") : false;
  const [detailResult, assignmentResult, cpResult, cfgResult, historyResult, versionsResult, telemetryResult, diagnosticsResult, eventsResult, alertsResult] = await Promise.all([
    getMotherAgent(agentId),
    getMotherPolicyAssignment(agentId),
    getMotherControlPlane(agentId),
    getMotherAgentConfig(agentId),
    getMotherAgentConfigHistory(agentId),
    getMotherAgentConfigVersions(agentId),
    getMotherAgentTelemetry(agentId),
    getMotherAgentDiagnostics(agentId),
    getMotherAgentEvents(agentId),
    getMotherAlerts({ status: "active", agent_id: agentId, limit: 100 })
  ]);

  const detail = read(detailResult);
  const assignment = read(assignmentResult);
  const cp = read(cpResult);
  const cfg = read(cfgResult);
  const activeRecord = cfg?.active_config || cp?.active_config || {};
  const activeConfig = activeConfigFrom(activeRecord);
  const draftRecord = cfg?.draft_config || cp?.draft_config;
  const history = read(historyResult)?.history || [];
  const versions = read(versionsResult)?.versions || [];
  const telemetry = read(telemetryResult)?.telemetry;
  const telemetryPayload = asRecord(telemetry?.payload);
  const telemetryControlPlane = getNestedRecord(telemetryPayload, "control_plane");
  const shadowTelemetry = getNestedRecord(telemetryPayload, "shadow");
  const runtimeTelemetry = getNestedRecord(telemetryPayload, "runtime");
  const storageTelemetry = getNestedRecord(telemetryPayload, "storage");
  const comparisonTelemetry = getNestedRecord(shadowTelemetry, "comparison");
  const events = read(eventsResult)?.events || read(diagnosticsResult)?.diagnostics?.events || [];
  const activeAlerts = read(alertsResult)?.alerts || [];

  return (
    <>
      <PageHeader
        title="جزئیات Agent"
        description={<span>مدیریت مرحله‌ای Agent <span className="technical-value">{agentId}</span>. ذخیره و انتشار فقط در Mother انجام می‌شود و Agent همچنان shadow-only است.</span>}
        actions={<><a className="button-link button-secondary" href="/agents">بازگشت</a><a className="button-link" href={`/gateway?agent_id=${encodeURIComponent(agentId)}`}>کنترل گیت‌وی</a></>}
      />

      <div className="grid cards">
        <MetricCard title="وضعیت اتصال" value={<StatusBadge value={detail?.agent?.status || "unknown"} />} hint={<span className="technical-value">{valueOrDash(detail?.agent?.last_seen_at)}</span>} />
        <MetricCard title="تعداد دریافت" value={valueOrDash(detail?.agent?.pull_count)} hint="policy pull از Mother" />
        <MetricCard title="Policy assignment" value={assignment?.assigned ? <StatusBadge tone="success">اختصاص یافته</StatusBadge> : <StatusBadge tone="unknown">پیش‌فرض</StatusBadge>} hint={<span className="technical-value">{assignment?.assigned ? valueOrDash(assignment.policy_id) : "default"}</span>} />
        <MetricCard title="Telemetry" value={<StatusBadge value={detail?.agent?.telemetry_status || "missing"} />} hint={<span className="technical-value">{valueOrDash(detail?.agent?.last_telemetry_at)}</span>} />
        <MetricCard title="نسخه config فعال" value={valueOrDash(detail?.agent?.active_config_version)} hint={<span className="technical-value">{valueOrDash(detail?.agent?.active_config_hash)}</span>} />
        <MetricCard title="Sync config" value={valueOrDash(detail?.agent?.config_sync_status)} hint={`Ack: ${valueOrDash(detail?.agent?.acknowledged_config_version)}`} />
        <MetricCard title="Match rate" value={typeof detail?.agent?.last_match_rate === "number" && detail.agent.last_match_rate > 0 ? `${detail.agent.last_match_rate.toFixed(1)}٪` : "—"} hint={`Mismatch: ${valueOrDash(detail?.agent?.last_mismatched)}`} />
        <MetricCard title="هشدار فعال" value={activeAlerts.length ? <StatusBadge tone={activeAlerts.some((a) => a.severity === "critical") ? "danger" : "warning"}>{activeAlerts.length}</StatusBadge> : <StatusBadge tone="success">۰</StatusBadge>} hint="برای این Agent" />
        <MetricCard title="ایمنی runtime" value={<StatusBadge value="shadow" />} hint="هیچ enforce یا remote command وجود ندارد." />
      </div>

      <Section title="هشدارهای فعال این Agent" description="هشدارها فقط visibility هستند و هیچ enforcement یا دستور ریموت فعال نمی‌کنند.">
        {alertsResult.ok ? activeAlerts.length > 0 ? (
          <table className="data-table"><thead><tr><th>شدت</th><th>محدوده</th><th>نوع</th><th>عنوان</th><th>آخرین مشاهده</th><th>تکرار</th></tr></thead><tbody>{activeAlerts.map((alert) => (
            <tr key={alert.id || alert.fingerprint}><td><StatusBadge tone={alert.severity === "critical" ? "danger" : alert.severity === "warn" ? "warning" : "success"}>{valueOrDash(alert.severity)}</StatusBadge></td><td className="technical-value">{valueOrDash(alert.scope)}</td><td className="technical-value">{valueOrDash(alert.type)}</td><td>{valueOrDash(alert.title)}</td><td className="technical-value">{valueOrDash(alert.last_seen_at)}</td><td>{valueOrDash(alert.occurrence_count)}</td></tr>
          ))}</tbody></table>
        ) : <EmptyState title="هشدار فعالی برای این Agent وجود ندارد" /> : <ErrorState error={alertsResult.error} />}
      </Section>

      <Section title="نمای کلی Agent">
        {detailResult.ok ? (
          <table className="kv"><tbody>
            <tr><th>Agent ID</th><td className="technical-value">{valueOrDash(detail?.agent?.agent_id)}</td></tr>
            <tr><th>اولین مشاهده</th><td className="technical-value">{valueOrDash(detail?.agent?.first_seen_at)}</td></tr>
            <tr><th>آخرین اتصال</th><td className="technical-value">{valueOrDash(detail?.agent?.last_seen_at)}</td></tr>
            <tr><th>آخرین دریافت سیاست</th><td className="technical-value">{valueOrDash(detail?.agent?.last_policy_pull_at)}</td></tr>
            <tr><th>Policy profile</th><td className="technical-value">{valueOrDash(detail?.agent?.last_policy_profile_id)}</td></tr>
            <tr><th>نسخه سیاست</th><td>{valueOrDash(detail?.agent?.last_policy_version)}</td></tr>
            <tr><th>آخرین ارسال config</th><td className="technical-value">{valueOrDash(detail?.agent?.last_config_delivered_at)}</td></tr>
            <tr><th>آخرین تأیید Agent</th><td className="technical-value">{valueOrDash(detail?.agent?.last_config_ack_at)}</td></tr>
            <tr><th>نسخه تأییدشده</th><td>{valueOrDash(detail?.agent?.acknowledged_config_version)}</td></tr>
          </tbody></table>
        ) : <ErrorState error={detailResult.error} />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="Config فعال" description="نسخه‌ای که Agent در pull بعدی می‌تواند دریافت کند.">
          <JsonPreview data={activeRecord || null} />
        </Section>
        <Section title="پیش‌نویس config" description="تا زمان انتشار، پیش‌نویس runtime را تغییر نمی‌دهد.">
          {draftRecord ? <JsonPreview data={draftRecord} /> : <EmptyState title="پیش‌نویسی وجود ندارد" description="از فرم زیر یک پیش‌نویس امن بساز." />}
        </Section>
      </div>

      <Section title="ذخیره پیش‌نویس" description="Mode روی shadow قفل است. default_action فقط allow/pass است و fail_mode فقط open/closed است.">
        <ConfigEditor agentId={agentId} activeConfig={activeConfig} action={saveDraft} disabled={!canDraft} />
      </Section>

      <Section title="انتشار تنظیمات" description="انتشار فقط نسخه فعال را در Mother ثبت می‌کند؛ Agent آن را در pull بعدی می‌گیرد.">
        <form action={publishDraft} className="form-actions">
          <button type="submit" disabled={!canPublish}>انتشار تنظیمات</button>
          <span className="small-muted">نقش فعلی تعیین می‌کند این عملیات مجاز باشد. هیچ push، دستور ریموت یا تغییر مستقیم فایل سایت انجام نمی‌شود.</span>
        </form>
      </Section>

      <Section title="تاریخچه config">
        {versions.length > 0 ? <table className="data-table"><thead><tr><th>نسخه</th><th>وضعیت</th><th>Hash</th><th>منبع</th><th>انتشار</th><th>Ack</th></tr></thead><tbody>{versions.slice(0, 20).map((v) => <tr key={String(v.version)}><td>{valueOrDash(v.version)}</td><td><StatusBadge value={v.status || "unknown"} /></td><td className="technical-value">{valueOrDash(v.config_hash)}</td><td className="technical-value">{valueOrDash(v.source)}</td><td className="technical-value">{valueOrDash(v.published_at)}</td><td className="technical-value">{valueOrDash(v.acknowledged_at)}</td></tr>)}</tbody></table> : history.length > 0 ? <JsonPreview data={history} /> : <EmptyState title="تاریخچه‌ای ثبت نشده است" />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="آخرین telemetry" description="آخرین payload جمع‌آوری‌شده توسط Mother از Agent.">
          {telemetryResult.ok ? telemetry ? <JsonPreview data={telemetry} /> : <EmptyState title="هنوز telemetry از Agent دریافت نشده است." description="Agent در بازه بعدی telemetry را به Mother push می‌کند." /> : <ErrorState error={telemetryResult.error} />}
        </Section>
        <Section title="Shadow counters" description="خلاصه counters از آخرین telemetry.">
          {telemetry ? (
            <table className="kv"><tbody>
              <tr><th>Received</th><td>{valueOrDash(shadowTelemetry.received)}</td></tr>
              <tr><th>Stored</th><td>{valueOrDash(shadowTelemetry.stored)}</td></tr>
              <tr><th>Invalid JSON</th><td>{valueOrDash(shadowTelemetry.invalid_json)}</td></tr>
              <tr><th>Signature failed</th><td>{valueOrDash(shadowTelemetry.signature_failed)}</td></tr>
              <tr><th>Match rate</th><td>{valueOrDash(comparisonTelemetry.match_rate)}</td></tr>
              <tr><th>Mismatched</th><td>{valueOrDash(comparisonTelemetry.mismatched)}</td></tr>
            </tbody></table>
          ) : <EmptyState title="Counter موجود نیست" description="پس از دریافت telemetry، counters اینجا نمایش داده می‌شود." />}
        </Section>
      </div>


      <Section title="Metadata تأیید config از telemetry" description="Agent در telemetry آخرین config version/hash دیده‌شده را گزارش می‌کند.">
        {telemetry ? <JsonPreview data={telemetryControlPlane || { message: "control_plane metadata not reported yet" }} /> : <EmptyState title="metadata موجود نیست" description="بعد از telemetry بعدی، اطلاعات config دریافتی Agent اینجا می‌آید." />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="وضعیت runtime moduleها">
          {telemetry ? (
            <table className="kv"><tbody>
              <tr><th>Gateway</th><td><StatusBadge value={runtimeTelemetry.gateway_enabled} /></td></tr>
              <tr><th>Campaign</th><td><StatusBadge value={runtimeTelemetry.campaign_enabled} /></td></tr>
              <tr><th>Queue</th><td><StatusBadge value={runtimeTelemetry.queue_enabled} /></td></tr>
              <tr><th>Bot</th><td><StatusBadge value={runtimeTelemetry.bot_enabled} /></td></tr>
              <tr><th>Storage fail mode</th><td className="technical-value">{valueOrDash(runtimeTelemetry.storage_fail_mode)}</td></tr>
              <tr><th>Storage status</th><td><StatusBadge tone={storageTelemetry.ok === true ? "success" : "danger"}>{storageTelemetry.ok === true ? "سالم" : "نامشخص"}</StatusBadge></td></tr>
            </tbody></table>
          ) : <EmptyState title="runtime telemetry موجود نیست" />}
        </Section>
        <Section title="By action breakdown">
          {telemetry ? <JsonPreview data={shadowTelemetry.by_action || {}} /> : <EmptyState title="داده‌ای موجود نیست" />}
        </Section>
      </div>

      <Section title="رویدادهای اخیر Agent" description="رویدادهای policy pull، telemetry، draft و publish که Mother نگه می‌دارد.">
        {eventsResult.ok ? events.length > 0 ? (
          <table className="data-table"><thead><tr><th>زمان</th><th>شدت</th><th>نوع</th><th>پیام</th></tr></thead><tbody>{events.slice(0, 20).map((event) => (
            <tr key={event.id || `${event.timestamp}-${event.type}`}>
              <td className="technical-value">{valueOrDash(event.timestamp)}</td>
              <td><StatusBadge tone={event.severity === "error" ? "danger" : event.severity === "warn" ? "warning" : "success"}>{valueOrDash(event.severity || "info")}</StatusBadge></td>
              <td className="technical-value">{valueOrDash(event.type)}</td>
              <td>{valueOrDash(event.message)}</td>
            </tr>
          ))}</tbody></table>
        ) : <EmptyState title="رویدادی ثبت نشده است" /> : <ErrorState error={eventsResult.error} />}
      </Section>

      <Section title="Diagnostics" description="همه داده‌ها از Mother API خوانده می‌شود و هیچ اتصال مستقیم Dashboard به Agent وجود ندارد.">
        <div className="notice">Agent همچنان shadow-only است و این صفحه هیچ ابزار دستور ریموت، حذف Agent یا enforce ندارد.</div>
      </Section>
    </>
  );
}
