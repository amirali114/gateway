import { EmptyAgentState } from "../../../components/EmptyAgentState";
import { ErrorState } from "../../../components/ErrorState";
import { HeroStatus } from "../../../components/HeroStatus";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherAgents, getMotherAlerts, getMotherDiagnosticsSummary, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

function formatRate(value: unknown): string {
  const n = typeof value === "number" ? value : Number(value || 0);
  return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}٪` : "—";
}

export default async function AgentsPage() {
  await requirePermission("agents.view");

  const [agentsResult, summaryResult, alertsResult] = await Promise.all([getMotherAgents(), getMotherDiagnosticsSummary(), getMotherAlerts({ status: "active", limit: 500 })]);
  const agents = read(agentsResult)?.agents || [];
  const summary = read(summaryResult)?.summary;
  const online = summary?.online_agents ?? agents.filter((agent) => agent.status === "online").length;
  const stale = summary?.stale_agents ?? agents.filter((agent) => agent.status === "stale").length;
  const unknown = summary?.unknown_agents ?? Math.max(0, agents.length - online - stale);
  const alerts = read(alertsResult)?.alerts || [];
  const alertCounts = new Map<string, { critical: number; warn: number; latest: string }>();
  for (const alert of alerts) {
    const key = String(alert.agent_id || "");
    if (!key) continue;
    const cur = alertCounts.get(key) || { critical: 0, warn: 0, latest: "" };
    if (alert.severity === "critical") cur.critical++;
    if (alert.severity === "warn") cur.warn++;
    if (String(alert.last_seen_at || "") > cur.latest) cur.latest = String(alert.last_seen_at || "");
    alertCounts.set(key, cur);
  }

  return (
    <>
      <PageHeader
        title="سایت‌ها / Agentها"
        description="نمای premium از Agent registry و telemetry aggregate. هیچ fetch مستقیمی از مرورگر به Agent انجام نمی‌شود."
      />

      <HeroStatus
        tone={agents.length === 0 ? "neutral" : stale > 0 ? "warn" : "safe"}
        eyebrow="Agent fleet"
        title={agents.length === 0 ? "در انتظار اولین Agent" : `${agents.length} Agent ثبت‌شده`}
        description="بعد از نصب Agent، policy pull و telemetry push، وضعیت اتصال، freshness، match rate و alertهای هر سایت اینجا نمایش داده می‌شود."
      />

      <div className="grid cards">
        <MetricCard title="کل Agentها" value={agentsResult.ok ? agents.length : "—"} hint={agentsResult.ok ? "Registry سمت Mother" : agentsResult.error} />
        <MetricCard title="آنلاین" value={online} />
        <MetricCard title="قدیمی" value={<StatusBadge tone={stale > 0 ? "warning" : "success"}>{stale}</StatusBadge>} />
        <MetricCard title="نامشخص" value={unknown} />
        <MetricCard title="Telemetry تازه" value={summary?.telemetry_fresh ?? 0} hint={`دریافت‌نشده: ${summary?.telemetry_missing ?? 0}`} />
        <MetricCard title="هشدارهای فعال" value={<StatusBadge tone={alerts.length > 0 ? "warning" : "success"}>{alerts.length}</StatusBadge>} />
      </div>

      <Section title="لیست Agentها" description="برای جزئیات config rollout، telemetry و alertهای هر Agent روی ردیف کلیک کن.">
        {agentsResult.ok ? agents.length > 0 ? (
          <table className="data-table polished-table">
            <thead><tr><th>Agent ID</th><th>وضعیت</th><th>Telemetry</th><th>آخرین telemetry</th><th>Match rate</th><th>Received</th><th>Mismatch</th><th>Config sync</th><th>هشدار</th><th>جزئیات</th></tr></thead>
            <tbody>{agents.map((agent) => {
              const id = agent.agent_id || "";
              const counts = alertCounts.get(id) || { critical: 0, warn: 0, latest: "" };
              return (
                <tr key={id || Math.random()}>
                  <td className="technical-value">{valueOrDash(id)}</td>
                  <td><StatusBadge value={agent.status || "unknown"} /></td>
                  <td><StatusBadge value={agent.telemetry_status || "missing"} /></td>
                  <td className="technical-value">{valueOrDash(agent.last_telemetry_at)}</td>
                  <td>{formatRate(agent.last_match_rate)}</td>
                  <td>{valueOrDash(agent.last_received)}</td>
                  <td>{valueOrDash(agent.last_mismatched)}</td>
                  <td><StatusBadge value={agent.config_sync_status || "unknown"} /></td>
                  <td><StatusBadge tone={counts.critical > 0 ? "danger" : counts.warn > 0 ? "warning" : "success"}>{counts.critical} / {counts.warn}</StatusBadge><div className="small-muted technical-value">{valueOrDash(counts.latest)}</div></td>
                  <td><a className="button-link button-secondary" href={`/agents/${encodeURIComponent(id)}`}>مشاهده</a></td>
                </tr>
              );
            })}</tbody>
          </table>
        ) : <EmptyAgentState /> : <ErrorState error={agentsResult.error} />}
      </Section>

      {agents.length === 0 ? (
        <Section title="قدم‌های بعدی نصب Agent">
          <div className="checklist-cards">
            <div className="check-card">Secret مشترک Mother-Agent را روی Client provision کن.</div>
            <div className="check-card">Agent را فقط روی <span className="technical-value">127.0.0.1:8731</span> اجرا کن.</div>
            <div className="check-card">از Client، <span className="technical-value">MOTHER_PUBLIC_URL/healthz</span> را قبل از apply تست کن.</div>
            <div className="check-card">بعد از public Gateway hit، telemetry و counters باید در Mother تغییر کنند.</div>
          </div>
        </Section>
      ) : null}
    </>
  );
}
