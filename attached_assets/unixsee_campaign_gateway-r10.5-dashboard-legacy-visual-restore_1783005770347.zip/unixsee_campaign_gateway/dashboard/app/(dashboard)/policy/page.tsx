import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherPolicies, getMotherPolicy, read, valueOrDash } from "../../../lib/api";

import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

export default async function PolicyPage() {
  await requirePermission("policy.view");

  const [policiesResult, defaultPolicyResult] = await Promise.all([
    getMotherPolicies(),
    getMotherPolicy("default")
  ]);

  const policies = read(policiesResult)?.policies || [];
  const defaultPolicy = read(defaultPolicyResult)?.policy;
  const profile = defaultPolicy?.profile || {};

  return (
    <>
      <PageHeader
        title="سیاست‌ها"
        description="نمای read-only از سیاست‌های Mother. تغییرات per-agent از صفحه کنترل گیت‌وی و از مسیر draft/publish انجام می‌شود."
        actions={<a className="button-link" href="/gateway">رفتن به کنترل گیت‌وی</a>}
      />

      <div className="grid cards">
        <MetricCard title="Policy profile" value={<span className="technical-value">{valueOrDash(defaultPolicy?.profile_id)}</span>} />
        <MetricCard title="نسخه" value={valueOrDash(defaultPolicy?.version)} />
        <MetricCard title="Source" value={<span className="technical-value">{valueOrDash(defaultPolicy?.source)}</span>} />
        <MetricCard title="Default" value={defaultPolicy?.is_default ? <StatusBadge tone="success">پیش‌فرض</StatusBadge> : "—"} />
      </div>

      <Section title="فهرست سیاست‌های Mother">
        {policiesResult.ok ? (
          <table className="data-table">
            <thead><tr><th>ID</th><th>Profile ID</th><th>Version</th><th>Source</th><th>Default</th></tr></thead>
            <tbody>{policies.map((policy) => (
              <tr key={policy.id || Math.random()}>
                <td className="technical-value">{valueOrDash(policy.id)}</td>
                <td className="technical-value">{valueOrDash(policy.profile_id)}</td>
                <td>{valueOrDash(policy.version)}</td>
                <td className="technical-value">{valueOrDash(policy.source)}</td>
                <td>{valueOrDash(policy.is_default)}</td>
              </tr>
            ))}</tbody>
          </table>
        ) : <ErrorState error={policiesResult.error} />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="ماژول‌های فعال در سیاست پیش‌فرض">
          {defaultPolicyResult.ok ? (
            <table className="kv"><tbody>
              <tr><th>Gateway</th><td>{valueOrDash((profile.gateway as { enabled?: boolean } | undefined)?.enabled)}</td></tr>
              <tr><th>Campaign</th><td>{valueOrDash((profile.campaign as { enabled?: boolean } | undefined)?.enabled)}</td></tr>
              <tr><th>Storage fail mode</th><td className="technical-value">{valueOrDash((profile.storage as { fail_mode?: string } | undefined)?.fail_mode)}</td></tr>
              <tr><th>Queue</th><td>{valueOrDash((profile.queue as { enabled?: boolean } | undefined)?.enabled)}</td></tr>
              <tr><th>Bot</th><td>{valueOrDash((profile.bot as { enabled?: boolean } | undefined)?.enabled)}</td></tr>
            </tbody></table>
          ) : <ErrorState error={defaultPolicyResult.error} />}
        </Section>
        <Section title="Preview سیاست پیش‌فرض"><JsonPreview data={defaultPolicyResult.ok ? defaultPolicyResult.data : defaultPolicyResult} /></Section>
      </div>
    </>
  );
}
