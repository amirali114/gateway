import { EmptyState } from "../../components/EmptyState";
import { ErrorState } from "../../components/ErrorState";
import { HeroStatus } from "../../components/HeroStatus";
import { MetricCard } from "../../components/MetricCard";
import { PageHeader } from "../../components/PageHeader";
import { SafetyPill } from "../../components/SafetyPill";
import { Section } from "../../components/Section";
import { StatusBadge } from "../../components/StatusBadge";
import { getMotherAgents, getMotherAlertSummary, getMotherDiagnosticsSummary, getMotherHealth, getMotherPolicy, getMotherReady, getMotherReleaseGateSummary, read, valueOrDash } from "../../lib/api";
import type { MotherEventRecord } from "../../lib/types";

import { requirePermission } from "../../lib/auth";

export const dynamic = "force-dynamic";

function formatRate(value: unknown): string {
  const n = typeof value === "number" ? value : Number(value || 0);
  return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}٪` : "—";
}

function renderEvent(event: MotherEventRecord) {
  return (
    <tr key={event.id || `${event.timestamp}-${event.type}`}>
      <td className="technical-value">{valueOrDash(event.timestamp)}</td>
      <td><StatusBadge tone={event.severity === "error" ? "danger" : event.severity === "warn" ? "warning" : "success"}>{valueOrDash(event.severity || "info")}</StatusBadge></td>
      <td className="technical-value">{valueOrDash(event.agent_id)}</td>
      <td className="technical-value">{valueOrDash(event.type)}</td>
      <td>{valueOrDash(event.message)}</td>
    </tr>
  );
}

export default async function OverviewPage() {
  await requirePermission("dashboard.view");

  const [healthResult, readyResult, agentsResult, defaultPolicyResult, summaryResult, alertSummaryResult, releaseSummaryResult] = await Promise.all([
    getMotherHealth(),
    getMotherReady(),
    getMotherAgents(),
    getMotherPolicy("default"),
    getMotherDiagnosticsSummary(),
    getMotherAlertSummary(),
    getMotherReleaseGateSummary()
  ]);

  const health = read(healthResult);
  const ready = read(readyResult);
  const agents = read(agentsResult)?.agents || [];
  const defaultPolicy = read(defaultPolicyResult)?.policy;
  const summary = read(summaryResult)?.summary;
  const recentEvents = summary?.recent_events || [];
  const alertSummary = read(alertSummaryResult);
  const releaseSummary = read(releaseSummaryResult);

  const online = summary?.online_agents ?? agents.filter((agent) => agent.status === "online").length;
  const stale = summary?.stale_agents ?? agents.filter((agent) => agent.status === "stale").length;
  const unknown = summary?.unknown_agents ?? Math.max(0, agents.length - online - stale);
  const overallHealth = (alertSummary?.critical || 0) > 0 ? "بحرانی" : (alertSummary?.warn || 0) > 0 || stale > 0 ? "نیازمند بررسی" : "سالم";
  const releaseLabel = releaseSummary?.fail && releaseSummary.fail > 0 ? "مسدود" : (releaseSummary?.unknown || 0) > 0 || (releaseSummary?.skipped || 0) > 0 ? "نیازمند تکمیل" : "آماده مشروط";

  return (
    <>
      <PageHeader
        title="نمای کلی"
        description="داشبورد premium Unixsee برای کنترل محدود staging. UI فقط Mother API را می‌خواند و raw JSON در نمای اصلی غالب نیست."
      />

      <HeroStatus
        tone={overallHealth === "بحرانی" ? "danger" : overallHealth === "نیازمند بررسی" ? "warn" : "safe"}
        eyebrow="Unixsee controlled beta"
        title={overallHealth}
        description="نمای تجمیعی Core health، آمادگی Mother، storage، release gates، telemetry و وضعیت امنیتی بدون فعال‌سازی enforcement."
      >
        <SafetyPill label="PHP" value="منبع runtime" tone="gold" />
        <SafetyPill label="Agent" value="shadow-only" tone="safe" />
        <SafetyPill label="Dashboard" value="Mother API only" tone="neutral" />
      </HeroStatus>

      <div className="grid cards">
        <MetricCard title="وضعیت کلی" value={<StatusBadge tone={overallHealth === "بحرانی" ? "danger" : overallHealth === "نیازمند بررسی" ? "warning" : "success"}>{overallHealth}</StatusBadge>} hint="براساس health + telemetry + alerts" />
        <MetricCard title="سلامت Mother" value={<StatusBadge tone={health?.ok ? "success" : "danger"}>{health?.ok ? "سالم" : "خطا"}</StatusBadge>} hint={healthResult.ok ? "Core API" : healthResult.error} />
        <MetricCard title="آمادگی Mother" value={<StatusBadge tone={ready?.ok ? "success" : "danger"}>{ready?.ok ? "آماده" : "نا‌آماده"}</StatusBadge>} hint={readyResult.ok ? valueOrDash(ready?.storage) : readyResult.error} />
        <MetricCard title="کل Agentها" value={summary?.total_agents ?? agents.length} hint="ثبت‌شده در Mother registry" />
        <MetricCard title="آنلاین / قدیمی / نامشخص" value={`${online} / ${stale} / ${unknown}`} />
      </div>

      <div className="grid cards" style={{ marginTop: 16 }}>
        <MetricCard title="Telemetry تازه" value={summary?.telemetry_fresh ?? 0} hint={`قدیمی: ${summary?.telemetry_stale ?? 0} | دریافت‌نشده: ${summary?.telemetry_missing ?? 0}`} />
        <MetricCard title="میانگین Match Rate" value={formatRate(summary?.average_match_rate)} hint="از آخرین telemetry Agentها" />
        <MetricCard title="Shadow payloadها" value={summary?.total_received ?? 0} hint="مجموع دریافتی از آخرین telemetry" />
        <MetricCard title="Mismatchها" value={summary?.total_mismatched ?? 0} hint="مجموع mismatch گزارش‌شده" />
        <MetricCard title="هشدار بحرانی" value={<StatusBadge tone={(alertSummary?.critical || 0) > 0 ? "danger" : "success"}>{alertSummary?.critical ?? 0}</StatusBadge>} hint={`warn: ${alertSummary?.warn ?? 0}`} />
        <MetricCard title="Config rollout" value={`${summary?.configs_pending_delivery ?? 0} / ${summary?.configs_delivered ?? 0} / ${summary?.configs_acknowledged ?? 0}`} hint="pending / delivered / acknowledged" />
        <MetricCard title="آمادگی انتشار" value={<StatusBadge tone={releaseLabel === "مسدود" ? "danger" : releaseLabel === "نیازمند تکمیل" ? "warning" : "success"}>{releaseLabel}</StatusBadge>} hint={`fail: ${releaseSummary?.fail ?? 0} | warn: ${releaseSummary?.warn ?? 0}`} />
      </div>

      <Section title="خلاصه آمادگی انتشار" description="Release gates فقط readiness عملیاتی را نشان می‌دهد و مکانیزم enforcement نیست.">
        {releaseSummaryResult.ok ? (
          <div className="notice">وضعیت: <b>{releaseLabel}</b> — عبور کرده: {releaseSummary?.pass ?? 0}، هشدار: {releaseSummary?.warn ?? 0}، شکست: {releaseSummary?.fail ?? 0}. <a className="link" href="/release">مشاهده صفحه آمادگی انتشار</a></div>
        ) : <ErrorState error={releaseSummaryResult.error} />}
      </Section>

      <Section title="آخرین هشدارها" description="Alert Center داخلی؛ هشدارها enforcement یا remote command اجرا نمی‌کنند.">
        {alertSummaryResult.ok && (alertSummary?.latest || []).length > 0 ? (
          <table className="data-table"><thead><tr><th>شدت</th><th>محدوده</th><th>Agent</th><th>عنوان</th><th>آخرین مشاهده</th></tr></thead><tbody>{(alertSummary?.latest || []).slice(0, 6).map((alert) => (
            <tr key={alert.id || alert.fingerprint}><td><StatusBadge tone={alert.severity === "critical" ? "danger" : alert.severity === "warn" ? "warning" : "success"}>{valueOrDash(alert.severity)}</StatusBadge></td><td className="technical-value">{valueOrDash(alert.scope)}</td><td className="technical-value">{valueOrDash(alert.agent_id)}</td><td>{valueOrDash(alert.title)}</td><td className="technical-value">{valueOrDash(alert.last_seen_at)}</td></tr>
          ))}</tbody></table>
        ) : <EmptyState title="هشدار فعالی دیده نمی‌شود" description="برای جزئیات کامل به صفحه هشدارها برو." />}
      </Section>

      <Section title="هشدارهای ایمنی" description="این کنترل‌پلین هنوز برای staging است و نباید عمومی expose شود.">
        <div className="notice">حالت runtime همچنان سایه‌ای است؛ هیچ enforce، دستور ریموت یا اتصال مستقیم Dashboard به Agent وجود ندارد.</div>
        <ul className="safety-list" style={{ marginTop: 12 }}>
          <li>PHP Gateway منبع تصمیم نهایی request handling است.</li>
          <li>تنظیمات فقط به Mother draft/publish نوشته می‌شود و Agent در pull بعدی آن را می‌بیند.</li>
          <li>در صورت نبود telemetry، Dashboard خطا نمی‌دهد و وضعیت دریافت‌نشده نمایش می‌دهد.</li>
        </ul>
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="نسخه سیاست پیش‌فرض Mother">
          {defaultPolicyResult.ok ? (
            <table className="kv"><tbody>
              <tr><th>Policy ID</th><td className="technical-value">{valueOrDash(defaultPolicy?.id)}</td></tr>
              <tr><th>Profile ID</th><td className="technical-value">{valueOrDash(defaultPolicy?.profile_id)}</td></tr>
              <tr><th>نسخه سیاست</th><td>{valueOrDash(defaultPolicy?.version)}</td></tr>
              <tr><th>Source</th><td className="technical-value">{valueOrDash(defaultPolicy?.source)}</td></tr>
            </tbody></table>
          ) : <ErrorState error={defaultPolicyResult.error} />}
        </Section>

        <Section title="آخرین رویدادها" description="رویدادهای جمع‌شده از Mother event buffer.">
          {summaryResult.ok ? recentEvents.length > 0 ? (
            <table className="data-table"><thead><tr><th>زمان</th><th>شدت</th><th>Agent</th><th>نوع</th><th>پیام</th></tr></thead><tbody>{recentEvents.slice(0, 8).map(renderEvent)}</tbody></table>
          ) : <EmptyState title="هنوز رویدادی ثبت نشده است" description="پس از policy pull، telemetry یا publish config، این بخش پر می‌شود." /> : <ErrorState error={summaryResult.error} />}
        </Section>
      </div>
    </>
  );
}
