import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherAgents, read, valueOrDash } from "../../../lib/api";

export const dynamic = "force-dynamic";

export default async function SyncPage() {
  const agentsResult = await getMotherAgents();
  const agents = read(agentsResult)?.agents || [];
  const latest = [...agents].sort((a, b) => String(b.last_policy_pull_at || "").localeCompare(String(a.last_policy_pull_at || "")))[0];

  return (
    <>
      <PageHeader
        title="همگام‌سازی سیاست"
        description="نمای Mother-side از policy pullها. این صفحه به Agent مستقیم وصل نمی‌شود و فقط registry سمت Mother را نشان می‌دهد."
      />
      <div className="grid cards">
        <MetricCard title="Agentهای ثبت‌شده" value={agentsResult.ok ? agents.length : "—"} hint={agentsResult.ok ? "از Mother registry" : agentsResult.error} />
        <MetricCard title="آخرین Agent دریافت‌کننده" value={<span className="technical-value">{valueOrDash(latest?.agent_id)}</span>} />
        <MetricCard title="آخرین دریافت" value={<span className="technical-value">{valueOrDash(latest?.last_policy_pull_at)}</span>} />
        <MetricCard title="حالت runtime" value={<StatusBadge value="shadow" />} hint="Agent همچنان enforcement ندارد." />
      </div>
      <Section title="Policy pull registry">
        {agentsResult.ok ? (
          <table className="data-table">
            <thead><tr><th>Agent ID</th><th>وضعیت</th><th>آخرین policy pull</th><th>Policy</th><th>نسخه</th><th>Pull count</th></tr></thead>
            <tbody>{agents.map((agent) => (
              <tr key={agent.agent_id || Math.random()}>
                <td className="technical-value">{valueOrDash(agent.agent_id)}</td>
                <td><StatusBadge value={agent.status || "unknown"} /></td>
                <td className="technical-value">{valueOrDash(agent.last_policy_pull_at)}</td>
                <td className="technical-value">{valueOrDash(agent.last_policy_profile_id)}</td>
                <td>{valueOrDash(agent.last_policy_version)}</td>
                <td>{valueOrDash(agent.pull_count)}</td>
              </tr>
            ))}</tbody>
          </table>
        ) : <ErrorState error={agentsResult.error} />}
      </Section>
      <Section title="پاسخ خام"><JsonPreview data={agentsResult.ok ? agentsResult.data : agentsResult} /></Section>
    </>
  );
}
