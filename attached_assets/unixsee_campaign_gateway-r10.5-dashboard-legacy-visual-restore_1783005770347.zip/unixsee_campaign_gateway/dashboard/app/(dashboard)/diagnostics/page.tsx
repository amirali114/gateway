import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherAgents, getMotherAlertSummary, getMotherDiagnosticsSummary, getMotherHealth, getMotherHealthReport, getMotherReady, getMotherStorageStatus, read, valueOrDash } from "../../../lib/api";

import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";

function formatRate(value: unknown): string {
  const n = typeof value === "number" ? value : Number(value || 0);
  return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}٪` : "—";
}

export default async function DiagnosticsPage() {
  await requirePermission("diagnostics.view");

  const [healthResult, readyResult, agentsResult, summaryResult, storageResult, alertSummaryResult, healthReportResult] = await Promise.all([
    getMotherHealth(),
    getMotherReady(),
    getMotherAgents(),
    getMotherDiagnosticsSummary(),
    getMotherStorageStatus(),
    getMotherAlertSummary(),
    getMotherHealthReport()
  ]);
  const health = read(healthResult);
  const ready = read(readyResult);
  const agents = read(agentsResult)?.agents || [];
  const summary = read(summaryResult)?.summary;
  const recentEvents = summary?.recent_events || [];
  const storage = read(storageResult);
  const alertSummary = read(alertSummaryResult);
  const healthReport = read(healthReportResult);

  return (
    <>
      <PageHeader
        title="لاگ‌ها و عیب‌یابی"
        description="خلاصه عملیاتی از Mother، Agent registry، telemetry health و رویدادهای اخیر. هیچ fetch مستقیمی به Agent انجام نمی‌شود."
      />

      <div className="grid cards">
        <MetricCard title="Mother health" value={healthResult.ok ? <StatusBadge tone="success">سالم</StatusBadge> : <StatusBadge tone="danger">قطع</StatusBadge>} hint={healthResult.ok ? valueOrDash(health?.service) : healthResult.error} />
        <MetricCard title="Mother ready" value={readyResult.ok && ready?.ok ? <StatusBadge tone="success">آماده</StatusBadge> : <StatusBadge tone="warning">نیازمند بررسی</StatusBadge>} hint={readyResult.ok ? valueOrDash(ready?.storage) : readyResult.error} />
        <MetricCard title="Telemetry تازه / قدیمی / دریافت‌نشده" value={`${summary?.telemetry_fresh ?? 0} / ${summary?.telemetry_stale ?? 0} / ${summary?.telemetry_missing ?? 0}`} />
        <MetricCard title="میانگین Match rate" value={formatRate(summary?.average_match_rate)} />
        <MetricCard title="کل shadow payloadها" value={summary?.total_received ?? 0} />
        <MetricCard title="کل mismatchها" value={summary?.total_mismatched ?? 0} />
        <MetricCard title="Storage engine" value={<span className="technical-value">{valueOrDash(storage?.engine || ready?.storage_engine)}</span>} hint={storage?.engine === "postgres" ? "production SQL profile" : storage?.engine === "memory" ? "هشدار: volatile" : "persistent JSON"} />
        <MetricCard title="DB connection" value={storage?.engine === "postgres" ? (storage?.database_connected ? <StatusBadge tone="success">متصل</StatusBadge> : <StatusBadge tone="danger">قطع</StatusBadge>) : <StatusBadge tone="warning">JSON</StatusBadge>} hint={storage?.engine === "postgres" ? valueOrDash(storage?.migration_status) : "PostgreSQL فعال نیست"} />
        <MetricCard title="Schema version" value={<span className="technical-value">{valueOrDash(storage?.schema_version)}</span>} hint={valueOrDash(storage?.dsn_redacted)} />
        <MetricCard title="Storage writable" value={storage?.writable ? <StatusBadge tone="success">قابل نوشتن</StatusBadge> : <StatusBadge tone="warning">نیازمند بررسی</StatusBadge>} hint={storageResult.ok ? valueOrDash(storage?.last_error) : storageResult.error} />
        <MetricCard title="Configs منتشرشده" value={summary?.configs_published_total ?? 0} />
        <MetricCard title="در انتظار ارسال" value={summary?.configs_pending_delivery ?? 0} />
        <MetricCard title="ارسال‌شده" value={summary?.configs_delivered ?? 0} />
        <MetricCard title="تأییدشده" value={summary?.configs_acknowledged ?? 0} />
        <MetricCard title="Rollbackها" value={summary?.rollbacks_total ?? 0} />
        <MetricCard title="Alert بحرانی" value={<StatusBadge tone={(alertSummary?.critical || 0) > 0 ? "danger" : "success"}>{alertSummary?.critical ?? 0}</StatusBadge>} hint={`warn: ${alertSummary?.warn ?? 0}`} />
        <MetricCard title="Alert فعال" value={alertSummary?.active_total ?? 0} />
      </div>

      <Section title="Alert summary" description="خلاصه هشدارهای فعال، resolve شده و muted. هیچ secret در response نمایش داده نمی‌شود.">
        {alertSummaryResult.ok ? <JsonPreview data={alertSummary} /> : <ErrorState error={alertSummaryResult.error} />}
      </Section>

      <Section title="Health report امن" description="گزارش تجمیعی Mother، storage، telemetry، rollout و alert بدون token/secret.">
        {healthReportResult.ok ? <JsonPreview data={healthReport} /> : <ErrorState error={healthReportResult.error} />}
      </Section>

      <Section title="Agent telemetry health" description="Agentهایی که telemetry ندارند با وضعیت دریافت‌نشده مشخص می‌شوند.">
        {agentsResult.ok ? agents.length > 0 ? (
          <table className="data-table">
            <thead><tr><th>Agent ID</th><th>اتصال</th><th>Telemetry</th><th>آخرین telemetry</th><th>Match rate</th><th>Received</th><th>Mismatch</th></tr></thead>
            <tbody>{agents.map((agent) => (
              <tr key={agent.agent_id || Math.random()}>
                <td className="technical-value">{valueOrDash(agent.agent_id)}</td>
                <td><StatusBadge value={agent.status || "unknown"} /></td>
                <td><StatusBadge value={agent.telemetry_status || "missing"} /></td>
                <td className="technical-value">{valueOrDash(agent.last_telemetry_at)}</td>
                <td>{formatRate(agent.last_match_rate)}</td>
                <td>{valueOrDash(agent.last_received)}</td>
                <td>{valueOrDash(agent.last_mismatched)}</td>
              </tr>
            ))}</tbody>
          </table>
        ) : <EmptyState title="هنوز Agent ثبت نشده است" description="پس از policy pull یا telemetry push، این جدول پر می‌شود." /> : <ErrorState error={agentsResult.error} />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="Agentهای stale / mismatch">
          {summaryResult.ok ? (
            <table className="kv"><tbody>
              <tr><th>Stale agents</th><td className="technical-value">{(summary?.stale_agent_ids || []).join(", ") || "—"}</td></tr>
              <tr><th>Mismatched agents</th><td className="technical-value">{(summary?.mismatched_agent_ids || []).join(", ") || "—"}</td></tr>
            </tbody></table>
          ) : <ErrorState error={summaryResult.error} />}
        </Section>
        <Section title="وضعیت Mother storage">
          {storageResult.ok ? (
            <table className="kv"><tbody>
              <tr><th>Engine</th><td className="technical-value">{valueOrDash(storage?.engine)}</td></tr>
              <tr><th>Path</th><td className="technical-value">{valueOrDash(storage?.path)}</td></tr>
              <tr><th>Last load</th><td className="technical-value">{valueOrDash(storage?.last_load_at)}</td></tr>
              <tr><th>Last save</th><td className="technical-value">{valueOrDash(storage?.last_save_at)}</td></tr>
              <tr><th>Last error</th><td>{valueOrDash(storage?.last_error)}</td></tr>
              <tr><th>Database connected</th><td>{valueOrDash(storage?.database_connected)}</td></tr>
              <tr><th>Schema version</th><td className="technical-value">{valueOrDash(storage?.schema_version)}</td></tr>
              <tr><th>Migration status</th><td className="technical-value">{valueOrDash(storage?.migration_status)}</td></tr>
              <tr><th>DSN redacted</th><td className="technical-value">{valueOrDash(storage?.dsn_redacted)}</td></tr>
            </tbody></table>
          ) : <ErrorState error={storageResult.error} />}
        </Section>
        <Section title="هشدار telemetry missing">
          {(summary?.telemetry_missing || 0) > 0 ? <div className="notice">هنوز telemetry از برخی Agentها دریافت نشده است. Agent در interval بعدی telemetry را به Mother push می‌کند.</div> : <div className="notice">Telemetry برای Agentهای شناخته‌شده تازه است یا هنوز Agentی ثبت نشده است.</div>}
        </Section>
      </div>

      <Section title="رویدادهای rollout config">
        {summaryResult.ok && (summary?.latest_config_events || []).length > 0 ? <JsonPreview data={summary?.latest_config_events} /> : <EmptyState title="رویداد config ثبت نشده است" description="publish، delivery، ack و rollback اینجا خلاصه می‌شوند." />}
      </Section>

      <Section title="رویدادهای اخیر">
        {summaryResult.ok ? recentEvents.length > 0 ? (
          <table className="data-table"><thead><tr><th>زمان</th><th>شدت</th><th>Agent</th><th>نوع</th><th>پیام</th></tr></thead><tbody>{recentEvents.slice(0, 30).map((event) => (
            <tr key={event.id || `${event.timestamp}-${event.type}`}>
              <td className="technical-value">{valueOrDash(event.timestamp)}</td>
              <td><StatusBadge tone={event.severity === "error" ? "danger" : event.severity === "warn" ? "warning" : "success"}>{valueOrDash(event.severity || "info")}</StatusBadge></td>
              <td className="technical-value">{valueOrDash(event.agent_id)}</td>
              <td className="technical-value">{valueOrDash(event.type)}</td>
              <td>{valueOrDash(event.message)}</td>
            </tr>
          ))}</tbody></table>
        ) : <EmptyState title="هنوز رویدادی ثبت نشده است" description="policy pull، telemetry، draft و publish اینجا دیده می‌شوند." /> : <ErrorState error={summaryResult.error} />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="Mother health raw"><JsonPreview data={healthResult.ok ? healthResult.data : healthResult} /></Section>
        <Section title="Diagnostics summary raw"><JsonPreview data={summaryResult.ok ? summaryResult.data : summaryResult} /></Section>
        <Section title="Storage raw"><JsonPreview data={storageResult.ok ? storageResult.data : storageResult} /></Section>
      </div>
    </>
  );
}
