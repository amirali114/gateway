import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { HeroStatus } from "../../../components/HeroStatus";
import { JsonPreview } from "../../../components/JsonPreview";
import { MetricCard } from "../../../components/MetricCard";
import { PageHeader } from "../../../components/PageHeader";
import { ReleaseGateCard } from "../../../components/ReleaseGateCard";
import { SafetyPill } from "../../../components/SafetyPill";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { getMotherAlerts, getMotherHealthReport, getMotherReleaseGates, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";
import type { MotherReleaseGate } from "../../../lib/types";

export const dynamic = "force-dynamic";

function displayReadiness(summary: { fail?: number; blockers?: MotherReleaseGate[]; warn?: number; unknown?: number; skipped?: number } | undefined, gates: MotherReleaseGate[]) {
  const blockers = summary?.blockers || gates.filter((g) => g.status === "fail");
  const fail = summary?.fail ?? gates.filter((g) => g.status === "fail").length;
  const pending = (summary?.unknown ?? gates.filter((g) => g.status === "unknown").length) + (summary?.skipped ?? gates.filter((g) => g.status === "skipped").length);
  if (fail > 0 || blockers.length > 0) return { label: "مسدود", tone: "danger" as const };
  if (pending > 0) return { label: "نیازمند تکمیل", tone: "warning" as const };
  return { label: "آماده مشروط", tone: "success" as const };
}

function groupWarnings(gates: MotherReleaseGate[]) {
  const groups = [
    { title: "Agent", keys: ["agent", "rollout"], items: [] as MotherReleaseGate[] },
    { title: "PHP Wrapper", keys: ["php_gateway", "gateway", "security"], items: [] as MotherReleaseGate[] },
    { title: "Backup / Restore", keys: ["backup_restore"], items: [] as MotherReleaseGate[] },
    { title: "Evidence", keys: ["documentation", "observability", "core", "dashboard", "storage", "mother"], items: [] as MotherReleaseGate[] }
  ];
  for (const gate of gates) {
    const category = String(gate.category || "");
    const target = groups.find((group) => group.keys.includes(category)) || groups[3];
    target.items.push(gate);
  }
  return groups;
}

function GateCards({ gates }: { gates: MotherReleaseGate[] }) {
  if (gates.length === 0) return <EmptyState title="موردی برای نمایش نیست" description="در این گروه blocker یا warning فعالی ثبت نشده است." />;
  return <div className="release-gate-grid">{gates.map((gate) => <ReleaseGateCard key={gate.id || `${gate.category}-${gate.title}`} gate={gate} />)}</div>;
}

export default async function ReleaseReadinessPage() {
  await requirePermission("release.view");
  const [gatesResult, healthResult, alertsResult] = await Promise.all([
    getMotherReleaseGates(),
    getMotherHealthReport(),
    getMotherAlerts({ status: "active", limit: 20 })
  ]);
  const gatesResponse = read(gatesResult);
  const gates = gatesResponse?.gates || [];
  const summary = gatesResponse?.summary || read(healthResult)?.release_gate_summary;
  const health = read(healthResult);
  const alerts = read(alertsResult)?.alerts || [];
  const blockers = summary?.blockers || gates.filter((g) => g.status === "fail");
  const warnings = summary?.warnings || gates.filter((g) => g.status === "warn" || g.status === "unknown" || g.status === "skipped");
  const readiness = displayReadiness(summary, gates);
  const progressTotal = summary?.total ?? gates.length;
  const progressPass = summary?.pass ?? gates.filter((g) => g.status === "pass").length;
  const progressPercent = progressTotal > 0 ? Math.round((progressPass / progressTotal) * 100) : 0;

  return (
    <>
      <PageHeader title="آمادگی انتشار" description="مرکز تصمیم go/no-go برای controlled beta staging؛ شواهد عملیاتی بدون اجرای دستور، بدون enforcement و بدون تغییر runtime نمایش داده می‌شود." />

      <HeroStatus
        tone={readiness.tone === "danger" ? "danger" : readiness.tone === "warning" ? "warn" : "safe"}
        eyebrow="Release readiness"
        title={readiness.label}
        description="اگر fail و blocker صفر باشد، وضعیت آماده مشروط است. موارد pending یا شواهد ناقص با نیازمند تکمیل نمایش داده می‌شوند."
      >
        <SafetyPill label="Enforcement" value="غیرفعال" tone="safe" />
        <SafetyPill label="Remote command" value="وجود ندارد" tone="safe" />
        <SafetyPill label="Agent" value="shadow-only" tone="gold" />
      </HeroStatus>

      <div className="grid cards">
        <MetricCard title="پیشرفت Gateها" value={`${progressPercent}٪`} hint={`${progressPass} از ${progressTotal} عبور کرده`} />
        <MetricCard title="عبور کرده" value={summary?.pass ?? 0} />
        <MetricCard title="هشدار" value={<StatusBadge tone={(summary?.warn || 0) > 0 ? "warning" : "success"}>{summary?.warn ?? 0}</StatusBadge>} />
        <MetricCard title="شکست" value={<StatusBadge tone={(summary?.fail || 0) > 0 ? "danger" : "success"}>{summary?.fail ?? 0}</StatusBadge>} />
        <MetricCard title="بررسی نشده" value={summary?.unknown ?? 0} />
        <MetricCard title="هشدار فعال" value={alerts.length} hint="از Alert Center داخلی" />
      </div>

      <Section title="Gateهای بحرانی" description="وجود هر blocker یعنی Beta نباید شروع شود.">
        {gatesResult.ok ? <GateCards gates={blockers} /> : <ErrorState error={gatesResult.error} />}
      </Section>

      <Section title="هشدارها بر اساس حوزه" description="برای جلوگیری از raw staging look، warningها به checklistهای قابل اقدام تقسیم شده‌اند.">
        {gatesResult.ok ? (
          <div className="release-warning-groups">
            {groupWarnings(warnings).map((group) => (
              <article className="warning-group" key={group.title}>
                <div className="warning-group-head">
                  <h3>{group.title}</h3>
                  <StatusBadge tone={group.items.length > 0 ? "warning" : "success"}>{group.items.length}</StatusBadge>
                </div>
                <GateCards gates={group.items} />
              </article>
            ))}
          </div>
        ) : <ErrorState error={gatesResult.error} />}
      </Section>

      <Section title="همه Gateهای آمادگی Beta">
        {gatesResult.ok ? <GateCards gates={gates} /> : <ErrorState error={gatesResult.error} />}
      </Section>

      <div className="grid two" style={{ marginTop: 16 }}>
        <Section title="خلاصه گزارش سلامت" description="خروجی safe از /v1/health/report به‌صورت خلاصه؛ raw response داخل accordion است.">
          {healthResult.ok ? (
            <>
              <table className="kv"><tbody>
                <tr><th>Shadow-only safety</th><td>{valueOrDash(health?.shadow_only_safety_status)}</td></tr>
                <tr><th>Public exposure</th><td>{valueOrDash(health?.public_exposure_status)}</td></tr>
                <tr><th>Backup / Restore</th><td>{valueOrDash(health?.backup_restore_status)}</td></tr>
                <tr><th>Blockers</th><td>{Array.isArray(health?.blockers) ? health?.blockers.length : 0}</td></tr>
              </tbody></table>
              <JsonPreview title="مشاهده پاسخ خام سلامت" data={{ release_gate_summary: health?.release_gate_summary, backup_restore_status: health?.backup_restore_status, shadow_only_safety_status: health?.shadow_only_safety_status, public_exposure_status: health?.public_exposure_status, blockers: health?.blockers, warnings: health?.warnings }} />
            </>
          ) : <ErrorState error={healthResult.error} />}
        </Section>
        <Section title="آخرین هشدارهای فعال">
          {alertsResult.ok ? alerts.length > 0 ? (
            <table className="data-table"><thead><tr><th>شدت</th><th>محدوده</th><th>عامل</th><th>عنوان</th><th>آخرین مشاهده</th></tr></thead><tbody>{alerts.map((alert) => (
              <tr key={alert.id || alert.fingerprint}><td><StatusBadge tone={alert.severity === "critical" ? "danger" : alert.severity === "warn" ? "warning" : "success"}>{valueOrDash(alert.severity)}</StatusBadge></td><td className="technical-value">{valueOrDash(alert.scope)}</td><td className="technical-value">{valueOrDash(alert.agent_id)}</td><td>{valueOrDash(alert.title)}</td><td className="technical-value">{valueOrDash(alert.last_seen_at)}</td></tr>
            ))}</tbody></table>
          ) : <EmptyState title="هشدار فعالی وجود ندارد" /> : <ErrorState error={alertsResult.error} />}
        </Section>
      </div>

      <Section title="چک‌لیست قبل از Beta" description="برای ثبت تصمیم go/no-go کنار گزارش evidence استفاده شود.">
        <div className="checklist-cards">
          {[
            "Package hash ثبت شده باشد.",
            "Backup کامل و restore drill dry-run پاس شده باشد.",
            "PHP wrapper exposure و public hardening پاس شده باشد.",
            "Telemetry Agent تازه باشد و config rollout simulation پاس شده باشد.",
            "Shadow-only safety پاس شده باشد؛ enforcement و remote command وجود نداشته باشد.",
            "Incident response و rollback path مرور شده باشد."
          ].map((item) => <div className="check-card" key={item}>{item}</div>)}
        </div>
      </Section>
    </>
  );
}
