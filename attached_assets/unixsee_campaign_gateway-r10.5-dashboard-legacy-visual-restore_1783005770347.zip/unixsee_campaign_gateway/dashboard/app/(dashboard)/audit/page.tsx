import { EmptyState } from "../../../components/EmptyState";
import { JsonPreview } from "../../../components/JsonPreview";
import { PageHeader } from "../../../components/PageHeader";
import { Section } from "../../../components/Section";
import { StatusBadge } from "../../../components/StatusBadge";
import { requirePermission } from "../../../lib/auth";
import { roleLabel } from "../../../lib/rbac";
import { listAuditEvents } from "../../../lib/user-store";

export const dynamic = "force-dynamic";

type Props = { searchParams?: Promise<{ action?: string; user?: string; result?: string; target?: string }> };

function actionLabel(action?: string): string {
  const labels: Record<string, string> = {
    login_success: "ورود موفق",
    login_failure: "ورود ناموفق",
    logout: "خروج",
    user_created: "ایجاد کاربر",
    user_updated: "ویرایش کاربر",
    user_disabled: "غیرفعال‌سازی کاربر",
    password_reset: "Reset رمز",
    config_draft_saved: "ذخیره پیش‌نویس",
    config_published: "انتشار config",
    config_rollback: "Rollback config",
    permission_denied: "رد دسترسی",
    api_write_failed: "خطای write API"
  };
  return labels[action || ""] || action || "—";
}

export default async function AuditPage({ searchParams }: Props) {
  await requirePermission("audit.view");
  const sp = searchParams ? await searchParams : {};
  let events = listAuditEvents(500);
  if (sp.action) events = events.filter((e) => e.action === sp.action);
  if (sp.user) events = events.filter((e) => e.actor_username.includes(sp.user || ""));
  if (sp.result) events = events.filter((e) => e.result === sp.result);
  if (sp.target) events = events.filter((e) => e.target_id.includes(sp.target || ""));

  return (
    <>
      <PageHeader title="ردپای عملیات" description="Audit trail محلی Dashboard؛ secret، token، cookie و payload حساس در این لاگ ذخیره نمی‌شود." />
      <Section title="فیلترها"><form className="inline-form"><input name="action" placeholder="action" defaultValue={sp.action || ""} /><input name="user" placeholder="user" defaultValue={sp.user || ""} /><select name="result" defaultValue={sp.result || ""}><option value="">همه نتایج</option><option value="success">success</option><option value="failure">failure</option></select><input name="target" placeholder="target agent/user" defaultValue={sp.target || ""} /><button type="submit" className="button-secondary">اعمال فیلتر</button></form></Section>
      <Section title="آخرین رخدادها">
        {events.length === 0 ? <EmptyState title="رخدادی برای نمایش نیست" description="با عملیات کاربران، audit trail اینجا پر می‌شود." /> : <table className="data-table"><thead><tr><th>زمان</th><th>کاربر</th><th>نقش</th><th>عملیات</th><th>هدف</th><th>نتیجه</th><th>Metadata</th></tr></thead><tbody>{events.map((e) => <tr key={e.id}><td className="technical-value">{e.timestamp}</td><td className="technical-value">{e.actor_username}</td><td>{roleLabel(e.actor_role)}</td><td>{actionLabel(e.action)}</td><td><span className="technical-value">{e.target_type}:{e.target_id}</span></td><td><StatusBadge tone={e.result === "success" ? "success" : "danger"}>{e.result}</StatusBadge></td><td><JsonPreview data={e.metadata || {}} /></td></tr>)}</tbody></table>}
      </Section>
    </>
  );
}
