# R10.26 — Final Action Surface QA

Baseline: R10.25 config workflow safety QA.

## Scope

R10.26 is a final dashboard action-surface audit before deployment. It does not add product features, redesign the UI, or change Mother, Agent, or PHP Gateway runtime code.

## Verified action inventory

- Alert resolve: server action only, `alerts.manage` checked inside the action, Mother called server-side, success/failure audit events written, sanitized redirect codes only, confirmation page required.
- Alert mute: server action only, `alerts.manage` checked inside the action, Mother called server-side, success/failure audit events written, sanitized redirect codes only, confirmation page required.
- Alert unmute: server action only, `alerts.manage` checked inside the action, Mother called server-side, success/failure audit events written, sanitized redirect codes only, confirmation page required.
- Config validate: server action only, `gateway.config.validate` checked inside the action, Mother called server-side, success/failure audit events written, sanitized redirect codes only, no config write.
- Config publish: server action only, `gateway.config.publish` checked inside the action, Mother called server-side, success/failure audit events written, sanitized redirect codes only, confirmation page required.
- Config rollback: server action only, `gateway.config.rollback` checked inside the action, Mother called server-side, success/failure audit events written, sanitized redirect codes only, confirmation page required.

## Safety fixes

- Alert unmute was moved behind the same confirmation surface as resolve and mute.
- Alert detail now displays only whitelisted action status/error codes from query params.
- `ConfigEditor` is fail-closed: it has no form action, cannot submit, and shows draft editing as disabled.
- Server-only modules were explicitly marked with `server-only` to prevent accidental browser imports of Mother API, auth/session, or audit/user-store logic.
- The Mother base URL now reads from the server-only `UNIXSEE_MOTHER_BASE_URL` environment variable only; the `NEXT_PUBLIC_` fallback was removed.

## Guardrails re-verified

- PHP Gateway remains runtime source of truth.
- Go Agent remains shadow-only.
- Browser never fetches Mother directly.
- Mother management token is injected only in server-side API calls and is never rendered to the browser.
- Users without manage/config permissions cannot see action controls.
- View-only pages remain available with view permissions.
- No draft write/edit UI is reachable.
- No deploy, enforcement, or remote-command action exists.
- Dashboard remains English LTR.
- No Persian UI text, Google fonts/CDN, or AI mock terms were introduced.

## Build

- `npm ci`: PASS
- `npm run build`: PASS

## Deployment readiness

Ready for dashboard-only deploy after review. Do not run install-core and do not change Mother, Agent, or PHP Gateway runtime during this deploy.
