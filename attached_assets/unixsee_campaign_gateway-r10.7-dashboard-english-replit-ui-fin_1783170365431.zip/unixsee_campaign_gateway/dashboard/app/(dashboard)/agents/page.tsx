import { AgentCard } from "../../../components/AgentCard";
import { DataTable } from "../../../components/DataTable";
import { EmptyState } from "../../../components/EmptyState";
import { ErrorState } from "../../../components/ErrorState";
import { KpiCard } from "../../../components/KpiCard";
import { PageHeader } from "../../../components/PageHeader";
import { RawJsonDrawer } from "../../../components/RawJsonDrawer";
import { SectionCard } from "../../../components/SectionCard";
import { StatusPill } from "../../../components/StatusPill";
import { getMotherAgents, getMotherAlertSummary, getMotherDiagnosticsSummary, read, valueOrDash } from "../../../lib/api";
import { requirePermission } from "../../../lib/auth";

export const dynamic = "force-dynamic";
function pct(v: unknown) { const n = Number(v || 0); return Number.isFinite(n) && n > 0 ? `${n.toFixed(1)}%` : "—"; }

export default async function AgentsPage() {
  await requirePermission("agents.view");
  const [agentsResult, summaryResult, alertsResult] = await Promise.all([getMotherAgents(), getMotherDiagnosticsSummary(), getMotherAlertSummary()]);
  const agents = read(agentsResult)?.agents || [];
  const summary = read(summaryResult)?.summary;
  const online = summary?.online_agents ?? agents.filter((a) => a.status === "online").length;
  const stale = summary?.stale_agents ?? agents.filter((a) => a.status === "stale").length;
  const unknown = summary?.unknown_agents ?? Math.max(0, agents.length - online - stale);
  return (
    <>
      <PageHeader eyebrow="Registry" title="Agents" description="Mother registry and telemetry aggregate. The dashboard never fetches Agents directly from the browser." />
      <div className="grid kpis">
        <KpiCard title="Total agents" value={agentsResult.ok ? agents.length : "—"} hint={agentsResult.ok ? "registered in Mother" : agentsResult.error} icon="◉" tone="blue" />
        <KpiCard title="Online" value={online} icon="✓" tone="success" />
        <KpiCard title="Stale" value={stale} icon="!" tone={stale ? "warning" : "success"} />
        <KpiCard title="Unknown" value={unknown} icon="?" />
        <KpiCard title="Fresh telemetry" value={summary?.telemetry_fresh ?? 0} hint={`missing ${summary?.telemetry_missing ?? 0}`} icon="⌁" />
        <KpiCard title="Active alerts" value={read(alertsResult)?.active_total ?? 0} icon="!" tone={(read(alertsResult)?.critical || 0) > 0 ? "danger" : "neutral"} />
      </div>
      <SectionCard title="Agent cards" description="Click an agent to inspect telemetry, config history, events, and alerts.">
        {agentsResult.ok ? agents.length ? <div className="agent-grid">{agents.map((agent) => <AgentCard key={agent.agent_id || Math.random()} agent={agent} href={agent.agent_id ? `/agents/${encodeURIComponent(agent.agent_id)}` : undefined} />)}</div> : <EmptyState title="No agents registered" description="Agents appear here after a policy pull or telemetry push." /> : <ErrorState error={agentsResult.error} />}
      </SectionCard>
      <SectionCard title="Registry table">
        {agentsResult.ok ? agents.length ? <DataTable><thead><tr><th>Agent ID</th><th>Status</th><th>Telemetry</th><th>Last telemetry</th><th>Match rate</th><th>Config sync</th><th>Received</th><th></th></tr></thead><tbody>{agents.map((agent) => <tr key={agent.agent_id || Math.random()}><td className="mono">{valueOrDash(agent.agent_id)}</td><td><StatusPill value={agent.status || "unknown"} /></td><td><StatusPill value={agent.telemetry_status || "missing"} /></td><td className="mono">{valueOrDash(agent.last_telemetry_at)}</td><td>{pct(agent.last_match_rate)}</td><td><StatusPill value={agent.config_sync_status || "unknown"} /></td><td>{valueOrDash(agent.last_received)}</td><td>{agent.agent_id ? <a className="button-link button-secondary" href={`/agents/${encodeURIComponent(agent.agent_id)}`}>Open</a> : null}</td></tr>)}</tbody></DataTable> : <EmptyState title="No rows" /> : <ErrorState error={agentsResult.error} />}
      </SectionCard>
      <RawJsonDrawer data={agentsResult.ok ? agentsResult.data : agentsResult} title="Raw Mother registry" />
    </>
  );
}
