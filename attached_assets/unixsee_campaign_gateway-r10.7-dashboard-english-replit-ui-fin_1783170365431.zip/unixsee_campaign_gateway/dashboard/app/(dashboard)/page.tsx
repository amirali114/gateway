import { AgentCard } from "../../components/AgentCard";
import { DataTable } from "../../components/DataTable";
import { KpiCard } from "../../components/KpiCard";
import { PageHeader } from "../../components/PageHeader";
import { RawJsonDrawer } from "../../components/RawJsonDrawer";
import { SectionCard } from "../../components/SectionCard";
import { StatusPill } from "../../components/StatusPill";
import { requirePermission } from "../../lib/auth";
import { getDashboardOverview } from "../../lib/dashboard/server-data";
import { releaseLabel } from "../../lib/dashboard/mappers";
import { valueOrDash } from "../../lib/api";

export const dynamic = "force-dynamic";

export default async function OverviewPage() {
  await requirePermission("dashboard.view");
  const overview = await getDashboardOverview();
  const overallTone = overview.alerts.critical ? "danger" : overview.alerts.warn || overview.agents.stale ? "warning" : "success";
  return (
    <>
      <PageHeader eyebrow="Unixsee Gateway" title="Dashboard" description="Operational view for the Mother-backed controlled beta. PHP Gateway remains the runtime source, Agents remain shadow-only, and the browser never talks to Mother directly." />
      <div className="grid kpis">
        <KpiCard title="Overall posture" value={<StatusPill tone={overallTone}>{overallTone === "success" ? "Healthy" : overallTone === "warning" ? "Needs review" : "Critical"}</StatusPill>} hint="Health + telemetry + alerts" icon="◈" tone={overallTone} />
        <KpiCard title="Mother health" value={<StatusPill value={overview.health.ok ? "healthy" : "unavailable"} />} hint={overview.health.service} icon="◎" tone={overview.health.ok ? "success" : "danger"} />
        <KpiCard title="Gateway Agents" value={overview.agents.total} hint={`${overview.agents.online} online · ${overview.agents.stale} stale`} icon="◉" tone="blue" />
        <KpiCard title="Release" value={<StatusPill value={releaseLabel(overview.release)} />} hint={`fail ${overview.release.fail || 0} · warn ${overview.release.warn || 0}`} icon="◇" tone="violet" />
      </div>
      <div className="grid kpis" style={{ marginTop: 14 }}>
        <KpiCard title="Telemetry fresh" value={overview.agents.freshTelemetry} hint="from Mother registry" icon="⌁" />
        <KpiCard title="Storage engine" value={valueOrDash(overview.storage?.engine || overview.ready.engine)} hint={overview.storage?.writable ? "writable" : "read-only or unknown"} icon="▣" />
        <KpiCard title="Active alerts" value={overview.alerts.active_total ?? 0} hint={`${overview.alerts.critical || 0} critical · ${overview.alerts.warn || 0} warn`} icon="!" tone={(overview.alerts.critical || 0) > 0 ? "danger" : (overview.alerts.warn || 0) > 0 ? "warning" : "success"} />
        <KpiCard title="Safety mode" value="Shadow" hint="no enforcement · no remote commands" icon="✓" tone="success" />
      </div>

      <div className="grid two" style={{ marginTop: 14 }}>
        <SectionCard title="Active agents" description="Latest known Agent registry entries from Mother." action={<a className="button-link button-secondary" href="/agents">View all</a>}>
          <div className="agent-grid">{overview.agents.items.slice(0, 4).map((agent) => <AgentCard key={agent.agent_id || Math.random()} agent={agent} href={agent.agent_id ? `/agents/${encodeURIComponent(agent.agent_id)}` : undefined} />)}</div>
          {overview.agents.items.length === 0 ? <div className="empty-state">No agents are registered yet. They will appear after policy pull or telemetry push.</div> : null}
        </SectionCard>
        <SectionCard title="Latest alerts" description="Alert Center summary without exposing secrets.">
          {(overview.alerts.latest || []).length ? <DataTable><thead><tr><th>Severity</th><th>Scope</th><th>Agent</th><th>Title</th><th>Last seen</th></tr></thead><tbody>{(overview.alerts.latest || []).slice(0, 5).map((alert) => <tr key={alert.id || alert.fingerprint}><td><StatusPill value={alert.severity || "info"} /></td><td>{valueOrDash(alert.scope)}</td><td className="mono">{valueOrDash(alert.agent_id)}</td><td>{valueOrDash(alert.title)}</td><td className="mono">{valueOrDash(alert.last_seen_at)}</td></tr>)}</tbody></DataTable> : <div className="empty-state">No active alerts.</div>}
        </SectionCard>
      </div>
      <div style={{ marginTop: 14 }}><RawJsonDrawer data={{ health: overview.health, ready: overview.ready, agents: overview.agents, release: overview.release, alerts: overview.alerts }} title="Raw normalized overview" /></div>
    </>
  );
}
